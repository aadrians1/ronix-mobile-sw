Nokia Card Phone 2.0
(c) 1997-2000 Nokia Mobile Phones. All rights reserved.

=================================================================
TABLE OF CONTENTS (README.TXT)
=================================================================

1.  Introduction
2.  Abbreviations used in this document
3.  System requirements
4.  Last minute additions and changes to the user manuals
 4.1  Troubleshooting
  4.1.1 Installation does not continue after inserting the NCP
  4.1.2 Installation stops to ask Location Information
  4.1.3 NCP is not working after Plug-In installation
  4.1.4 After inserting the NCP, Windows stops responding
  4.1.5 NCP is not working after using COM Port Changing Tool
  4.1.6 Internal mouse or speakers are not working properly
  4.1.7 Component self-registration failed during the installation
  4.1.8 Dial-Up Networking in Windows NT 4.0
  4.1.9 Windows 2000 asks for NCP Installation Disk 1 
 4.2 AT command restrictions
 4.3 How to determine which Windows version you are using
 4.4 User Interface
  4.4.1 I cannot write a text message when the NCP is not inserted
  4.4.2 High Speed Data indicator is not shown
  4.4.3 High Speed Data settings are not working under
        Windows NT 4.0 / Windows 2000
  4.4.4 Sending a fax during a voice call
  4.4.5 Uninstalling the NCP when Nokia Data Suite 3.0 is installed
 4.5 Importing and exporting contacts
  4.5.1 Importing contacts from the Nokia Cellular Card Phone 1.x
  4.5.2 Importing contacts from Outlook 98
5. Compatibility notes
 5.1 PC Card Modem Power Management
 5.2 Laptops
  5.2.1 Laptops using Phoenix Card Manager 95
 5.3 Nokia Card Phone hardware/software
 5.4 Windows NT 4.0 and CardWizard
 5.5 Windows NT 4.0 and Softex Card Services

=================================================================
1.  INTRODUCTION
=================================================================

This document provides information to help you to use the Nokia
Card Phone 2.0, hereafter called NCP.

It deals with last minute additions and changes to the user
manuals as well as compatibility issues and possible problem 
causes and is preferred to be read prior to the installation of
NCP.

For more information on how to deal with certain problems that 
you might encounter, please refer to the NCP Online Help 
(Help topics/Contents/Troubleshooting).

=================================================================
2.  ABBREVIATIONS USED IN THIS DOCUMENT
=================================================================

ACPI		Advanced Configuration and Power management 
		Interface
APM		Advanced Power Management
bps		Bits per second
MB		Megabyte
MHz		Megahertz
NCP		Nokia Card Phone 2.0
RAM		Random Access Memory
RAS             Remote Access Service
SIM		Subscriber Identification Module
SMS		Short Message Service
SP              Service Pack
UART		Universal Asynchronous Receiver/Transmitter

=================================================================
3. SYSTEM REQUIREMENTS
=================================================================

To install and run NCP, you need the following:

  * Personal Computer with a Pentium 166 MHz processor or higher
  * Windows 95/98 operating system
    or Windows NT 4.0 operating system with SP 3 or higher
    or Windows 2000 operating system
  * Type I or II PCMCIA socket
  * 32 MB of RAM (recommended)
  * 15 MB of free hard disk space (depends on language selection)
  * 800 x 600 display resolution

NOTE: Nokia Card Phone 2.0 supports only CardWizard and Softex 
Card Services under Windows NT 4.0.

=================================================================
4. LAST MINUTE ADDITIONS AND CHANGES TO THE USER MANUALS
=================================================================

4.1  Troubleshooting

4.1.1 Installation does not continue after inserting the NCP. 

If installation does not seem to continue after inserting 
the NCP (when the "New Hardware Found" dialog appears), it 
may be that all interrupts in the system are reserved. 
Press the Skip button in the "Insert Nokia Card Phone 2.0" 
dialog to continue the installation without running the 
driver checks. 

You can then verify the resource conflict by selecting 
Control Panel -> System -> Device Manager -> Multifunction Device 
-> Nokia Card Phone. If there is the text "resource conflict", 
you have to remove other PC Cards or disable some other device to 
free an interrupt. Check also from the Windows Help how to 
resolve resource conflicts and free resources.

When you have resolved all resource conflicts, start the 
installation program again. 

See also topic 4.1.3.

4.1.2 Installation stops to ask Location Information.

In Windows 95, after inserting the NCP, the installation of 
drivers stops to ask Location information and specifically 
the area code. Enter the required code to continue with the 
installation.

4.1.3 NCP is not working after Plug-In installation

If you have accidentally installed NCP as a standard modem,
you have to remove the "Standard PCMCIA Card Modem" from 
Control Panel -> Modems, and then start the NCP installation 
program (Setup.exe) from the CD-ROM.

4.1.4 After inserting the NCP, Windows stops responding.

This may be caused by a resource conflict. For example, 
some other PC Card is using the same interrupt. If this is 
the case, remove the other PC Card and insert the NCP again. 
Otherwise, refer to the Windows Help for information on how 
to resolve resource conflicts and free resources.

4.1.5 NCP is not working after using the COM Port Changing Tool.

Do not select a COM port which is already being 
used by an internal modem, infrared port or Nokia Data Suite. 

4.1.6 Internal mouse or speakers are not working properly.

If the internal mouse is not working properly, or there is
additional noise coming from the speakers during calls, it may
be caused by RF interference. Use an external antenna or change
the antenna's position.

4.1.7 Component self registration failed during the installation

During the installation there might appear the error message
"Failed to self-register files ...". Because of this failure, the
User Interface will not work properly. To resolve this problem, 
you need to reinstall Nokia Card Phone 2.0.

4.1.8 Dial-Up Networking in Windows NT 4.0

To use the NCP 2.0 with Dial-Up Networking in Windows
NT 4.0, the NCP 2.0 must first be added to the list of RAS devices.
To do this, go to Control Panel -> Network -> Services -> Remote Access 
Service -> Properties and click Add. Select Nokia Card Phone 2.0 from the list.
After re-starting the system, the Card Phone 2.0 appears in the 
"Dial using" list within Dial-Up Networking and it can be chosen
from the list.

4.1.9 Windows 2000 asks for NCP Installation Disk 1 

If the card insertion is skipped during the installation,
the location of the Nokia Card Phone 2.0 driver has to be entered 
manually when the card is inserted for the first time after the
installation. Follow the steps below:

1. Insert the card into the PCMCIA slot of your computer. 
2. After a while Windows warns about a non-certified driver. Click Yes.
3. When Windows asks for "NCP Installation Disk 1", click OK and then
Browse to \WinNT\System32\Drivers\ directory. Click Open.
4. Click OK. Windows 2000 installs the driver and the Card Phone 2.0
can be used.

-----------------------------------------------------------------

4.2 AT command restrictions

It is recommended that you do not use the Short Message AT 
commands while you are using the NCP Messages application. The 
same restriction also applies to the Phone/SIM memory AT commands
and the NCP Contacts application. If this restriction is not 
followed, it is possible that the NCP User Interface is not 
working normally.

-----------------------------------------------------------------

4.3 How to determine which Windows version you are using

You find the version number from Control Panel->System->General
tab. In retail version of Windows 95 the version number is 
4.00.950. After the version number there can also be a letter 
(A or B). If your Windows version is B, check also the section 
"5.1 PC Card Modem Power Management".

-----------------------------------------------------------------

4.4 User Interface 

4.4.1 I cannot write a text message when the NCP is not inserted.

There must be at least one SMS setting group stored in the 
database, otherwise it is not possible to write text 
messages when the NCP is not inserted in the PC Card slot.

4.4.2 High Speed Data indicator is not shown.

The High Speed Data indicator is only shown for multislot
configurations, not for single slot configurations. This means
that when connected at 9.6 kbps or 14.4 kbps, the High Speed Data
indicator is not shown.

4.4.3 High Speed Data settings are not working under
      Windows NT 4.0 / Windows 2000

When changing the High Speed Data settings from Card Phone's 
Settings -> Modem, there may appear the error message 
"Cannot access registry value". This will happen if the user 
does not have administrator rights (local admin).

4.4.4 Sending a fax during a voice call.

Sending a fax during a voice call is not recommended, because some
fax programs may drop the ongoing voice call during the modem
initialisation phase.

4.4.5 Uninstalling the NCP when Nokia Data Suite 3.0 is installed.

When uninstalling the NCP on a computer that has Nokia Data Suite
3.0 installed, select "No to All" in the "Remove shared file?" 
dialog. If "Yes" or "Yes to All" is selected, Nokia Data Suite 
3.0 will not work properly, and it must be reinstalled.

----------------------------------------------------------------- 

4.5 Importing and exporting contacts

You can use the Import and Export functions of the Contacts 
application to import contacts from a file to Nokia Card Phone 2.0
and vice versa.

4.5.1 Importing contacts from Nokia Cellular Card Phone 1.x.

Export contacts from Card Phone 1.x to a file. Then use Nokia
Database Converter to convert the file into the Outlook .csv format.
You can then import the .csv file to the Contacts application of 
Nokia Card Phone 2.0.

4.5.2 Importing contacts from Outlook 98.

Note that the Nokia Card Phone 2.0 Import and Export format is 
compatible with the Outlook 98 .csv format. In some language 
versions of Outlook 98, you might meet incompatibility.

=================================================================
5. COMPATIBILITY NOTES
=================================================================

5.1 PC Card Modem Power Management

In version B of Windows 95, the PC Card Modem Power Management 
should not be enabled (see section "How to determine which 
Windows version you are using"). Otherwise the NCP cannot be 
installed nor used.

----------------------------------------------------------------- 

5.2 Laptops

5.2.1 Laptops using Phoenix Card Manager 95

Symptom: The driver functionality and MPAPI tests fail.

Solution: The system has been configured with Phoenix Card 
Manager 95. Contact Phoenix technical support to get the latest 
version of the Phoenix Card Manager drivers (4.00.80 or later).

5.3 Nokia Card Phone 2.0 hardware/software

Certain cellular networks do not support 7-bit data calls and
connection problems may occur if applications have been 
configured for 7-bit use.

The default data transfer speed is 9600 kbps. Configuring 
applications to use transfer speeds other than the default value
may result in data transfer problems, unless the SIM has been
configured to support them.

5.4 Windows NT 4.0 and CardWizard

Nokia Card Phone 2.0 requires version 5.00 of the CardWizard to
work properly under Windows NT 4.0. Contact your laptop vendor to
get the latest version of the CardWizard. After the installation, 
the laptop must be restarted in order for the NCP to work properly.

5.5 Windows NT 4.0 and Softex Card Services

Nokia Card Phone 2.0 requires version 2.33 of Softex Card
Services to work properly under Windows NT 4.0. Contact your 
laptop vendor to get the latest version of the Softex. After the
installation, the laptop must be restarted in order for the NCP 
to work properly.

=================================================================

(c) 1997-2000 Nokia Mobile Phones. All rights reserved.
Nokia and Nokia Connecting People are registered trademarks of 
Nokia Corporation. Windows 95, Windows 98, Windows NT 4.0 and
Windows 2000 are registered trademarks of Microsoft Corporation.
Other products and company names mentioned herein may be 
registered trademarks or trade names of their respective owners.

Nokia Mobile Phones operates on a policy of continuous 
improvement. Therefore we reserve the right to make changes and 
improvements to any of the products described in this guide 
without prior notice.
Nokia Mobile Phones is not responsible for any loss of data,
income or any consequential damage howsoever caused.