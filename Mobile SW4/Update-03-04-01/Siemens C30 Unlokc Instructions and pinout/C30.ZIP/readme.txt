this is the only 100% working Siemens C30 solution out now!!!

The C30 was build by Bosch and is for sale by Siemens so you can use a real Bosch code reader to view the unlock code!!

this solution was fucked by a friend who bought a C30 Unlocker by PRO incl. Dongle use portsniffer and found out that the Bosch Unlocker by VirtualM uses the same string as the unlocker by PRO!!!

So try this solution it really works... ive unlocked today many C30 by this method!!

regards

--------------------------------
not tested  wrrrrrrrrrr
SKY
---------------
skygsm@hoga.pl

