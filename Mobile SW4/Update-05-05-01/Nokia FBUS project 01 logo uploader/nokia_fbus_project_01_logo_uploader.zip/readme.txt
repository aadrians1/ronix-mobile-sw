Nokia FBUS Project 01 Logo Uploader by =mOp= Dru Crew
=====================================================

Hi friends, this is my first mobile project.....

it's made with da great mobilefbuscontrol from http://softwarecave.nl
You can download demo and full source there...

click start_me_first.bat to add needed ocx to your system...

Connect your nokia to cable now, start my soft and select comport for automatical connection.

Enjoy!!!

Best regards

=mOp=
Leader of Dru Crew

http://go.to/drucrew