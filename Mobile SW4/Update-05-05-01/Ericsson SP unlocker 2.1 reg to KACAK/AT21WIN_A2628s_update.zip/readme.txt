Upravena verzia AT21WIN rozpozna a odblokuje A2628s.
