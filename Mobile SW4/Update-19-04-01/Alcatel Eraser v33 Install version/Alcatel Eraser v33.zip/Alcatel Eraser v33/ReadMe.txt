Need emulator donga!!
work:
BE1 16B, 16C, 16D, 16E1m, 16F
BE3 170, 171, 16B
BE4 134, 135, 136, 137
and red/writer lang