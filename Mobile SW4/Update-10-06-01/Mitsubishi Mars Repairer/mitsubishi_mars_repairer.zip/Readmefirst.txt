Mitsubishi Mars "Malfunction" Solution.

Creat directory c:\friend.

Extract this file to c:\friend.

Read EEPROM through Read write from EEPROM.

Save it.

OPen it and press Repaire it.

Write C:\friend\mars.bin to Phone.

Your Phone will work.


This Program will not work on Tempered Phones.

IF any problem occurs in read/write EEPROM contact on 

gsm_boy@rediffmail.com.


GOOD LUCK !!!!!


Note : This Program will works only on com1.


If error comes like "There is some fault in Installation"

Then contact run crack.exe.

contact bellaphones@hotmail.com




----
downloaded from: 
http://www.techgsm.com/