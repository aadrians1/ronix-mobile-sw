**********************************
* Panasonic GD92 Module Composer *
*          Version 0.6a          *
**********************************
*     by SiRio / KoGA DeSiGN     *
**********************************


-----------
Disclaimer:
-----------

GD92 Composer (C)2000/2001 by Saverio Russo (SiRioKD)

- It can be distributed freely as long as it is not modified.
- When you use it you do so at your own risk.
- The author is not responsible for any loss or damage resulting 
  from the use or misuse of GD92 Composer.
- If you do not agree with these terms delete GD92 Composer now!


--------
Contact:
--------

mailto: siriokds@libero.it



--------
History:
--------

...................................................................................
11/Jan/2001	Version 0.6a:

+ Added info about note phone-keyboard sequence

...................................................................................
24/Dec/2000	Version 0.5a:

* Changed DirectSound DataBuffer Streaming Routines.
  DirectSound Position Notify of DirectX sucks!
  Now i use a MMTimer that are more accurate, and more responsive.
  Latency changed from 250ms downto 80ms (responsive value, but safe!)
  MMTimer method works better with Win2K!
 
* Fixed a bug in titlebar module filename showing routine.

+ Improved Graphics Routines, now more responsive!

+ Added 4 modules (.m92) to package, now contains 12 songs.

...................................................................................
14/Dec/2000	Version 0.4a:

* First Public Release!

...................................................................................



-------------------
Keyboard Shortcuts:
-------------------

CTRL+N				New  Module
CTRL+L				Load Module
CTRL+S				Save Module
CTRL+X				Quit program
F9				Play Song
F8				Stop Song

F1,F2,F3			Select octave
F4				Rotate octave
1,2,3,4,5			Select note length
Z,S,X,D,C,V,G,B,H,N,J,M		Play/Insert note
P				Play/Insert Pause
SPACE				Stop Song, Stop Note, Switch Edit/Rec Mode

Arrow UP,DOWN,LEFT,RIGHT	Cursor move
HOME, END			Cursor to begin/end
CTRL+HOME			Cursor to begin of row
CTRL+END			Cursor to end of row
PAGEUP, PAGEDOWN		Cursor to previous/next 4 rows

BACKSPACE			Delete prev note and back
DELETE				Delete note/block
CTRL+LEFT, CTRL+RIGHT		Dec/Inc selected note length
CTRL+UP, CTRL+DOWN		Dec/Inc selected note/block octave

CTRL+B				Start/End Block Mode
CTRL+C				Copy note/block to memory
CTRL+V				Paste memory to cursor



----
downloaded from: 
http://www.techgsm.com/