/* DL95dll_int.h : header file */

/* define for Dl95_Init() function */
#define AUTOMATIC	0x20
#define OTHER		0x00

/* define for receiving windows message */
#define WM_USER_TRACE_LOADBYTES		0x0410
#define WM_USER_TRACE_LISTMSG		0x0420
#define WM_USER_TRACE_PROGRESSBYTES	0x0430
#define WM_USER_TRACE_ERROR			0x0440

/* define for return parameter of Dl95_Download() function */
/* if return OK */
#define DOWNLOADCOMPLETED		50
/* if return KO */
#define ERROR_DOWNLOADCANCELED	51
#define ERROR_WINDELAY			52
#define	ERROR_PARITY			53
#define ERROR_SPEED				54
#define ERROR_WAITSTATE			55
#define ERROR_RAMSIZE			56
#define ERROR_OPEN_COM			57
#define ERROR_OPENAPPFILE		58
#define ERROR_OPENLOADFILE		59
#define ERROR_MEMORYAPPFILE		60
#define ERROR_MEMORYLOADFILE	61
#define ERROR_STOPBITS			62
#define ERROR_READAPPFILE		63
#define ERROR_READLOADFILE		64
#define ERROR_PARAM_COM			65
#define ERROR_PARAM_FILE		66
#define ERROR_DBG				67

typedef struct
{
int m_ComPort;
int m_RamWaitState;
int m_RamSize;
int m_Speed;
int m_Parity;
int m_StopBit;
} ParamCom;

typedef struct
{
char * aS_LoadFileName;
char * aS_AppFileName;
char * aS_TraceFileName;
} ParamFile;

typedef struct ParamDebug
{
int mode_mem;
int pause;
int acknowledge;
} ParamDebug;

typedef void (*T_Dll95_Init)(UINT par);
typedef void (*T_Dll95_StartStop)(BOOL par);
typedef UINT (*T_Dll95_Download)(HWND handle, ParamCom *DlgCom, ParamFile *Dlgfile,ParamDebug *DlgDbg);

