Reg instruction:
1.start reg_me.exe and enter path to your win directory
2.soft generate reg.rec file on c:\
3.use the rec2nfo table and replace the first line
4.save new file to "reg.nfo"

Install instruction:
1.unzip file c30_unl.zip to some folder
2.copy reg.nfo to same folder where the software is
3.open loader.exe and type password: tweetygroup
4.after that software will be open dongle emulator program
  (the loader.exe must be opened too)
5.disable KEYPRO and Optimaze data in dongle emulator
  open file: .kpe
  enable "enable emulator"
6.don't shut down dongle emulator program
  (dongle emulator must be opened too)
7.go to loader.exe and click enter
8.wait for calibration to 100%
9.after that c30 software will be open automate
10.after your work go to loader.exe and click enter and than
   close all programs!
