copy MSCOMM32.* files to C:\WINDOWS\SYSTEM32 folder!!!
