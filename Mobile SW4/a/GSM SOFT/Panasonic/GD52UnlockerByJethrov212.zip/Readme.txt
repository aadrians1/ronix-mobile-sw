Lancez $loader.exe ! Be happy ! ;o)

Launch $loader.exe ! Be happy ! ;o)