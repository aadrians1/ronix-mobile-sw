notes...... 


Wieso gehen manche Nummern nicht?
-Die von Euch erstellte Nummer wurde einfach schon benutzt.


Kann es sein das Deine Nummer nicht existiert???
-NNNNNNEEEEEEIIIIIINNNNN

Kann man mich erwischen?
-Klar kann man, denn wenn Ihr die Karte selber gekauft habt, dann haben die ja Eure PersoKopie.

Aber daran denken..... 

Der Kontoserver wird nach einiger zeit gesperrt.... (ca 16 versuchen)
Dies ist aber nicht weiter schlimm, Callyateam anrufen und sagen
handy irgendwo liegengelassen und wiedergefunden oder sowas....
DENKT euch was aus!!!


!!!!!!!!!!!!!!!!!!!!!
Dieses Programm wurde nur geschrieben um zu zeigen das ein generierren von Call Ya Nummern m�glich ist
Dieses Programm soll keinem schaden es ist nur aus Testzwecken geschrieben worden
Dieses Programm zu benutzen ist illegal und wird bei Missbrauch vom Gesetzgeber verfolgt und bestraft

          ich �bernehme keine Haftung f�r Folgesch�den
!!!!!!!!!!!!!!!!!!!!!

 ________________
|         
| Damit dieses Tool weiterhin aktuell bleibt m��t ihr eure
| neuen Callnowkarten (nachdem ihr sie eingel�st habt) 
| an die weiter geben von denen ihr das tool habt :))))
|_______

cya
TheW****



