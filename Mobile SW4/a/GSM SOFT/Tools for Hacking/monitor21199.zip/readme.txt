1......Registrieren    (deutsch)
2......How to register (english)
3......some hints      (english)


1. Die Lizenz zum Sendersuchen - bitte beachten:

  Dieses Programm ist nicht 'Freeware'. Wer das Programm regelm��ig verwendet 
  oder es beruflich einsetzt muss es registrieren. Damit werden dann auch 
  einige weitere Funktionen (die Auswertung des Monitormode von M20 und Nokia)
  freigeschaltet.

  Die Registriergeb�hr betr�gt nach eigener Wahl:

   - Schokolade oder
   - Kekse oder
   - sonstwas nettes, von dem man annehmen kann, dass es mich freut.

  Hierbei sollte darauf geachtet werden, da� jeweils regionale Spezialit�ten 
  eingekauft (und verschickt...) werden.

  Firmen sind gehalten, sch�ne und seltene Werbegeschenke zu schicken.

  Die Zusendung nichtmaterieller Dinge kann nur in Ausnahmef�llen als 
  Registrierung anerkannt werden.

  Diese Sachen sollten verschickt werden an:

     Norbert H�ttisch
     Berckm�llerstrasse 31
     76131 Karlsruhe
     Germany

  Bitte nicht vergessen, die EMailadresse anzugeben, damit der 
  Registrierungs-Key zugesandt werden kann.
  
  Danke + Viel Spa�!

  Norbert H�ttisch (nobbi@nobbi.com)



2. License to search BSs - please note:

  This software isn't 'freeware'. Everyone who is using this software 
  regularly or is using it for his business has to register it. 
  When registered, some more functions are enabled (e.g. the Monitormode display
  of the Siemens M20 and Nokia).

  As registration fee you may send on your own choice:

   - some chocolate or
   - some cookies or
   - something nice, which you think is making me happy

  Please take care to buy (and send...) some of your local specialities.

  Companys and Organisations may send some rare and pretty giveaways.

  Registration thru email (by sending software or such things) is normally 
  not possible , sorry.

  See above for address. Thanks + have fun.

  Please don't forget your EMailaddress, so that the registration key may 
  be sent to you by email.


3. Some hints, simply because lots of you have asked for it:

  When using a NOKIA phone, you must 

  EITHER:

  decide to use AT-commands. Use the virtual COMPort made available 
  through the NCDS. This piece of software must be installed, sorry folks....
  Do not use the real COMx (with DAU9P) or your IR-port for AT-commands.

  OR:

  decide to use direct FBUS communication (registered feature). Set the 
  FBUSMODE switch in monitor.ini and use the hardware comport.


  Additionally, NOKIA-phones used with NCDS sometimes feel the need to 
  react curious. Examples are:

   - your printjobs seem to hang
   - the phone locks up
   - the phone starts to make strange beeps

  This seems to be the nature of some (not all) NCDS installations. 
  Sometimes these effects vanish after reinstalling NCDS. And it makes 
  sense to have the actual phonesoftware loaded into you NOKIA.


  Before contacting me with any problems, think about this:

   - Have you selected the correct port? For NOKIA: the NCDS port. 
     For all others: a suitable COM-port.

   - Have you switched off the phone, and then on again? 
     This often helps with SIEMENS phones.

   - Is the phone responding to AT-Commands in a terminalprogram? 
     If not, your settings are not correct. Try again....

  After this, collect the following information, and send it to me:

   - the type of phone you are using
   - the version of your phonesoftware
   - what cable/port/irda/hardware you are using
   - your operating system

  If you find any errors in this text, let me know. 
  My english is far away from being good.
