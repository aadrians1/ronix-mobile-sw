This language pack is for users of LogoManager, version 1.0 Beta 6 and upwards.  
To install, extract the file lm_lang.dll into the LogoManager directory, then
run LogoManager.  The new languages should now be listed in the International
Settings option in the configuration dialog.
