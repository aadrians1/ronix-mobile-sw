Nokia NetMagic V2.0XMas (NetMonitor Activator for NOKIA 51/6110, 3210)


    Version 2.0XMas

* MANY BUG'S CORRECTED !!!!
* NOW WORKING WITH ALL CABLE'S Recommended:(M2BUS)
* RESET BUTTON REMOVED
* PROGRESS BAR ADDED !!!
* POWER "ON" THE PHONE ADDED
* ADDED A HTTP URL LINK
.........

This file downloaded from http://www.gsm.mits.lv
