New Phone Images For Logomanager
***************************************************
Instructions: After you connect your phone to the logomanager, 
for instance if it's 8210, it will display the piture of the default
red 8210, or if you've installed the Picture Pack By Mike Bradley, 
blue Nokia 8210, or the pic of your model.
To insert a different image, just pick the one you want
from the BMP's available and RENAME them to 8210.BMP while the
logomanager is off. Run the Logomanager, 
and the default pic should be the one you've picked!
You can rename the picture of ANY phone to the phone brand currently attached
and next time when run, Logomanager will display it's pic!

Logomanager name and program is copyrighted by Mike Bradley
To find out more about this great product, please
visit the web site: http://www.logomanager.co.uk/

Thhis pack is updated regullary, so chek back on 
http://www.zamir.net/~josipm/Nokia/nokiafaq/#30
for updates!

Remember the link for donload it is 
NOVE SLIKE TELEFONA ZA LOGOMANAGER !!!

thx, jsp_m

+++++++++++++++++++++++++++++++++++++

Za one koji neznaju engleski: samo prekopirati slike tamo gdje je 
logomanager instaliran i preimenovati sliku koju zelite da vam 
pokaze  ime telefona koji je prilkucen (ako imate 8850 spjen, a zelite 
zlatni 8850 onda sliku 8850.bmp preimenujte u npr. 8850a.bmp, a 
8850gold_edition.bmp u 8850.bmp)

jsp_m