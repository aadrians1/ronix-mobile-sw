Program Convert.exe je urcen na konvertovani BMP souboru do NOL (NGG) a obracene.
NOL (NGG) format nacte Nokia Grouph-Graphic Editor a Nokia Operator-Logo Uploader.

Vstupni bitmapa musi mit nasledujici parametry:
 72x14 pixelu,
 monochromaticka
 bez komprese

SW pozadavky: Win95/98/NT
Freeware

http://www.vaizr.cz/nokia
nokia@vaizr.cz
