	==========================================================
	        >>> Iguana Ring 0.99 (Beta) Introduction <<<
	==========================================================

  0) History
  
  - version 0.99 (20 JUN 2000)
    Current version. This update fix some the the bugs while converting midi file. It also
    let you specify Iguana Home Site IP.
    
  - version 0.91 (30 NOV 1999)     
    Iguana Ring first release 

  1) What

  A simple tool to convert MIDI music to Nokia mobilephone ringtone.  You can then upload the 
  ringtone to Iguana SMS service site at http://www.apic.com.sg and transmit it to a Nokia 
  mobilephone online.

  Only MIDI type 0 and 1 are supported in this version.

  2) Copyright

  Iguana Ring is Copyright 1999 by Apic Systems Pte Ltd. 

  3) Cost

  This is a Windows 95/98/NT freeware and cost you nothing.  You can freely distribute this piece of
  software but are not allow to use it for commercial purpose.


	==========================================================
	            >>> Install / Quick Start <<<
	==========================================================

  1) Install

  - Unzip IgRing.zip to your hard drive.
  - DONE ! 

  2) Quick Start

  - Run "Iguana Ring.exe"
  - Fill in setup information if this are your first time.
  - Open a MIDI file by the "Load" function in [Midi Control].
  - Drag the slider in [Midi Control] to the point where you wish to start the MIDI playback.
  - Press "Play" in [Midi Control] to start recording.
  - IMPORTANT: If this is a multi-channel MIDI, you must ONLY select 1 channel to make the
    conversion successful.  You can do this by clikcing the checkboxs in [Channel Statistic].
  - Press "Stop" to halt recording.
  - The recorded MIDI will be shown in RTTTL of [Ringtone Preview].
  - Press "Listen" to playback your recorded ringtone.
  - If you are familiar with RTTTL format, you can edit RTTTL and "Listen" again.
  - Press "Post to Iguana Ring Gallery" to upload this ringtone to Iguana SMS home site.
  - Go to Iguana SMS home site at http://www.apic.com.sg.
  - Transmit the ringtone to a Nokia mobilephone online.


	==========================================================
                           >>> User Interface <<<
	==========================================================

  1) Midi Control

  - Slider Bar      : To set the starting point of recording (or conversion).
  - Load            : To load/open a Midi file.
  - Play            : To begin recording.
  - Stop            : Stop recording. Converted ringtone will be shown in Ringtone Preview RTTTL.
  - Mute On/Off     : To turn on/off all MIDI channel.

  2) Channel Statistic

  - You can turn on/off any of the 16 MIDI channel here. A checked channel is a turn on channel,
    otherwise, it is off.
  - Current Nokia mobilephone only support single channel ringtone, thus, make sure that only 1
    channel is selected before you start recording.

  3) Ringtone Preview

  - RTTTL           : The recorded ringtone is shown here. You can edit the content (in RTTTL 
                      format).
  - Sel Instrument  : Select an instrument to playback the recorded ringtone.
  - Listen          : Playback the recorded ringtone.
  - Post to...      : Post ringtone to Iguana Home Site.


	==========================================================
	            >>> Use Iguana Ring with Nokring <<<
	==========================================================

  Nokring - a Nokia Ring Tone Composer written by Jon Mostelo.  You can copy RTTTL from Iguana
  Musician to Nokring and vice versa. Nokring provide a Score interface for you to edit your
  ringtone.

  You should be able to download Nokring from http://members.tripod.com/~ringtones/.
  

	==========================================================
		  >>> Bugs Report / Feedbacks / Comments <<<
	==========================================================

  To submit a bug report, please include these information,

     Iguana Ring version       :
     Operating System          :
     Bug description           :
     Midi File                 : (attach as file)

  and send it to iguana@apic.com.sg

  Feedbacks and comments are also welcome, you can send it to iguana@apic.com.sg.



Have lots of fun,
Iguana WebMaster 20 JUN 2000
  
