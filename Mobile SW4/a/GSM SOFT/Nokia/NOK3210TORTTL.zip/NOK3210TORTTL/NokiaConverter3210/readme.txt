\ Nokring RTTTL to NOKIA 3210 Converter Version 1.5
\ Copyright (c) 1999 Justin Edmunds
\ =================================================
\ 
\ This software is free and may be used and distributed without payment. 
\ 
\ This software may be freely distributed subject to, but not limited to, 
\ the following terms: This software may not be sold or resold, distributed
\ as part of any commercial package, used in a commercial environment, used 
\ or distributed in support of a commercial service, or used or distributed 
\ to support any kind of profit-generating activity, even if it is being 
\ distributed freely.
\ 
\ If you would like to distribute this software as part of a distribution,
\ magazine, book, CD-ROM, etc. please contact the Author for permission.
\ 
\ All commercial use interests in this software should be directed to 
\ the Author, too.
\ 
\ THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT
\ THE SUITABILITY OF THE SOFTWARE.  THE AUTHOR SHALL NOT 
\ BE LIABLE FOR ANY DAMAGES SUFFERED BY ANYBODY AS A RESULT 
\ OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS 
\ DERIVATIVES.
\ 
\ (c) Justin Edmunds, 1999 (Sydney, Australia)
\ Email: jedmunds@bigfoot.com
\ WWW:   www.bigfoot.com/~jedmunds
\ 

Important imformation:
----------------------
Read the following!

What this program does!
----------------------
As of writing, I have been unable to send freely available ringing tones 
to my Nokia 3210.  This program has been created to fill this gap.

This program converts ringing tones in the Nokring RTTTL file format to 
the Nokia 3210 Composer format.  It also shows you the keypress sequence required
which you can simply type in without knowing how the composer feature works.

You will STILL need to type the ringing tone directly into the Composer in your phone, but
it will be very straightforward.

1. Requirements:
----------------
System: Windows 95 or Windows 98 or Windows NT 4
Hardware: PC
Nokia 3210 Cellular Phone
Nokring RTTTL data files (freely available on the web)

2. Installation:
----------------
-Remove any previous installed version with Start|Settings|Control-Panel|AddRemove Programs.
-Unzip the archive, run SETUP.EXE and follow the english installation instructions.

3. How to use:
--------------
Click on an RTTTL (Ringing Tone Text Transfer Language) file.  The converted
Nokia 3210 Composer format will be displayed in the window.

4. The Future
-------------------------------------------
-If there is enough interest I will be adding a tone playback facility.
-There has also been interest in the development of a .MID (MIDI) file 
 conversion feature to the Nokia 3210 format.
-A print and save  feature.

5. Limitations
--------------
The Nokia 3210 is more limited on ring tone features compared to other phones and 
therefore some tones won't work fully.

Be aware of the following:
1.  The 3210 has a 50 note/entry capacity.
2.  There are only three octaves not 4 like on some other phones.

6. Change History
-----------------
1.5 06/12/1999
	Fixed spurious 'Run-Time Error 52' bug - I think!
	Added link to Web page in Info box
1.4 24/11/1999
	Fixed keypresses bug.  Failed to display pauses.
	Added feature to cut and paste RTTTL/Nokring text from a web page 
	directly in the converter without loading a file.
1.3 22/11/1999
	Added feature to display tones in keypress sequences format.
	Now you only need to press the keys as displayed in the program
	in the order shown.
1.2 17/11/1999
	Added dotted note feature.
	Fixed note count bug 
		(previously reporting one less then the actual number of notes)
	Fixed # bug.
		(The # appeared after the note when it actually
		appears before the note in the composer window.)
	Changed user interface slightly.

1.1 29/10/1999 
	Registry bug fix

1.0 28/10/1999 
	Initial release


"Nokring" by John Mostelo is available for download on sites devoted to GSM ringtones.
Note that "Nokia" and Nokia's product names are trademarks of Nokia,
"Microsoft" and Microsofts's product names are trademarks of Microsoft.


