All for free only from :
-=http://gsm-cables.com=-
Why we give this for free???
Because you all should have it :-)
-=http://gsm-cables.com=-


Explanation (HOW TO):

Well just run setup.
After installing...
Each time you want to run the Program you have to use a dongle emulator.
Which is in this case called Alcatel_emmu.exe
So run Alcatel_emmu.exe go to the functions menu, deactivate :
Reset Keypro & Optimize Datas.
Go to load file open Be4s.kpe

Wait for error....

Go to function and Enable Emulator.

Go to Start Menu-Programs-Alcatel Eraser and Start Program VOILA!!!

Press Unlock to UNLOCK your phone :-) 

Supported versions 134,135,136 .
Version 137 will come soon, email us about this subject.


Regards,

	Alexander 
	email: alex@gsm-cables.com

