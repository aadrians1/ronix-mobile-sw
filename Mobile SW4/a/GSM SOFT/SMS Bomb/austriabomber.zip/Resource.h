//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SM Bomber.rc
//
#define IDD_MAIN                        101
#define IDI_ICON1                       103
#define ID_MAIN_NUMBER                  1002
#define ID_MAIN_MESSAGE                 1003
#define ID_MAIN_INTERVAL                1004
#define ID_MAIN_START                   1005
#define ID_MAIN_STOP                    1006
#define ID_MAIN_SENT                    1007
#define ID_MAIN_PROVIDER                1008
#define ID_MAIN_DELAY                   1009
#define ID_MAIN_DELAYTIME               1010
#define ID_MAIN_STATUS                  1011
#define ID_MAIN_HOWOFTEN                1012
#define ID_MAIN_HOMEPAGE                1013
#define ID_MAIN_EMAIL                   1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
