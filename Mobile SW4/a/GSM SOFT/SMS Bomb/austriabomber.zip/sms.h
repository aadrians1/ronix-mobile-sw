
/*******************************************************************************

   Short Message Service Library 1.1

   Copyright (c) Richard Hirner 2000, all rights reserved
   http://www.hirner.chello.at/richard/
   r.hirner@chello.at

*******************************************************************************/

#define SMS_COOKIE_FAILED    1
#define SMS_DONE             2
#define SMS_GETTING_COOKIE   3
#define SMS_MSG_TOO_LONG     4
#define SMS_NO_CONNECTION    5
#define SMS_NO_REQUEST       6
#define SMS_SENDING          7

typedef void (*SMSCALLBACKPROC)(int);

__declspec(dllexport) BOOL _stdcall SmsSend(const char *Provider, const char *PhoneNumber, const char *Message, SMSCALLBACKPROC smsCallback);
