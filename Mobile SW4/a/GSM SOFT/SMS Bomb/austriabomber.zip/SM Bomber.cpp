
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <wininet.h>
#pragma hdrstop
#include "resource.h"
#include "external/sms.h"

#define MAXMSGCHARS 280
#define USER_AGENT 0

const char AppName[] = "SM Bomber";
const char StartupMsg[] =
   "Short Message Bomber 1.2 (" __DATE__ " " __TIME__ ")\n"
   "Copyright (c) 2000 Richard Hirner, alle Rechte vorbehalten\n"
   "ICQ #40693229\n\n"
   "Stellen Sie sicher, dass eine Verbindung zum Internet besteht, und klicken Sie "
   "auf <OK>, um fortzufahren.";

HINTERNET hInternet;

HWND hMainDlg;
int MsgsSent = 0;

int Countdown = 0;
char Message[256];
int OrigMsgLen;
char PhoneNumber[64];
char Provider[12];

BOOL CALLBACK MainDlgProc(HWND, UINT, WPARAM, LPARAM);
void SendSM(DWORD);
void SetStatus(const char *);
void SMCallback(int);


BOOL CALLBACK MainDlgProc(HWND hDlg, UINT wMsg, WPARAM wParam, LPARAM)
{
   switch (wMsg) {
      case WM_CLOSE:
         EndDialog(hDlg, 0);
         break;
      case WM_COMMAND:
         switch (LOWORD(wParam)) {
            case ID_MAIN_EMAIL:
               ShellExecute(hDlg, "open", "mailto:r.hirner@gmx.at?subject=SM Bomber 1.1", 0, 0, SW_SHOW);
               break;
            case ID_MAIN_HOMEPAGE:
               ShellExecute(hDlg, "open", "http://www.hirner.chello.at/richard/", 0, 0, SW_SHOW);
               break;
            case ID_MAIN_START:
               if (SendDlgItemMessage(hDlg, ID_MAIN_DELAY, BM_GETCHECK, 0, 0) == BST_CHECKED) {
                  Countdown = GetDlgItemInt(hDlg, ID_MAIN_DELAYTIME, 0, FALSE);
                  SetTimer(hDlg, 2, 60000, 0);
                  SendMessage(hDlg, WM_TIMER, 2, 0);
                  EnableWindow(GetDlgItem(hDlg, ID_MAIN_START), FALSE);
               } else {
                  GetDlgItemText(hDlg, ID_MAIN_NUMBER, PhoneNumber, 63);
                  GetDlgItemText(hDlg, ID_MAIN_PROVIDER, Provider, 11);
                  GetDlgItemText(hDlg, ID_MAIN_MESSAGE, Message, 255);

                  OrigMsgLen = lstrlen(Message);
               
                  EnableWindow(GetDlgItem(hDlg, ID_MAIN_START), FALSE);
                  EnableWindow(GetDlgItem(hDlg, ID_MAIN_STOP), TRUE);

                  int Interval = GetDlgItemInt(hDlg, ID_MAIN_INTERVAL, 0, FALSE)*1000;
                  SetTimer(hDlg, 1, Interval, 0);
                  DWORD tid;
                  CreateThread(0, 0, (LPTHREAD_START_ROUTINE)SendSM, 0, 0, &tid);
               }
               break;
            case ID_MAIN_STOP:
               KillTimer(hDlg, 1);
               EnableWindow(GetDlgItem(hDlg, ID_MAIN_START), TRUE);
               EnableWindow(GetDlgItem(hDlg, ID_MAIN_STOP), FALSE);
               break;
         }
         break;
      case WM_INITDIALOG:
         hMainDlg = hDlg;
         SetDlgItemText(hDlg, ID_MAIN_PROVIDER, "676");
         SetDlgItemInt(hDlg, ID_MAIN_INTERVAL, 60, FALSE);
         break;
      case WM_TIMER:
         if (wParam == 2) {
            char s[64];
            wsprintf(s, "Wird in %i Minute(n) gestartet.", Countdown);
            SetStatus(s);
            if (!Countdown) {
               KillTimer(hDlg, 2);
               SendDlgItemMessage(hDlg, ID_MAIN_DELAY, BM_SETCHECK, BST_UNCHECKED, 0);
               SendMessage(hDlg, WM_COMMAND, ID_MAIN_START, 0);
            }
            Countdown--;
         } else {
            DWORD tid;
            CreateThread(0, 0, (LPTHREAD_START_ROUTINE)SendSM, 0, 0, &tid);
         }
         break;
      default:
         return FALSE;
   }
   return TRUE;
}


void SendSM(DWORD)
{
   SmsSend(Provider, PhoneNumber, Message, SMCallback);
}


void SetStatus(const char *NewStatus)
{
   SetDlgItemText(hMainDlg, ID_MAIN_STATUS, NewStatus);
}


void SMCallback(int wMsg)
{
   char *status;
   switch (wMsg) {
      case SMS_COOKIE_FAILED:
         status = "Das Cookie konnte nicht gelesen werden.";
         break;
      case SMS_DONE:
         status = "Die Kurzmitteilung wurde gesendet.";
         break;
      case SMS_GETTING_COOKIE:
         status = "Das Cookie wird gelesen.";
         break;
      case SMS_MSG_TOO_LONG:
         status = "Die Kurzmitteilung ist zu lang!";
         break;
      case SMS_NO_CONNECTION:
         status = "Die Serververbindung konnte nicht hergestellt werden.";
         break;
      case SMS_NO_REQUEST:
         status = "Die Anforderung konnte nicht formuliert werden.";
         break;
      case SMS_SENDING:
         status = "Die Kurzmitteilung wird gesendet.";
   }
   SetDlgItemText(hMainDlg, ID_MAIN_STATUS, status);
}


int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int)
{
   MessageBox(0, StartupMsg, AppName, MB_ICONINFORMATION | MB_OK);
   InternetAttemptConnect(0);
   hInternet = InternetOpen(AppName, INTERNET_OPEN_TYPE_PRECONFIG, 0, 0, 0);
   DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAIN), 0, MainDlgProc);
   InternetCloseHandle(hInternet);
   return 0;
}
