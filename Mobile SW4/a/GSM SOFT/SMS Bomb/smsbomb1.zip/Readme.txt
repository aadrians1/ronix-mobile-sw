SMS alpha und SMS + Bomber

Das Programm kann in einem beliebiges Verzeichnis abgelegt werden. 

Du kannst dir aussuchen, ob du die sms.dll und Mscomctl.ocx in das selbe oder in das 
Verzeichnis c:\windows\system\ .
Ladest Du dir mehrere Programme von mir runter, w�re es sinnvoll, die Dateien in das 
Verzeichnis c:\windows\system\ zu kopieren. So m�ssen die dll Dateien nur einmal 
"installiert" werden. 

Bei W�nschen oder Anregungen wende dich bitte an shorty1@aon.at  .


Shorty 2000