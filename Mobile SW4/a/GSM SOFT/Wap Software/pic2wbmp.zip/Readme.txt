
PIC2WBMP-ReadMe

Version 1.0
============================================================================


You are a WAP-developer or interested in WAP publishing? You need a tool to convert your images made with Adobe Photoshop or Macromedia Fireworks to the WAP-ready WBMP-format? We would like to help you with our freeware-tool pic2wbmp.

This little freeware-tool imports graphic files and saves them in WBMP-format (TYPE 0: B/W, Uncompressed Bitmap - WAP WAE Specification). WBMP is a graphics format used for example by mobile phones supporting the WAP-protocol.

How to convert graphics file?

Browse and select the file. You will see a preview of your image on-the-fly. Choose 'Save WBMP as' from the file menu. Note: WBMP image format extension is '.wbmp'.

You can also scale and adjust the intensity of the WBMP-file before saving the WBMP-file on your local hard disk.



You may use this wbmp-converter-tool for free. GINGCO New Media assumes no liability on accuracy, completeness or suitability for the program.

Please note: pic2wbmp requires Java Runtime Environment 1.1 (or later) for Mac or PC. You can download JRE 1.2.1 from Sun's JDK-Web site.


Starting pic2wbmp:
------------------
java -classpath .;pic2wbmp.zip;JimiProClasses.zip;%CLASSPATH% pic2wbmp

or use the batch file:

pic2wbmp.bat (windows)


Files:
------
pic2wbmp.zip - Class files for pic2wbmp (do not unzip)
JimiProClasses.zip - Class files for image I/O (do not unzip)
pic2wbmp.bat - Startup file for pic2wbmp (windows)
Readme.txt - This file
samples (directory) - Some images



If there are problems concerning the Java virtual machine please go to the JavaSoft weppage: http://java.sun.com. 


Copyright 1999, GINGCO New Media, 

mailto:wap@gingco-newmedia.de
http://wap.gingco.de
http://www.gingco-newmedia.de

All rights reserved.



HISTORY
=============================================================================

03.11.99 - version 1.0
--------
Now pic2wbmp can read/write wbmp images of any size.
New Menu Item: Save WBMP+WML -> produces simple wml card.

*****************************************************************************
* Note: Earlier versions of pic2wbmp (<1.0) produced a wrong encoding of wbmp
* images larger than 127 pixels (width or height).
*****************************************************************************

14.10.99 - version 0.7
--------
Choose to hide original image.
Flip image.
Invert image.

13.10.99 - version 0.6
--------
Added Menu Shortcuts.
Added Printing.
Choose to display wbmp with white or default (handy-green) background.
Filename suggestion in save dialog.

08.10.99 - version 0.5a
--------
Removed stupid bug when loading wbmp images. It occured since version 0.5.
Class files now zip-packed.

01.10.99 - version 0.5
--------
** Added Error Diffusion Algorithm **. It drastically improves quality of colorful images or photographs.
Now works correctly with Java 1.1.*.
Minor bug fixes.

29.09.99 - version 0.4
--------
Fixed bug when reading wbmp files (sometimes right edge of picture was scrambled).
File dialog now remembers last directory.
Slider instead of numeric intensity input.
Adding default file-extension.

27.09.99 - version 0.3
--------
Tool can now open WBMP files.

27.09.99 - version 0.2
--------
Added load/save support for the following image formats:
DIB, DDB, BMP, GIF, JPEG, PICT, PNG, PSD, TGA, TIFF, XBM, XPM, ICO, CUR, PCX.

24.09.99 - version 0.1
--------
First release at http://clients.gingco.de/wap.