Explanation (HOW TO):

Well just run setup.
After installing...
Each time you want to run the Program you have to use a dongle emulator.
Which is in this case called Alcatel_emmu.exe
So run Alcatel_emmu.exe go to the functions menu, deactivate :
Reset Keypro & Optimize Datas.
Go to load file open Be4s.kpe
I�� do �adowania pliku otworzy� Be4s.kpe

Wait for error....
czeka� do b�edu

Go to function and Enable Emulator.
I�c do funkcji i w��czyc Emulator

Go to Start Menu-Programs-Alcatel Eraser and Start Program VOILA!!!

Press Unlock to UNLOCK your phone :-) 

Supported versions 134,135,136 .
Version 137 will come soon, email us about this subject.


Regards,

--
Downloaded from Members Area of
GSM Traders Group (c) 1998-2001
http://gsm-technology.com
info@gsm-technology.com