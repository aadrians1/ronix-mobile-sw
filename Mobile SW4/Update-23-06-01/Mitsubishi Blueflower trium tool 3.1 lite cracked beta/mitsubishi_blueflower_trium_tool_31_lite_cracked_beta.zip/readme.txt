 This is Beta version no responsibility for results

-------------------------------------------------------------------

 Before making anything Backup EEPROM 
 
 If You get phone killed  :  
  1 Put it with unlocker form Salegk & Skoker in test mode
  2 Write EEPROM Back with normal Troky EEPROM READER/WRITER Back
    ( not with this program )
--------------------------------------------------------------------

What is cracked ? : Dongle Envelope 
What it brings  ? : Proggy Reads Phone, Writes and Reads EEPROM

I don't have locked Triums to test if it unlocks

If don't unlocks, send me a locked Trium for experiments ( He He )


send comments to memyselfi@hotbox.ru


and don't forget to visit main Page :

http://yuan.terrashare.com/password.html

BRGS Bobik / Bubaka / GSM_SUPPLY


P.S. 

The aim of this project was not crack it, but to revirgin telock
packed application. If Troky have compiled EXE as a pcode instead
of native code I would not even to try crack dongle envelope.

You have 5 days to test programm, cause Troky is a good guy
     







 
 
  
 
  

  