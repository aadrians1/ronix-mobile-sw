GA628 melody changer

melodies are written in the flash, so you will have to download
the flash from your phone, change it with melody changer and
upload it back with some flasher.

melody changer searches for melodies in the flash and writes
their location to the registry, because once you change them
there's no way to find them again and melody changer uses the
information in the registry. you should be aware of this if you
change the melodies and then delete the registry or try to use
melody changer at a friend's who doesn't have this entry. it's
best if you make a backup of your flash prior to any changes
with melody changer anyway.

tested firmware versions:
970716
980519
990113
990401

they all had melodies somewhere at $50000 to $60000 and that's
the only region melody changer searches by default. if for some
reason you have an odd version of the firmware and the melodies
can't be found you can change the search region in the Edit values.
the tones can also be corrected here if you feel I haven't hit the
right values.

for comments and questions ...

humble@subdimension.com



http://techgsm.prv.pl























































http://techgsm.prv.pl