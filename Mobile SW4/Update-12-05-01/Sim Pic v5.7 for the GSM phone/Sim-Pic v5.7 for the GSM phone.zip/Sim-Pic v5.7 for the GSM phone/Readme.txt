Sim-Pic v5.7 for the GSM phone / GoldWafer (PIC16F84 + 24C16) 
Includes A3A8-COMP128 algorithm!!!
Created by Ronny Stern (simpic@gmx.de)
http://simpic.tele-servizi.com
Date: 02.01.2001

Sim-Pic's COMP128 was based on the COMP128 C source engineered by
Marc Briceno, Ian Goldberg, and David Wagner.
Copyright 1998, All rights reserved.
http://www.scard.org/gsm

Fuses for Pic16F84:	OSC: 	XT
			PWRTE:	ON
			WDTE: 	OFF
			CP: 	ON

This code is not released for the public domain and it is STRICTLY FORBIDDEN
to distribute, modify or resell it. Please use it for educational purposes only!

