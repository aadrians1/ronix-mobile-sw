How to install:
copy *.vbx to \windows\system directory
copy *.dll to windows directory
that's it.

!!! Warning !!!
Be ware of some word processor like Word for windows and
WordPad, that change lines in printer port, if the Pro Pic
is turned on and you have a PIC on it, you can damage your
chip.

This is the seconf version of Pro Pic Programmer, if you
find any bug, please report it to me, if you'd like to
make sugestions or comments, just e-mail me.

**** Changes in V3.0 ***
A jumper J1 was added to enable/disable PIC 14000 VPP2
put the jumper to use PIC 14000, leave it open for others

**** Changes in V2.9 ***
12C5X bugs fixed, other devices added
small change in circuit, PCB and software to program PIC14000
using VPP2

**** Changes in V2.7 ***
Change ExtRc to IntRc in 12CXX

**** Changes in V2.5 ***
corrections for 12CXX and 16C55X

**** Changes in v2.4 ***
- PIC 14000 added
- Save HEX added
- Save and Load calibration added
- Circuit changed to accept 14000

**** changes in v2.3 ****
- 12C508 and 12C509 added
- 16C554, 16C556, 16C558 added

**** changes in v2.2 ****
- The circuit was changed, this version will work with
  the old circuit, but I recommend to change the circuit.
- A button was added when programming 16C84. The button
  erase the 16C84 memory.
- When programming 16C84 the program will not test for blank
  if you don't mark the new check box.
- New very easy way to register, please take a look.

**** changes in v2.1 ****
Some minor bugs corrected.
- Values of ID bigger then 3FFFh doesn't give error.
- You have the choice to write or not the EEData in 16C84.
- Before start writing the chip, the software check the time
  and date of the hex file, if the hex file is newer the the
  one in memory, it loads the file again.
- Was added a progression bar.

**** changes in v2.0 ****
The circuit was changed to support Vdd min and Vdd max, with
the aid of the program you need to adjust P1 to Vdd max, P2 to
Vdd min and P3 to Vdd prog, normaly 5V.
With this changes the Pro Pic programmer can be classified as
production programmer.         
If you don't want to build the optional part, the programmer
will work ok.
The Config menu was added the Production mode and Prototype mode
options.
You now have the choice to write or not the EE data in 16C84, the
ProPic read EE data starting at address 2100h in hex files.
If you have a 486 or up motherborad you need to put a 470pF
capacitor between RB7 and ground under the Textool.

Octavio

nogueira@mandic.com.br