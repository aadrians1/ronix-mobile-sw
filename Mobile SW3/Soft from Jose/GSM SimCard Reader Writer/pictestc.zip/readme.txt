Test card for motorola GSM phones. 

Created by Ronny Stern (simapic@hotmail.com) and distributed from 
Janus Pages on Mot GSM (http://www.tele-servizi.com/Janus/motpages.html)

The code is meant for ISO 7816 sized PIC 16F84 or 16C84 wafer cards.

Fuses are: 
		OSC: 	XT
		WDOG: 	Off
		PUT:	Dis
		CP: 	Don't care

This code is released for the public domain and it is STRICTLY FORBIDDEN
to charge anything for it.

For documentation on the test card, look at Janus page.

