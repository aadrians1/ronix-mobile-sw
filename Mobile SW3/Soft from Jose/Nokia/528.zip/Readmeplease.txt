Free download from http://www.gsmtop.net


 1.You have to open the phone (without back cover)
 2.Phone must be on
 3.Conect m-bus cable to phone
 4.Run nokia.exe to read phone
 5.On eepron 24c16 conect scl and test 6 and 7(phone stil on)
 

             ---      conect 6 and 7
      *-5---6---7--8-*    
      *              *
      *    24c16     *
      *              *
      * *            *
      *-1---2---3--4-*




 6.Read phone again (you will see funny imei)
 7.Push unlock button 5 times
 8.Remove conect on eepron 6 and 7 scl and test
 9.Push unlock button again
10.And viola-phone is unlocked WORKS 100% ON ALL LOCKS.
