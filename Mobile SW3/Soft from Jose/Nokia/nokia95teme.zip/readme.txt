Installing instructions
for the Nokia Style & Design Desktop Theme for Windows 95 v1.0

* The theme files (all except the .sys and .scr -files)

Copy all files that start with 'nokia for win95...' to the 
Themes-folder in Plus!-folder (e.g. c:\program files\plus!\themes).
Change the theme the normal way (Control panel->Desktop themes
->Theme->nokia for win95).

* The startup and shutdown pictures

Copy logo.sys to c:\ (or to the root directory of the drive your
windows is installed to). Copy logow.sys and logos.sys to your
windows directory. Take backup copies of the three files to be
replaced, if you want to use them again later. The files are
actually 320x400 bitmap files (.bmp) with a different extension.

* Tips

Turn off the sounds. They are quite annoying. (but can you use
any other sounds?! No... I guess :-)

* Contact

Nokia Style & Design
http://cs.joensuu.fi/~tuohimaa/nokia
tuohimaa@cs.joensuu.fi