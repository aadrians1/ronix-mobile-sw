**********************************************************************
INSTALATION:
**********************************************************************
1.If you dont have 'Nokia Flasher' on your computer:

Extract files from Flasher.zip to folder C:\Flasher,from Nk_files.zip to folder C:\Nk_files and from Vygishell.zip to folder C:\Vygishell.

2.If you have 'Nokia Flasher':

Extract files from Vygishell.zip to folder C:\Vygishell


