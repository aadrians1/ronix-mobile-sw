Oxygen Phone Manager for Nokia 71**/62** v.1.9.2
================================================

  The Oxygen Phone Manager for Nokia 71**/62** works under Microsoft Windows'95,
  '98, Windows NT, Windows ME and Windows 2000 operating systems family only and
  supports DAU-9P and DLR-3(P) cables and infrared port using IrDA stack.

  This version is shareware. To register visit http://www.oxygensoftware.com

Last revision date: July 9, 2001.

PLEASE FOLLOW THE INSTRUCTIONS PROVIDED IN THE INSTALLATION SECTION!

TABLE OF CONTENTS
-----------------
Overview
History
Warranty disclaimer
Installation
Registration
Price
Copyright Notes
Contact

Overview
--------
  Oxygen Phone Manager for Nokia 71**/62** program allows you to communicate 
  with your Nokia 7110, 7160, 7190, 6210 or 6250 GSM phone using PC. In this
  version, connection is established via IrDA or DAU-9P or DLR-3 cable. You can
  read, edit, store, load and rewrite your phonebook, import data from
  Microsoft Outlook or Lotus Notes and export the phonebook back to Outlook or
  Lotus Notes. You can work with calendar as well. The program also includes
  advanced SMS manager, allowing you to send, receive, export, move between
  folders, find, print, attach pictures, reply and forward short messages using
  SMS. Oxygen Phone Manager has full unicode support. You can also manage WAP
  bookmarks, Profiles and edit caller group logos using powerful logo editor.
  You will learn how to connect your mobile phone to a PC.
  The program works under Microsoft Windows'95, 98, Windows NT, Windows ME and
  Windows 2000 operating systems family.
  Registered version performs full phonebook, calendar and profiles rewriting,
  doesn't add 'www.oxygensoftware.com' to every SMS message being sent and goes
  for $39 for personal version.

  The author disclaims all warranties as to this software, whether express
  or implied, including without limitation any implied warranties of
  merchantability or fitness for a particular purpose. Use under your own
  responsibility, but comments (even critique) in English (or in Russian)
  are welcome.

History
-------
  March,      1, 2000:  Version 1.0.
  June,      13, 2000:  Version 1.4.
  July,       3, 2000:  Version 1.5.
  July,      29, 2000:  Version 1.5.1.
  August,    11, 2000:  Version 1.5.2.
  August,    23, 2000:  Version 1.5.3.
  August,    31, 2000:  Version 1.5.4.
  September,  3, 2000:  Version 1.5.5.
  September, 15, 2000:  Version 1.6.
  September, 19, 2000:  Version 1.6.1.
  September, 21, 2000:  Version 1.6.2.
  October,    4, 2000:  Version 1.6.3.
  October,   25, 2000:  Version 1.6.4.
  November,   4, 2000:  Version 1.7beta.
  November,  14, 2000:  Version 1.7beta2.
  November,  24, 2000:  Version 1.7beta3.
  November,  29, 2000:  Version 1.7.
  December,   8, 2000:  Version 1.7.1.
  December,  22, 2000:  Version 1.7.2.
  January,   10, 2001:  Version 1.7.3.
  March,      1, 2001:  Version 1.9.
  March,     20, 2001:  Version 1.9.1.
  July,       9, 2001:  Version 1.9.2.

Warranty disclaimer
-------------------
  THIS SOFTWARE IS PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND. TO THE MAXIMUM
  EXTENT PERMITTED BY APPLICABLE LAW, OXYGEN FURTHER DISCLAIMS ALL
  WARRANTIES, INCLUDING WITHOUT LIMITATION ANY IMPLIED WARRANTIES
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT. THE
  ENTIRE RISK ARISING OUT OF THE USE OR PERFORMANCE OF THE PRODUCT AND
  DOCUMENTATION REMAINS WITH RECIPIENT. TO THE MAXIMUM EXTENT PERMITTED BY
  APPLICABLE LAW, IN NO EVENT SHALL OXYGEN BE LIABLE FOR ANY
  CONSEQUENTIAL, INCIDENTAL, DIRECT, INDIRECT, SPECIAL, PUNITIVE, OR OTHER
  DAMAGES WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF
  BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR
  OTHER PECUNIARY LOSS) ARISING OUT OF THIS AGREEMENT OR THE USE OF OR
  INABILITY TO USE THE PRODUCT, EVEN IF OXYGEN HAS BEEN ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGES.


Installation
------------
  Run Nok7110.exe from the command prompt or Explorer. Follow the installation
  program directions.

Registration
------------
  This product is released as shareware.

  What you get if register:
   * No mentions about unregistered version.
   * All next versions for FREE.
   * Whole phonebook is copied to phone.
   * Whole calendar is copied to phone.
   * Extra advertising string isn't added to each SMS message.
   * Information about upgrades of the program.
   * A warm fuzzy feeling that you did the right thing.
   * You'll support good software & provide more incentives to make it even 
     better.

  To register online, visit:
  http://www.oxygensoftware.com or http://www.oxygensoftware.co.uk

Price
-----
  Licensing for Oxygen Phonebook Manager for Nokia 71**/62** is as follows:

 ---------------------------------------------------------------------------- 
 |License type|Personal|Business|For-profit|Multiple SMS|   Phones     |Price|
 |            |  use   |  use   |   use    | recipients |   allowed    |     |
 -----------------------------------------------------------------------------
 |  Personal  |  Yes   |  No    |   No     |    No      |       2      | $39 |
 -----------------------------------------------------------------------------
 |  Business  |  Yes   |  Yes   |   No     |    Yes     |       4      | $59 |
 -----------------------------------------------------------------------------
 | Commercial |  Yes   |  Yes   |   Yes    |    Yes     |      10      | $89 |
 -----------------------------------------------------------------------------
 | 5 Business |  Yes   |  Yes   |   Yes    |    Yes     |      20      | $179|
 -----------------------------------------------------------------------------
 |10 Business |  Yes   |  Yes   |   Yes    |    Yes     |      40      | $329|
 -----------------------------------------------------------------------------
 |25 Business |  Yes   |  Yes   |   Yes    |    Yes     |     100      | $799|
 -----------------------------------------------------------------------------
 |50 Business |  Yes   |  Yes   |   Yes    |    Yes     |     200      |$1399|
 -----------------------------------------------------------------------------
 
  You will receive a registration key(s) via email.

Copyright Notes
---------------
  Copyright (C) 2000,2001 Oxygen Software

  Windows'95, 98, Windows NT, Windows ME and Windows 2000 are registered
  trademarks of Microsoft Corp.

  All other trademarks are owned by their respective companies.

Contact
-------
  Oxygen Software web site: http://www.oxygensoftware.com
  Oxygen Software UK web site: http://www.oxygensoftware.co.uk
  Oxygen Software Russia web site: http://www.oxygensoftware.ru

  Oxygen Software contact mail address: nokia@oxygensoftware.com


