Copy files to windows\system
you read and write system.ini