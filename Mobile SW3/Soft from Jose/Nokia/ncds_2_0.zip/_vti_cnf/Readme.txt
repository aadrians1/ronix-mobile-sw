vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|29 Jun 1998 13:56:52 -0000
vti_extenderversion:SR|4.0.2.2717
