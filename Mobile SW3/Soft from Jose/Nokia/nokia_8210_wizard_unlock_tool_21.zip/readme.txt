Installation Instructions:
To Install this program, first install a working copy of WinTesla 6.10, install all of the dongles and files for the 8210 and 8850 phones. Once done just copy wiz8210v2.exe into your WinTesla directory and run by double clicking the file from Windows Explorer.

Revision Notes:

2.1 - Security code can now be changed as well as viewed, and IMEI changing now works on 8850 properly.

2.0 - Support for the 8850 Phone, and a new look interface with colourful scheme. Now for WinTesla 6.10.

1.2 - Added Netmonitor Support

1.1 - The users security code can now be viewed

1.0 - Now stable and allows user to edit the IMEI (visual only)

0.9 - Fixed a few bugs and added the IMEI to the display, now working on all phones.

0.8 - First Release very buggy, only working on some phones.
