This solution is tested by me on

5110 ver. 5.28
3210 ver. 5.31