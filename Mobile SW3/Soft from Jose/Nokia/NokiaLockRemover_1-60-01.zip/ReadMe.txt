If you are missing some DLLs, you can download full instalation on www.volny.cz/unlock/download.html

Read Info after pressing on "Info" button.