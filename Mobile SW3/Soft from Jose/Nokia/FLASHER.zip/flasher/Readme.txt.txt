Unzip this zip file to c:\
It creates flasher and nk_files directory automatically.
Otherwise program doesn't work.

------------------
Regards
KaToT

http://www.gsmhall.com