PC Suite for Nokia 8210
(c) 1999 Nokia Mobile Phones. All rights reserved.

=================================================================
TABLE OF CONTENTS (README.TXT)
=================================================================

1. Introduction
2. Abbreviations used in this document
3. System requirements
4. Last minute additions and changes to the user documentation
5. Compatibility notes
6. Other Information

=================================================================
1.  INTRODUCTION
=================================================================

This document provides information to help you properly run 
PC Suite for Nokia 8210.

It deals with last minute additions and changes to the user
documentation as well as compatibility issues and possible 
problem causes and is intended to be read prior to the 
installation of PC Suite for Nokia 8210.

For a more detailed description on how to deal with certain
problems that you might encounter, please refer to the 
troubleshooting file TROUBLESHOOTING.TXT


=================================================================
2.  ABBREVIATIONS USED IN THIS DOCUMENT
=================================================================

bps		Bits per second
MB		Megabyte
MHz		Megahertz
RAM		Random Access Memory
SIM		Subscriber Identification Module
UART		Universal Asynchronous Receiver/Transmitter
IrDA		Infrared Data Association

=================================================================
3. SYSTEM REQUIREMENTS
=================================================================

To install and run PC Suite for Nokia 8210, you need the 
following:

  * Personal Computer with a Pentium 60 MHz processor or higher
  * Windows 95/98 operating system
  * At least 9 MB of free hard disk space
  * 8 MB of RAM (recommended)
  

=================================================================
4. LAST MINUTE ADDITIONS AND CHANGES TO THE USER DOCUMENTATION
=================================================================

4.1  How to transfer contacts information between phones

SIM cards from different network operators might support
different name and number lengths. When transferring entries from
one SIM to another, length reductions might become necessary
if the two SIMs support different name and number lengths. 

-----------------------------------------------------------------

4.11  Between Nokia 6110 and Nokia 8210 

This section describes how to transfer the contacts information
from Nokia 6110 phone (Phone 1) to Nokia 8210 phone (Phone 2). 

1.  Connect Phone 1 to the computer and start Nokia Data Suite
    2.0.
2.  Read the "Contacts Directory". 
3.  Save the Contacts Directory to the PC, using "Export
    To File" command.
4.  Close Nokia Data Suite 2.0.
5.  Open the PC Suite for Nokia 8210 and connect Phone 2. 
    Wait until the PC Suite has recognised that phone is 
    connected.
6.  Open the Contacts Directory of PC Suite for Nokia 8210.
7.  Open the file saved in step 3. using "Import From File" 
    command.
8.  Save the Contacts Directory to the phone, using "Save To
    Phone" command (PC Suite for Nokia 8210 will inform you if 
    shortening of entries is necessary.)

-----------------------------------------------------------------

4.12  Between phone memory and SIM memory

This section describes how to transfer entries from the phone
memory to the SIM-memory.

1.  Connect your phone to the computer and start PC Suite for 
    Nokia 8210.
2.  Read the "Contacts Directory"
3.  Mark the phone memory (B) entries that you would like to
    transfer to the SIM-memory (A).
4.  Use the command "Change memory type" from the "Edit" menu. 
    (PC Suite for Nokia 8210 will inform you if shortening of 
    entries is necessary.)
5.  Save the Contacts Directory to the phone, using the "Save To
    Phone" command.


=================================================================
5. COMPATIBILITY NOTES
=================================================================


5.1  Applications
 
Remember to specify the "Nokia 8210" modem to be used in all data 
and fax applications.

If you intend to use both Nokia CellularWare and PC Suite for 
Nokia 8210, ensure that these applications do not use the same 
physical communication port.

It is recommended to use "Zmodem" as the default transfer
protocol.

-----------------------------------------------------------------
 
5.2  Phone hardware/software

PC Suite for Nokia 8210 is intended to be used with the Nokia 8210
phones and IrDA connection. PC Suite for Nokia 8210 does not work 
with phones other than the ones specified.

Certain cellular networks do not support 7-bit data calls and
connection problems may occur if applications have been 
configured for 7-bit use.

The default data transfer speed is 9600 bps. Configuring 
applications to use transfer speeds other than the default value
may result in data transfer problems, unless the SIM has been
configured to support them.

If you are using Nokia 8210 for data communications make sure that
PC Suite for Nokia 8210 user interface is not running.

Please remember that PC Suite for Nokia 8210 is fully functional only 
after it has recognised the presence of a powered-on phone. This 
process may take a few seconds and as soon as the RF and battery-
level indication bars appear in the PC Suite for Nokia 8210 Monitor, 
full functionality has been attained.

-----------------------------------------------------------------

5.3 Note about CAPI

If any problems occur with CAPI, make sure that you are using
the latest version of it. The latest version of CAPI is available
in Forum Nokia web site at www.forum.nokia.com.

=================================================================
6. OTHER INFORMATION
=================================================================

More information about this product can be found from web pages 
WWW.FORUM.NOKIA.COM or WWW.NOKIA.COM. You can also register 
yourself to the Club Nokia from WWW.CLUB.NOKIA.COM.

-----------------------------------------------------------------

NOKIA is a trademark of Nokia Corporation.

MS-DOS is a trademark of Microsoft Corporation.

Windows 95 and Windows 98 are registered trademarks
of Microsoft Corporation.

Other products may be trademarks or registered trademarks of
their respective manufacturers.

(c) 1999 Nokia Mobile Phones. All rights reserved.

Nokia Mobile Phones operates on a policy of continuous improvement.
Therefore we reserve the right to make changes and improvements
to any of the products described in this guide without prior 
notice.

Nokia Mobile Phones is not responsible for any loss of data,
income or any consequential damage howsoever caused.
