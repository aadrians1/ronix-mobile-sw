*********************
*Nokia X v1.7       *
*      by Liam2000  *
*********************

Last Update: 14/02/2001

Website: www.rallypt.com/gsm/
Email: Liam2000@netc.pt

**************************
Just run c:\Flasher\Nx.exe
**************************


THIS SOFTWARE SUCKS, BUT IS MINNE! :)

History:

v1.0 - The first version that I give to the users, suports almost all versions (3310 4.06 100% working)

v1.1 - Simplified the choose of Flash

v1.2 - 6210 4.27 added, 6210 3.01 working 100%

v1.3 - Support for Backup Files added

v1.4 - Some bugs fixed

v1.5 - Some bugs fixed, new boot suport, 6210 3.74 working 100%, 3310 4.18 working 100%

v1.6 - Some versions and bugs fixed, and i think that all the 6210 are working

v1.7 - Automatic process implemented :) (Thanks to DarkTelecom), Loaders Table implemented, I think all the versions are working


Thanks to:

DarkTelecom
CRE8OR
Phantom
Rally
Candlestick
BGTGSM
BrAiNnDeAd
MisterMister