Version 0.3b.

If your imei is: 52-1111111111012345678 then enter: 01234567
to programm. 9 numbers without last one, just 8 numbers.

This proggy is very simpe in use, just enter IMEI number and press
ENTER. You will get the code. To remove simlock, power on the phone
and type: *#7465625*32*12345678#, 7465625 means SIMLOCK :) and 
12345678 is number that you have generated.
Thats all.


Author of this prog takes no responsibility for using this programm.


For more hot gsm progs and more... http://gsm.iq.pl

YagoDa
yagoda@supergsm.prv.pl
http://gsm.iq.pl
