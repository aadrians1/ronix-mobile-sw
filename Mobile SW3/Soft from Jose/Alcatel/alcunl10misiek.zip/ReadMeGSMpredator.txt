From Magupredator  http;//welcome.to/gsmpredator
###              ###                ###                       #######              ###         ## 
  ####            ####               ####                     ###########             ##        ##  
  ####            ####               ####                   ####      ####            ###       ##  
  ## #            # ##               #  ##                 ###          ###            ##      ##   
  ## ##          ## ##              ##  ##                ###             ##           ##      ##   
  ## ##          ## ##              ##   ##               ##                            ##    ##    
  ##  ##        ##  ##             ##    ##              ###                            ##    ##    
  ##  ##        ##  ##             ##    ##              ##                              ##  ##     
  ##   ##      ##   ##            ##      ##             ##                              ##  ##     
  ##   ##      ##   ##            ##      ##             ##                               ####      
  ##   ##      ##   ##            ##       ##            ##      ############             ####      
  ##    ##    ##    ##           ############            ##      ############              ##       
  ##    ##    ##    ##           ############            ###               ##              ##       
  ##     ##  ##     ##          ###         ##            ##              ##               ##       
  ##     ##  ##     ##          ##          ##            ###             ##               ##       
  ##      ####      ##         ###           ##            ###          ###                ##       
  ##      ####      ##         ##            ##             ####      ####                 ##       
  ##      ####      ##         ##            ##              ############                  ##       
  ##       ##       ##        ###             ##                ######                     ##       
  #                       #                          
                                            #                       #                          
                                                 #                       #                          
                                                 #                       #                          
 #  ###          # #         ###            ###  #          ###  #     #####        ###          # #
 # #####         ###       ######         ###### #         ##### #     #####       #####         ###
 ###   ##        ##        ##   ##        ##   ###        ##   ###       #        ##   ##        ## 
 ##     ##       #        ##     ##      ##     ##       ##     ##       #       ##     ##       #  
 #       #       #        #       #      #       #       #       #       #       #       #       #  
 #       #       #        #########      #       #       #       #       #       #       #       #  
 #       #       #        #########      #       #       #       #       #       #       #       #  
 #       #       #        #              #       #       #       #       #       #       #       #  
 ##     ##       #        ##             ##     ##       ##     ##       #       ##     ##       #  
 ###   ##        #         ##    ##       ##   ###        ##   ###       #        ##   ##        #  
 # ######        #          ######         ##### #        ###### #       #         #####         #  
 #  ###          #           ####           ###  #          ###  #       #          ###          #  
 #                                                                                                  
 #                                                                                                  
 #If you wish BUY  NEW  700 MB CD with GSMunlocking software please send E-mail
                            predattor@email.com

 Ukoliko zelite  da kupite  NOVI 700MB CD sa programima za dekodiranje posaljite nam E-mail
   			Price/Cena     $30    
    OURS links:  hack software   http://www.geocities.com/magadonny/hack.html
    Nasi linkovi   FREE PORNO http://www.geocities.com/magadonny/porn1.htm
                          GSMunlocking  http:welcome.to/magypredator                                                           


password:  misiek

If you need CD with unlocking software 700 MB  write me. Price is ONLY  $30 .
