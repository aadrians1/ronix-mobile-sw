COMMTRAP v1.97 (Beta)	(981021)

This is a Beta only!!! It is not yet complete!

Remember if you have not got the Microsoft ActiveX Communications Control (MSCOMM32.OCX) installed,
then copy this to c:\winnt\system32 or (c:\windows\system) and then click Start, Run... and type:
	regsvr32 mscomm32.ocx
and click OK.

Then just run the program from a suitable directory (eg. c:\commtrap).

To use:

To trap S-Hex files from EMMA, etc., first connect two serial ports together using a crossed modem
cable! These ports can be on the same PC or on two different PC's. The cable needs only three wires:
GND to GND, TX to RX and RX to TX. Then run a program such as EMMA flash utility on one COM port and
then click Connect... in CommTrap to select the 2nd serial port. Then load a script such as
Em Flash 6xx.txt, Start EMMA, and click ON! Note during the S-Hex transfer you'll see EMMA's Progress
Bar but CommTrap will be too busy to respond - if you cancel EMMA, then CommTrap will eventually stop
too.

Otherwise connect PC to phone and use CommTrap to flash phone, etc.

Enjoy and please comment!

Regards
Anthony
