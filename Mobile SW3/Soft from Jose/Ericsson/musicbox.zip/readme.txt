ERICSSON GH688/788 MUSICBOX 1.0b3 - Cosmos Software
---------------------------------------------------

So.. You're tired of pressing those buttons on your cellular? Well, here's the solution.. The GH688/788 Musicbox! ;-) Here you can copy&paste from webpages directly into the editfield and listen to the music before you use it on your phone... very handy..

As you can see this is still a beta release, and a new improved version will be available soon.

If you find any bugs, please mail me at cosmos@nano.no and describe the problem.


Known bugs:
-----------
 - The temp$$$.wav and note$$$.wav files are not created in some cases, and that means no sound..
 - I removed the buggy "click-removal" routine, but now the sample "clicks" sometimes..
 - The sound-routines are to slow, I need to look into the DirectSound thing to make it faster i think..

What's coming in next version?
------------------------------

 - A "Program-your-phone-easy" function ;-)


History:
--------

 1.0b1
 -----
  - First very lame release

 1.0b2
 -----
  - Changed name ;-)
  - New interface
  - Many bugs removed
  - Optimized the sound-generate routine a bit
  - It is now possible to save the songs for later usage (Presets)

 1.0b3
 -----
  - Keypad now works
  - Added some buttons to the interface
  - Some bugs was eliminated
  - New sounds (should be more accurate now)


If you have any suggestions, improvements etc feel free to drop me a mail at cosmos@nano.no


The Author:
-----------

Espen Grimsgaard
Cosmos Software
cosmos@nano.no
