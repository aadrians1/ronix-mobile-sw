#define frmMain        1000
#define fldMainContent 1001
#define btnMainInstall 1002
#define btnMainFetch   1003
#define btnMainPlay    1004
#define lblMainStatus  1005
#define gdgMainGraphic 1006
#define btnMainSwitch  1007
#define btnMainL       1008
#define btnMainR       1009

#define strMainHelp 1000

#define frmErrorAlert 1100



#define mnuMainMenu  10000
#define mnuMainUndo 10000
#define mnuMainCut 10001
#define mnuMainCopy 10002
#define mnuMainPaste 10003
#define mnuMainSelectAll 10004
#define mnuMainKeyboard 10006
#define mnuMainGraffiti 10007


// There must not be any gaps in the following sequence
#define gBitmap 0
#define sharpBitmap 1
#define flatBitmap 2
#define shUpBitmap 3
#define shDnBitmap 4
#define lnUpBitmap 5
#define lnDnBitmap 6
#define restBitmap 7
#define normalBitmap 8

#define BITMAPS 9
