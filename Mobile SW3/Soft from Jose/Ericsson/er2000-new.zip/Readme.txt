An update of Er2000 by Deezel to recognize the new T10's
Updated by Deezel