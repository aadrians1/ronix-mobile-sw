Philips Flash Download Software Readme
--------------------------------------
E-Mail: MyKy@163.net MyKy@FM365.com
--------------------------------------
Flash Index:

  13083600.CLA     128. 138. 168. 188
  48103112.CLA     828
  52300822.CLA     838
  58080100.CLA     878. 929. 939
  68000307.CLA     898 Best Version
  68000311.CLA     898
  89034245.CLA     989
  
--------------------------------------
Project Index:

  B52 NF Softwares  838
  B52 NF Languages  828
  B52 DB            898
  C12               128. 138
  C13 DB            168. 188
  X15 ( 5085 )      929
  X15 ( 5087 )      939
  X16 DB            989
  X16 DB - WAP
  G2K
  V2O
  
---------------------------------------
Thanks MyKy Aug 5, 2000