***********************************************************************
***********************************************************************
** Hello							     **
** This is partial flash unlocker for Siemens A3x V11,13,19,20,23    **
** Just check software version on Your phone (*#06# + left long key) **
** than connect Your gsm to COM1 (edit SWUP.ini for COM2) using      **
** Siemens data cabel, than choice 1,2,...etc.                       **
** After that on screen You will get:                                **
**                                                                   **
**   SIEMENS AG  SWUP  SoftWareUpdateProgram V1.91  Sep  6 2000 23:23**
**   Ini-FILE: .\SWUP.INI					     **
**   software-update under Windows on your own risk !!!              **
**   unlock.sw1 from 10.11.00 at 13:07:16 will be updated            **
**   tested:  100%                                                   **
**   trying to connect to mobile with EGold-Boot-Strap-Loader        **
**                                                                   **
** After that push red key and after couple seconds Your phone will  **
** be UNLOCKED.                                                      **
**                                                                   **
** best regards.                                                     **
**   swand_kc@yahoo.com                                              **
**                                                                   **
***********************************************************************
***********************************************************************
















