MyPhone 1.3 - readme.txt

Copyright (c) by Collin R. Mulliner

website: www.mulliner.org/myphone/
email:   palm@mulliner.org

FAQ: www.mulliner.org/palm/myphone/faq.php3

- A nice converter for Windows will come soon, until this you can use the
  commandline version.
- You can also convert your logos and midis online at the MyPhone website !

files:
	myphone.prc	-	the program file (install this to your Palm)
	readme.txt	-	the file you are reading right now
	logos/		-	the demo logos
	midis/		-	the demo midis
	2pdb/		-	the converter program including source


have fun ... Collin
