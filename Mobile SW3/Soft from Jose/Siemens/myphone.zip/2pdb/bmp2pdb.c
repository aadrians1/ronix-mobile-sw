/* ------------------------------------------------------------
bmp2pdb Copyright (c) by Collin R. Mulliner
version 1.4 - June 17. 2000

email: palm@mulliner.org
www: www.mulliner.org/palm
------------------------------------------------------------ */

#include <stdio.h>

void write_data(FILE *out, FILE *in);
void write_rec_header(FILE *fp);
void make_offset(int to, char oo[]);
void write_pdb_header(FILE *fp, char name[]);

int main(int argc, char *argv[])
{
	FILE *pdb_f;
	FILE *bmp_f;


	if (argc != 4) {
#ifdef BMP
		printf(	"bmp2pdb Copyright (c) by Collin R. Mulliner\n"\
			"Version 1.4 June 17. 2000\n"\
			"EMail: palm@mulliner.org.de WWW: "\
			"www.mulliner.org/palm\n\n"\
			"Syntax:	bmp2pdb <filename.bmp> <filename.pdb>"\
			" \"<description>\"\n\n"\
			"Supported BMPs:\n"\
			"S25:\n"\
			"\tSize: 97x26 (minimum)\n"\
			"\tColors: 1 bpp (b/w), 4 bpp (16 colors), 8 bpp (256 colors) - only 4\n\tcolors will be used - "\
			"red, green, blue, no color (background)\n"\
			"S35i:\n"\
			"\tSize: 101x43 (size may change this is the max. size)\n"\
			"\tColors: 1 bpp (b/w) all colors will work (will be converted to b/w)\n"\
			"C35/M35:\n"\
			"\tSize: 101x21\n"\
			"\tColors: 1 bpp (b/w)\n"\
			"\nAll BMP must be uncompressed !\n\n"\
			"Example:\n"\
			"bmp2pdb homer.bmp homer.pdb \"Homer J. Simpson\"\n\n");
#endif
#ifdef MIDI
		printf(	"midi2pdb Copyright (c) by Collin R. Mulliner\n"\
			"Version 1.3 June 17. 2000\n"\
			"EMail: palm@mulliner.org.de WWW: "\
			"www.mulliner.org/palm\n\n"\
			"Syntax:	midi2pdb <filename.mid> <filename.pdb>"\
			" \"<description>\"\n\n"\
			"Only one track midi's will work on your phone !\n\n"\
			"Example:\n"\
			"midi2pdb ring.mid ring.pdb \"My Ring Tone\"\n\n");
#endif

		return(1);
	}

	if ((bmp_f = fopen(argv[1], "rb")) == NULL) {
		return(1);
	}
	if ((pdb_f = fopen(argv[2], "wb")) == NULL) {
		return(1);
	}

	write_pdb_header(pdb_f, argv[3]);
	write_rec_header(pdb_f);

	write_data(pdb_f, bmp_f);

	fclose(pdb_f);
	fclose(bmp_f);

	return(0);
}
/* ------------------------------------------------------------
Write the data
------------------------------------------------------------ */
void write_data(FILE *out, FILE *in)
{
	unsigned char c;

	do {
		c = fgetc(in);
		fputc(c, out);
	} while (feof(in) == 0);
}
/* -------------------------------------------------------------
Write the record offset(s)
------------------------------------------------------------- */
void write_rec_header(FILE *fp)
{
	int new_offset;
	unsigned char rec_number;
	unsigned char offset_out[4];
	int i;


	rec_number = 0;
	new_offset = 78 + (1 * 8);	// 1 record
	make_offset(new_offset, offset_out);

	for (i = 0; i < 4; i++) {
		fputc(offset_out[i], fp);
	}

	fputc(0x40, fp);
	fputc(0x6F, fp);
	fputc(0x80, fp);
	fputc(rec_number, fp);
}
/* -------------------------------------------------------------
Calculate the offset
------------------------------------------------------------- */
void make_offset(int to, char oo[])
{
	int z3, zcc, i;

	for (i = 0; i < 3; i++) { oo[i] = '\x00'; }

	if (to < 256) {
		oo[3] = to;
	}
	else if (to > 255 && to < 65535) {
		z3 = to;
		zcc = z3 / 256;
		oo[3] = to - (256 * zcc);
		oo[2] = zcc;
	}
}
/* -------------------------------------------------------------
The pdb Header without the Record headers is 78 Bytes in size
------------------------------------------------------------- */
void write_pdb_header(FILE *fp, char name[])
{
	int i;
	char db_name[33];

	for (i = 0; i < 32; i++) { db_name[i] = '\0'; }

	strncpy(db_name, name, 32);

	for (i = 0; i < 32; i++) {
		fputc(db_name[i], fp);
	}

	fputc(0x00, fp);
	fputc(0x00, fp);
	//	the flags
	fputc(0x00, fp);
	fputc(0x00, fp);
	//	the version
	fputc(0x06, fp);
	fputc(0xD1, fp);
	fputc(0x44, fp);
	fputc(0xAE, fp);
	//	the creation time
	fputc(0x06, fp);
	fputc(0xD1, fp);
	fputc(0x44, fp);
	fputc(0xAE, fp);
	//	the modifi time
	fputc(0x00, fp);
	fputc(0x00, fp);
	fputc(0x00, fp);
	fputc(0x00, fp);
	//	the backup time
	fputc(0x00, fp);
	fputc(0x00, fp);
	fputc(0x00, fp);
	fputc(0x00, fp);
	//	the modifi number
	fputc(0x00, fp);
	fputc(0x00, fp);
	fputc(0x00, fp);
	fputc(0x00, fp);
	//	the app info offset
	fputc(0x00, fp);
	fputc(0x00, fp);
	fputc(0x00, fp);
	fputc(0x00, fp);
	//	the sort info offset

#ifdef BMP
	fputc('S', fp);
	fputc('2', fp);
	fputc('5', fp);
	fputc('L', fp);
	//	the DB Type "S25L"
#endif

#ifdef MIDI
	fputc('S', fp);
	fputc('M', fp);
	fputc('I', fp);
	fputc('D', fp);
#endif

	fputc('C', fp);
	fputc('R', fp);
	fputc('M', fp);
	fputc('6', fp);
	//	the CRID

	fputc(0x00, fp);
	fputc(0x00, fp);
	fputc(0x00, fp);
	fputc(0x00, fp);
	//	the unique ID seed
	fputc(0x00, fp);
	fputc(0x00, fp);
	fputc(0x00, fp);
	fputc(0x00, fp);
	//	the next record list ID

	fputc(0x00, fp);
	fputc(1, fp);
 	// num records - allways 1 record
}
