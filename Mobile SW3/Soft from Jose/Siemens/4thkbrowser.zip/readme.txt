==================================================
4thpass KBrowser(TM), Technology Preview readme 

Date: May 26, 2000
==================================================

We strongly recommend that you review this entire 
document for information that may not be available 
in the user manual.

-------------------
TABLE OF CONTENTS
-------------------
- Minimum Requirements
- Installation
- KBrowser Features
- KBrowser Issues 
- Registering
- Suggestions for Additional Features


----------------------
MINIMUM REQUIREMENTS
----------------------

To use KBrowser Technology Preview
you must have the following:

- Palm OS 3.1 or higher (with NetLib)
- 80k of freespace
- A wireless modem

--------------
INSTALLATION
--------------

To install KBrowser:

1. Copy the files kbrowser.prc to your desktop computer. 

2. Install the software by using Palm's Install Tool program.

3. From your Palm computer, run a HotSync operation.  KBrowser 
   will transfer from your desktop computer to your Palm computer.

---------------------
KBrowser 1.0 FEATURES
---------------------
- Supports WML and WMLC

- Supports WBMP images 

- Favorites for bookmarking WAP sites 

- 4thpass transcoding technology 

- Online Help files  
 
---------------
KBrowser ISSUES
---------------

- KBrowser may not work with TCP/IP network connections 
  via infrared on older PalmOS versions. We believe this 
  is a problem with the network implementation on Palm devices 
  having earlier versions of the PalmOS - the PalmOS 3.3 update 
  fixes this issue and is available from Palm Computing's web 
  site at http://www.palm.com/custsupp/upgrade/.


------------
Cache size
------------

Copies of KBrowser pages are kept locally in order to speed
operation.  By default, up to 50K of the device's memory is used for
this cache. 

---------------------------
Registering
---------------------------

As distributed KBrowser Technology preview is FREE for personal use.

To License KBrowser for commerical use, please visit our web site at
http://www.4thpass.com or contact sales@4thpass.com


There is e-mail and telephone technical support available for
registered users of the KBrowser.


--------------------------------------------
SUGGESTIONS FOR ADDITIONAL KBrowser FEATURES
--------------------------------------------

From time to time, everyone comes up with an idea for something that
they'd like their software to do differently. If you have an idea that
you think might enhance KBrowser, your input is always welcome.

Please send any suggestions for new features in KBrowser to: 
feedback@4thpass.com



