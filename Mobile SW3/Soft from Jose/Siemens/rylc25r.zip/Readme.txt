For repairing destroyed phones:

("Destroyed by C25 Unlocker" and "Wrong software" messages)


1. Start C25-pwr.exe
2. Enter IMEI of phone
3. When step1 start push Power button on phone - you must see "Service mode" on phone display
4. When step21 go you must exit program with ALT+X !!!!!!!!!!!!

Now if you have "Wrong software" phone you flash it