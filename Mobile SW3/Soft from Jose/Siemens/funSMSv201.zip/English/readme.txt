
funSMS, fMML

Release 2.0

If you are already using version 1.0 of funSMS you have to delete
the communication library fMML before installing the new version.
Select the menu "Delete" in the application launcher on your palm
and delete the entry "fMML-SMS".
After doing so you can install the new version 2.0. Your already
received messages will still be available.

If you are working with PalmOS 3.3 or higher, please do 
not install the Enhanced Infrared update from 3Com. 
It is no longer required for funSMS.

The program documentation (funSMS.htm) can be found 
in the folder \English\Docs. 



fun communications GmbH, September 2000
