funSMS, fMML

Release 2.0

Wenn Sie bereits Version 1.0 von funSMS auf Ihrem Palm installiert haben, so
m�ssen Sie vor der Installation der neuen Version zuerst die Kommunikations-
bibliothek fMML l�schen.
Rufen Sie hierzu in der Anwendungs�bersicht auf Ihrem Palm den Men�punkt
"L�schen" auf und l�schen Sie den Eintrag "fMML-SMS".
Danach k�nnen Sie die neue Version installieren. Ihre bereits abgelegten SMS
sind von dieser Prozedur nicht betroffen.

Wenn Sie mit PalmOS 3.3 oder h�her arbeiten, installieren Sie 
das "Enhanced Infrared Update" von 3Com bitte nicht. 
Es wird f�r funSMS nicht mehr ben�tigt.

Im Verzeichnis \Deutsch\Doku befindet sich 
die Programmdokumentation (funSMS.htm).



fun communications GmbH, September 2000
