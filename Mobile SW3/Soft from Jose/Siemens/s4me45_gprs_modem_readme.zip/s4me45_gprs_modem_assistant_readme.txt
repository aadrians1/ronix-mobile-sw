          --- SIEMENS S45 / ME45 GPRS Modem Assistant ---
          ---         useful hints (07/2001)          ---



### Windows Platforms ###
These platforms are supported: 95, 98, 98 SE, ME, NT 4, 2000. The Microsoft
Internet Explorer must be version 4.x or better. Depending on the special
installation situation on each PC, other installed programs or Windows internal
problems the tool may fail to install the neccessary Windows components. You
need to have the Windows CD supplied with your PC for proper installation. End
ALL programs before installation. If you encounter problems installing network
components in general ask your local PC dealer for Windows support.

### Language Versions ###
The versions are Deutsch, English, Francais, Italiano. The Assistant only runs
on these localised Windows versions because it uses components of the Microsoft
Internet Explorer (version 4.x or better).

### Deinstallation / Update ###
For installation of a new version you have to deinstall the Assistant first.
Just right-click on the Assistant's icon on the desktop and choose "deinstall".
Make a reboot afterwards. The deinstallation will NOT remove the S45 GPRS Modem
and the Dial-Up Network and the other network components because they may still
be used in other connections. Only the Assistant itself is removed.

### IrDA ###
The Assistant as well as the mobile phones do not support GPRS via IrDA, but it
may work nevertheless ... You will get problems when the Windows Plug&Play
mechanism detects the S45 / M45 via IrDA. It will install the modem again. To
solve the problem: Do not use IrDA but the cable that came with the mobile
phone. Deinstall the modem that is conected to the IrDA port and run the
Assistant's installation again.

### Baudrate ###
57600 Baud is the default of phones delivered to the customers. The Assistant
fits to this and therefore also uses 57600 for installation. There should be no
reason to change this! - If you want to set the Baudrate in the mobile phone to
something else just set it back to 57600 during the installation of this
Assistant. Try a connection and when you succeeded end the connection and
switch the baudrate in the telephone to the value you prefer, open the modem
setup in the system settings change the baudrate to the same value, open the
Dial-Up network and select the entry "Siemens S45 GPRS" and set the baudrate
inside of it to the same value. Yes, it has to be done three times. The mobile
phones do not support AutoBaud. There is no AT command to change the baudrate
from outside the mobile. AGAIN: We recommend to keep it (as it is) at 57600!

### Modem Init String ###
It is left blank in the Dial-Up Network entry "Siemens S45 GPRS" after
installation of the tool. Yes, this is ok. Some Windows versions cannot send
enough characters to the modem. Therefore the Modem Assistant does it himself.

### How to find all the connection parameters ###
Check your "Program Files" folder for the "S45GPRS" folder. Inside of it there
are the details. The phone numbers can be found in "SIEMENS.PBK" and the
settings in "S45.INI". DO NOT change anything unless you know what you are
doing!

### Dial-Up Network ###
There is an entry "Siemens S45 GPRS" being automatically created during
installation of the Modem Assistant. Use it to change the baudrate as described
above. If it is deleted it will be recreated at the next start of the Modem
Assistant BUT with the original setting of 57600 Baud. Keep this in mind.

### Hints for NT / 2000 ###
In case of WinNT Service Pack 6 is recommended/required. You MUST be an
administrator of that PC! Remember to install the Service Pack once more after
any installation and the Phone Service must be running for proper installation.

### COM port ###
If the Assistant reports that the mobile phone cannot be found though you
checked the proper connection to a COM port of your PC some other program has
reserved the COM port for itself. Well known are programs that exchange data
to Palm handhelds or FAX programs. Make those programs to release the COM port!



We wish you always a good connection ...                            Be inspired


