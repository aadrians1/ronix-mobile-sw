S25_Sync--- Das Programm zur Pflege des S25 Organizers

*** Version 1.1.17

Dieses Programm ist Freeware.
Jegliche Verbreitung gegen Bezahlung ist unerwuenscht !
Der Autor uebernimmt keinerlei Garantie oder Haftung
fuer Daten und evtl.Schaeden welche durch die Installation 
oder Nutzung des Programms entstehen !

Wem das Programm gefaellt kann dem Autor gerne einen Ausgeben. 
Wie ?? 
Mailto:alange@velbert.net 
Antwort folgt dann.

Installation :
Setup ausfuehren

Inbetriebnahme :
Programm starten
In "System" 
COM-Port Einstellen
Geschwindigkeit 
19.200 bei V24 
und 
57.600 bei Infrarot

Bei sehr schnellen CPU's und/oder V24 Verbindung koennte es zu Problemen kommen.
dann die CPU-Bremse in den COM-Port Einstellungen hoeher setzen
Defaultwert ist 7500 
Bei Infrarot oder langsamen PC kann man den Wert
auch verkleinern. (ausprobieren)
Wenn der Wert zu klein ist kommt es zu Kommunikationsfehlermeldungen.


In Programmoptionen kann eingestellt werden ob das Programm 
vor dem Senden zum S25 die Termine nach Datum sortiert
und
ob vor dem Senden bereits vergangene Termine aus dem Organizer
geloescht werden sollen.

Der Button "Tabelle Drucken" verwendet den WIndows-Standard-Drucker

HINWEIS:
Zweimaliger Doppelklick auf das Datumsfeld oeffnet ein Kalender-Controll


Dann viel Spass mit dem Programm !  