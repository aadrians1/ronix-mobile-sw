;**********************************************************
;*		Do not edit these line!!!		  *
;*							  *
;**********************************************************
"Special From "GSM Page by Hoze...""
"URL: http://www.alfa24.co.yu/gsm/"
"E-Mail: hoze@alfga24.co.yu ICQ# 42742817, mail me for new soft!!!"