Hy folks here you have the new version of all25, be carefull it won�t work in power models.
Unpack this to C:\SIEMENS\.
Use this program after you flash the mobile.


                                  Thanks to All, by 10111100110110010100!!