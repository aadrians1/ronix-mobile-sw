Easy IMEI Changer v1.01  -  Help File
(C) Copyright Montanio II 
2000-2001
-------------------------------------------------

*** Introduction ***

Welcome! This is the first version of Easy Imei Changer.
EIC is a program that helps you change your current IMEI number
on your phone.

*** Supports ***

EIC Support the 5110, 5130, 6110, 6150.
Software versions has to be between NSE -1 and NSE -3
You need a FBUS/M2BUS cable to make EIC work.

*** Specification ***

EIC can change your IMEI number 99,9 % on a working phone.
Make sure your using the right software version that EIC claims.

*** F.A.Q ***

1. Why do I get an error that tells me I'm using an incorrect SW version
   and that says that my mobile might be stolen?

2. Make sure that you are using a compatible software version that EIC
   can handle. Your mobile could also been a stolen one. You should go to
   your retailer and ask them if they know any about this.
   If you now that you're mobile is stolen you should go to " http://www.des.co.uk/software.htm "
   and download latest DK2WIN drivers. Because if your mobile is stolen then
   windows will protect EIC from writing to your phone but with DK2WIN
   you can continue writing to the phone.

1. What is DK2WIN.DLL???


2. DK2WIN.DLL is security protection drivers that let's you do illegal
   operations such as "changing the phones IMEI".

1. Can I use my 3210 for this program??

2. Not in this version, But very soon this program will have support
   for the nokia 3210 and the 3210 cable of course.

1. When I'm trying to write to the phone, EIC says that my phone is
   not a 5110. But I KNOW it is.

2. You're phones software might be to new for EIC to recognize it.
   Try using it later in our new version of EIC.

1. EIC can't communicate with the communication port, Why???

2. Check that the COM port is not in use by any other software.
   Maybe your computer needs a restart.

1. What is this program written in?

2. I've been working with this program in a hell long time!
   It's written in Borland C++ and the source for communicating
   with the phone I've found in a great programming site with
   full of sources.


*** Contacting ***

We don't take any e-mails or any other shit.
We don't either have any homepage.
You will notice the new version on the site you downloaded
this program.

*** Agreement ***

We don't take any responsibilty if your phone happends to crash...
I'm just telling you that this program could make seriously damage
to your phone if you really don't know what you're doing.
EIC will replace your current eeprom with a new eeprom image that 
contains a different IMEI number.


(C) Copyright Montanio II 2000, All right reserved. 