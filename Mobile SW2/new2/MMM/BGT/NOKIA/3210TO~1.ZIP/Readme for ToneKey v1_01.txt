

Readme for ToneKey v1_01

Installation: Simply decompress ToneKey.zip in a separate directory (e.g. c:\ToneKey)

Features: ToneKey is a Program to convert ringtone notes for Nokia 3210(r) into key sequences that extremely simplify the correct insertion of these ringtones.
ToneKey has a very simply interface 



Toolbar: This is a very simple toolbar, the four buttons has the canonical functions, the first clear the input/output area, the second cut any selected text, the third copy the selected text in the clipboard and the forth paste the text in the clipboard at the cursor position.
Number of Notes/Check: This field shows the current number of notes inserted in the input area, report "ERR" when an error occurs (e.g. a misspelled note), report "KEY" when the conversion has take place. The 50 notes bound is a Nokia 3210(r) limitation, the phone can store only fifty notes at maximum, the program can convert however any number of notes you like (even if the use of this case is unknown).
Input & Output Area: This Area is a simple text area, you can write, erase, copy, paste text as you like. This area is mouse sensitive and if you click the right mouse button, a popup menu is showed.

Select all, select all the text in the area, Undo Conversion, recover the original notes as they were before conversion, About Tonekey, display a message of the author, Exit, closes the program, exactly as the small x at the upper-right corner.
Action Button: This button converts the notes in the input area into keys sequence.

This is how program works, however there are some recommendations I have to do to make the program works fine:
* Do not enter normal text in the area and try to convert it, even if the program recognize the notes, special combinations of characters may generate errors.
* Don't push Action Button twice, because the output window and the input are the same.

If you find other bugs or if you have suggestion, please let me know them.

This program is free; your little donation is nice and welcomed.
Tank you very much.

micdabe@tin.it

Version 1.01
A little bug in tone duration was corrected, in fact for example if you insert a 1/8 note then a 1/2 pause and then 1/8 note you don't have to change the duration of the 2nd note because the 1/2 pause don't affect the duration of the 2nd note and this is quite strange to predict, isn't it?
