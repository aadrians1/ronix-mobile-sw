Nokia NetMagic V2.0XMas (NetMonitor Activator for NOKIA 51/6110, 3210)


    Version 2.0XMas
Date:21/12/99  Time:05.57CET

* MANY BUG'S CORRECTED !!!!
* NOW WORKING WITH ALL CABLE'S Recommended:(M2BUS)
* RESET BUTTON REMOVED
* PROGRESS BAR ADDED !!!
* POWER "ON" THE PHONE ADDED
* ADDED A HTTP URL LINK
.........

       GSMagic TEAM WISH TO ALL MERRY MERRY CHRISTMAS AND HAPPY THE NEW YEAR !!! 

-

  Nokia NetMagic v1.0b
     First release 
Date:25/11/99  Time:16.05CET


For bug report's please write us EMAIL: GSMagic@SoftHome.net

Check out our SITE  http://GSMagic.tsx.org