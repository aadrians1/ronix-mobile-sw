M0t0r0La LiBEraT0r
-------------------

Well that's another program suite from the Romanian GSM Liberation Front.

This one kicks Motorola's ass really hard. The damn bastards disabled
the CLONE facility in the newer phones (POST-October-98 - A0.04.29) and SP-Unlocking
is more difficult now, you can do it via bdm. How? Clone everything (flash,
eeprom etc).I've managed to enclose some plans for the bdm interface and the
connector pinouts for the d520 and cd930 bitches. The 74HC76 can be replaced
successfully with a 74LS76 since we don't need high speed ttl gates there.
Of course you can change IMEI and any other crap but I don't know the
DS2401 protection impact. Write me about it.Send me clean flashes.Just don't be
jews.
Warning, d520 firmware A8.03.04  can't be downgraded to A8.02.14 (the last
that accepts clone). Guess the special code if you don't have a good flash
images. Anyone knowing the special code locations for the Mot phones?
Don't think about unlocking 3688 with this, it won't work hence the MCU has
been changed.

If you mess up the imei on the A8.03.04 d520 sw don't panic.
The field 0C, subfield 01 is 9 bytes long.But an IMEI is 8 bytes long :)
The solution: place $08 before the 8 swapped bytes of the IMEI ... the frame looks like 09 0C 01 08 4A 84

Of course you have some examples for bd32 made by mad

We are recruiting new members, send your intentions to deadrange@hotmail.com.
Please contribute with programs and webspace.
I would like to send big hailz to the FreeGSM supporters: MyKy and Bontek.
For more info visit http://www.tele-servizi.com/janus/motpages.html, there 
is an excelent work there made by real gsm gurus, Janus and Madis.

---------------------
Ninja
RGLF Headquarters
deadrange@hotmail.com