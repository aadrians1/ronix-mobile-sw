f	-	init macro for Mot gsm phone (d160)
eewe	-	macro that enables EEPROM and Flash Write 
		by changing SIM registers
d2d	-	Dump Data to Disk
eewpd	-	Disable EEPROM Chip Software Data Protection Feature
wree	-	Write Data to EEPROM (M26lv64)
wrfl	- 	Write Data to Flash (for 16bit wide Intel Smart Voltage
		Flash Chips - tested with TE28F800CEB120 in Motorola d160
erafl	- 	Erase single Flash Rom Block
tofler  - 	TOtal FLash ERase macro
wob	-	Write Only Byte (bf;b <addr> <addr> <data> is better idea) 

Works with any other mot phone except 3688.