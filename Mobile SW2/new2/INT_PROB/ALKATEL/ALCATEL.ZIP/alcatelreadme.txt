Instructions for alcatel unlock.exe

Once you enter your IMEI, you got 2 codes, ON, OFF plus phone type. 
ON is the code for turning on the SIMLOCK. We don't wanna do that, right? :-) So let's go for the OFF code. This is supposed to be the one to remove the SIMLOCK, but it's incomplete, at least for the network providers here in Spain. This number, as you have seen, is in HEX format. I think it's a kind of universal code in which any netword provide add another fixed number (always the same) and the correct UNLOCK CODE is the sum of both of them. Let's see this in an example. 

IMEI: 330020536226XXX
ON: 50453d90 
OFF: 10453d90 
Phone type: Alcatel HC800 
Network provider: E MOVISTAR (214-07) 

If we introduce the OFF code, the phone won't accept it. We have to add another number to this code. In Spain and for 214-07 (MoviStar) this is 9FDFFA. So we have to sum this numbers. The easier way is by loading the windows's calc, use the Hex mode and realize the sum 
10453d90+9FDFFA=10E51D8A 
10E51D8A is the right number. So we type this in our phone and ... the SIMLOCK is removed!!!!! 

Instructions credited from :http://www.worldofcellularsecrets.com



