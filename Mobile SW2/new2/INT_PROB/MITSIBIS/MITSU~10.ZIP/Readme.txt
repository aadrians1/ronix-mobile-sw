pic12c509 or 12c508 program for Mitsubishi MT140,MT040

CodeProtect - ON , MasterClear - OFF , WatchDogTimer - OFF , OscilatorType - IRC 

connections:

1..pin 8 of 25640 
2..pin 7 of 25640 !!! importantly !!! - ( 7pin of 25640 is not connected to phone, only to 2pin of 12c509)
3..nc
4..pin 1 of 25640
5..nc
6..nc
7..nc
8..pin 4 of 25640
