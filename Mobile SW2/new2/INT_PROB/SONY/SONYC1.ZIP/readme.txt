
This proggy is very simpe in use, just enter IMEI number and press
ENTER. You will get the code. To remove simlock, power on the phone
and type: *#7465625*12*12345678#, 7465625 means SIMLOCK :) and 
12345678 is number that you have generated.
Thats all.

Tested with ERAGSM only:<
Please let me know if you have succesufully remove simlock 
using my prog.


Next version soon.


Author of this prog takes no responsibility for using this programm.


For more hot gsm progs and more... http://gsm.iq.pl

YagoDa
yagoda@supergsm.prv.pl
http://gsm.iq.pl
