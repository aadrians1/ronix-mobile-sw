Motorola Test card for GSM phones / PIC 16F84 or 16C84 wafer cards.
Created by Ronny Stern (simpic@gmx.de)
http://simpic.tele-servizi.com/index.html

For documentation on the test card, look at Janus page.
http://www.tele-servizi.com/Janus/motpages.html

Fuses Pic16C84: OSC: 	XT
		WDOG: 	Off
		PUT:	Off
		CP: 	On/Off

Fuses Pic16F84: OSC: 	XT
		WDOG: 	Off
		PUT:	On
		CP: 	On/Off

This code is released for the public domain and it is STRICTLY FORBIDDEN
to charge anything for it.

