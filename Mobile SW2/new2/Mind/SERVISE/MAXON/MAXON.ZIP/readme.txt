hi wiked
this program unlock all maxon phones 
i that there are a lot of maxon phones in spain....
just try it.