Panaimei is a Visual Basic 5.0 Program and requires the 
files msvbvm50.dll, comctl32.ocx and mscomm32.ocx to be in 
the windows\system folder. Please ensure that this files 
are correctly set up on your system BEFORE attempting to 
run panaimei.exe