PICPROG README
==============

Last minute updates

<none>

Full insallation information can be found in PICPROG.DOC 
(Windows 95 Wordpad file, Word 6.0 should be able to read it).

