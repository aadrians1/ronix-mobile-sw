Schematic and PCB for CHIPY Reader.
Version 1.0 (07-Jan-1999).

http://perso.wanadoo.fr/telecard



      Hello,

   First of all thanks for your interest in CHIPY READER.

   I am sorry it took me much time to set up this schematic and
PCB for CHIPY READER.

   The files in this archive:

      - readme.txt    You are currently readind it ;-)
      - material.txt  The 'Bill Of Material', this is the (big)
                      list of the material you have to buy
      - schema.ps     Schematic of the reader in Postscript
                      format (see below for reading .ps files)
      - bottom.ps     The bottom view of the PCB you have to
                      etch using a photo-sensitive board.
      - silk.ps       Is the silkscreen, it shows where you have
                      to solder the parts.
      - top.ps        Is the top view of the board, indicating
                      where you have to solder the 4 straps.


Questions and Answers:

Q: I do not have a PostSctipt printer, how can read .ps files?

A: Try to use GSView 2.7 available from http://www.cs.wisc.edu/~ghost/

Q: Where can I find a +5V power supply?

A: From your computer, e.g. taking it from the keyboard or PS/2 mouse
   connector.

Q: Do you have the pinout for the keyboard or PS/2 mouse connector?

A: Yes, available from Flynn's Tech-Links, the Keyboard and Mouse
   Connectors. Remember to verify the voltage available before
   connecting the power to the reader.

        Signal Name     5-pin    6-pin
                         DIN   mini-DIN

        Keyboard data     2        1
        Ground            4        3
        +5V               5        4
        Keyboard clock    1        5
        Not connected    ---       2
        Not connected    ---       6
        Not connected     3       ---


        5-pin DIN      Plug      Socket
                      1   3      3   1
                     4     5    5     4
                        2          2

        6-pin Mini-DIN   Plug     Socket
                        5 � 6     6 � 5
                       3  �  4   4  �  3
                         1 2       2 1

Q: My computer and the nuclear power plant next to me exploded when
   I connected your f#@king reader to my computer.

A: This did not happen to me. Sorry but I assume no responsability
   for this, obviously you made a mistake or were not qualified for
   this kind of work.

Q: Is there an order to solder the parts?

A: The more easy way is to first solder the 4 straps (mandatory
   because they are implanted under the smartcard connector), then
   the resitors and the capacitor, then the 3 connectors.

Q: Can you sold or swap a fully assembled and tested reader?

A: Not for the moment, I will never sold anything anyway, but may be
   a swap for a pile of chipcards for my collection. Why not?
