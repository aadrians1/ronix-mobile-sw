downloaded from: http://gsm.przez.net

An update of Er2000 by Deezel to recognize the new T10's
Updated by Deezel

downloaded from: http://gsm.przez.net