Sim_Pic v2.4 for GSM phones / Gold Wafer (PIC 16F84 + 24c16)
Includes COMP128 !!!
Created by Ronny Stern (simpic@gmx.de)
http://simpic.tele-servizi.com

Simpic's COMP128 was based on the COMP128 C source code engineered by
Marc Briceno, Ian Goldberg, and David Wagner.
Copyright 1998, All rights reserved.
http://www.scard.org/gsm


Fuses Pic16F84: OSC: 	XT
		WDOG: 	Off
		PUT:	On
		CP: 	On/Off (Better On)

This code is released for the public domain and it is STRICTLY FORBIDDEN
to charge anything for it.

