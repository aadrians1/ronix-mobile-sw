This document contains some recent information about the Nokia 9110 Communicator.


Contents

1. Printing with Nokia 9110 Communicator
2. Using Nserver software under Microsoft NT
3. Using the communicator as a fax modem with Microsoft Windows 95
4. Using the communicator as a fax modem under Microsoft Windows 98
5. PC Suite troubleshooting


1. Printing with Nokia 9110 Communicator
=========================================

The Nokia 9110 Communicator allows you to print using infrared or cable.
These instructions will help you to make direct printing from your communicator.

All brands and product names are trademarks or registered trademarks
of their respective holders.


SUPPORTED PRINTERS

There are many printer models available.  The drivers supplied here will cover most 
needs. Even if your model is not mentioned by name, then if your printer supports 
"Epson emulation" or "Postcript" or "PCL" then printing is possible.

- The following printer drivers are supplied in the communicator:

Hewlett Packard Laserjet 5P	(postscript printer)
Hewlett Packard Laserjet 5MP	(PCL printer)
Hewlett Packard Laserjet 6P	(postscript printer)
Hewlett Packard Laserjet 6MP	(PCL printer)			

- Extra printer drivers on the diskette:

These drivers can be installed to the communicator using the Install/Remove feature
in the PC Suite, or Install/Remove software in the communicator Systems application
with Nokia Server Software. Drivers are in directory d:\9110Soft\Printer. Reboot
the 9110 Communicator after installing the software.

Canon BJC-70			(Set printer to LQ emulation mode)
Citizen PN60i
Hewlett Packard Deskjet 340
Ascii printer driver

The Ascii printer driver allows you to print simple text from documents,
but not graphics files, such as faxes.  This printer driver is compatible
with many printers.

- Other printers:

If your printer supports "Epson emulation" (check the documentation supplied
with your printer) then printing is possible with either the Canon BJC-70 or
Citizen PN60i printer drivers.

If your printer supports "Printer Control Language (PCL)" (check the documentation
supplied with your printer) then printing is possible with either HP LJ 5MP or
HP LJ 6MP  printer drivers.

If your printer supports "postscript" (check the documentation supplied with
your printer) then printing may be possible with either HP LJ 5P or HP LJ 6P
printer drivers.

Please check first that printing is possible before purchasing a new printer.


INFRARED AND SERIAL PORT PRINTING

Printing uses either Infrared or the serial RS-232 Adapter Cable included
in the communicator sales package. Select the connection method that you wish to use
with the Print settings from the Settings in System application in your communicator.

If you use serial port printing, check that the Print Settings in the system application
(shown below) are set correctly for your printer (see the documentation supplied
with your printer). 

Please check that serial port printing is possible before purchasing a new printer - it is
best to check that serial port printing works in the store before purchase.

	Connection type		Cable
	Baud rate		xxxx
	Flow control		xxx
	Data bits		x
	Parity			x
	Stop bits		x


Parallel printing to a printer Centronics port:

Greenwich Instruments Ltd., UK, have developed an adapter for parallel printing
specifically for the Nokia 9110 Communicator (model: GA935-N).  This connects a printer
to the RS-232 Adapter Cable supplied in your communicator sales package.
Contact information is provided in the 9110 Solutions Guide.

To use GA935-N, select System application and Settings, then change Print settings and
check the following settings:
	
	Connection type		Cable
	Baud rate		57600
	Flow control		Software
	Data bits		8
	Parity			None
	Stop bits		1

Nokia 9110 Communicator may not be compatible with other serial/parallel printing adapters.
The GA935-N has been developed specifically to work with the 9110.



PRINTING WITH PC SUITE

Communicator documents and faxes can be printed to a PC printer.
First, use File transfer to move file from Nokia 9110 Communicator using
PC Suite for Nokia 9110 Communicator. Then print the file from a compatible
Windows application. 

Note: documents can also be transferred using File Transfer with Nokia Server Software
for printing, but faxes will not be converted to a suitable format for PC printing.



2. Using Nserver software under Microsoft NT
============================================

The recommended tasking model under NT3.51:
	- Foreground Application More Responsive than Background
or
	- Foreground and Background Applications Equally Responsive

	1) In the Main group, double-click the Control Panel icon.
	2) In the Control Panel, double-click the System icon.
	3) Choose the Tasking button.
	4) Select the correct Tasking model.
	5) Click the Ok button.
	6) Shutdown and Reboot the computer.

The recommended performance boost under NT4.0:
	-None

	1)  In My Computer, choose the Control Panel icon.
	2)  In Control Panel, double-click the System icon.
	3) Select the Performance tab.
	4) Set Application Performance boost to None.
	5) Click the Ok button.
	6) Close System and Control Panel


3. Using the communicator as a fax modem under Microsoft Windows 95
===================================================================

The communicator may be connected to a computer via an infrared or
cable connection. The connection type is selected in the communicator's
Fax modem settings (the Fax modem application is found in the System
main view).

If you wish to use an infrared connection, your computer must have an
IrDA compatible infrared port and the IrDA drivers must have been installed
and activated (for more information on IrDA drivers and their use in
Windows 95 contact Microsoft).
		
If the IrDA drivers are activated on your computer, the computer will
automatically detect the presence of the communicator. 

When using the communicator as a fax modem via an infrared connection, 
it is recommended to use the communicator with cover closed to speed up 
the infrared link.

- Fax modem installation using infrared connection:
	 
	 1) Start Windows 95 and switch on the communicator's phone interface.
	 2) Insert the Setup disk into the disk drive of your computer.
	    This floppy disk contains the modem information file.
	 3) The infrared ports of the communicator and the computer should be
	    facing each other (the distance should be between 5 to 100 cm).
	 4) Select Infrared as the connection type in the Fax modem
	    settings.
	 5) Press Activate in the Fax modem main view.
	 6) Check from the Infrared Monitor of Windows 95 that Windows 95
	    is searching for other devices in range and Plug and Play
	    is enabled.
	 7) If your Windows 95 operating system does not at this stage
	    display a dialog box you can start using the communicator as
	    a fax modem.
	 8) If your Windows 95 displays a dialog box stating "New Hardware Found",
	    choose "Driver From Disk Provided By Hardware Manufacturer"
	    (default choice). Click OK or press Enter.
	 9) The dialog "Install From Disk" appears. Click OK or press Enter.
	    Windows 95 configures your communicator.
	10) Remove the Setup disk from the disk drive. You may now start using
	    your communicator as a fax modem with Windows 95. The computer you
	    have configured can now automatically detect the communicator every
	    time the communicator is used as a fax modem with the computer.


- Fax modem installation using a cable connection:

	 1) Start Windows 95 and switch on the communicator's phone interface.
	 2) Insert the Setup disk into the disk drive of your computer.
	    This floppy disk contains the modem information file.
	 3) Connect one end of the cable DLR-2 to the adapter and the other end to 
	    the serial port of the computer.
	 4) Double-click Modems icon in the Control Panel.
	    Click Add button in the Modems Properties Dialog.
	 5) Choose "Other" to the Question "What type of modem do you want
	    to install?". Click Next button.
	 6) Tick the option "Don't detect my modem;I will select it from a list."
	    Click Next button.
	 7) Click Have Disk... button. Click OK button.
	 8) Select "Nokia 9110 Communicator (Cable)". Click Next button.
	 9) Choose the serial port to which the cable DLR-2 is connected.
	    Click Next button.
	10) Click Finish button.
	11) Remove the Setup disk from the disk drive. 
	12) In the communicator's Fax modem settings, select Cable, 115200, 
            Software, 8, 1, None.
	13) Press Activate in the Fax modem main view. You may now start using your
	    communicator as a fax modem with Windows 95.

4. Using the communicator as a fax modem under Microsoft Windows 98
===================================================================

The communicator may be connected to a computer via an infrared or
cable connection. The connection type is selected in the communicator's
Fax modem settings (the Fax modem application is found in the System
main view).

If you wish to use an infrared connection, your computer must have an
IrDA compatible infrared port and the IrDA drivers must have been installed
and activated (for more information on IrDA drivers and their use in
Windows 98 contact Microsoft).
		
If the IrDA drivers are activated on your computer, the computer will
automatically detect the presence of the communicator. 

When using the communicator as a fax modem via an infrared connection, 
it is recommended to use the communicator with cover closed to speed up 
the infrared link.

- Fax modem installation using infrared connection:
	 
	  1) Start Windows 98 and switch on the communicator's phone interface.
	  2) Insert the Setup disk into the disk drive of your computer.
	    This floppy disk contains the modem information file.
	  3) The infrared ports of the communicator and the computer should be
	    facing each other (the distance should be between 5 to 100 cm).
	  4) Select Infrared as the connection type in the Fax modem
	    settings.
	  5) Press Activate in the Fax modem main view.
	  6) Check from the Infrared Monitor of Windows 98 that Windows 98
	    is searching for other devices in range and Plug and Play
	    is enabled.
	  7) If your Windows 98 operating system does not at this stage
	    display a dialog box you can start using the communicator as
	    a fax modem.
	  8) If your Windows 98 displays a dialog boxes stating "New Hardware Found" and 
	    "Add New Hardware Wizard", Click Next
	  9) Select "Search for the best driver for your device." Click Next 
	10) Unselect Microsoft Windows Update. Click Next
	11) Click Next
	12) The dialog "Install From Disk" appears. Click OK or press Enter.
	     Windows 98 configures your communicator.
	13) Remove the Setup disk from the disk drive. You may now start using
	    your communicator as a fax modem with Windows 98. The computer you
	    have configured can now automatically detect the communicator every
	    time the communicator is used as a fax modem with the computer.


- Fax modem installation using a cable connection:

	 1) Start Windows 98 and switch on the communicator's phone interface.
	 2) Insert the Setup disk into the disk drive of your computer.
	     This floppy disk contains the modem information file.
	 3) Connect one end of the cable DLR-2 to the adapter and the other end to 
	     the serial port of the computer.
	 4) Double-click Modems icon in the Control Panel.
	     Click Add button in the Modems Properties Dialog.
	 5) Choose "Other" to the Question "What type of modem do you want
	     to install?". Click Next button.
	 6) Tick the option "Don't detect my modem;I will select it from a list."
	     Click Next button.
	 7) Click Have Disk... button. Click OK button.
	 8) Copy manufacture's files from A:\
	     Click OK
	     Click Next
	 9) Select "Nokia 9110 Communicator (Cable)". Click Next button.
	10) Choose the serial port to which the cable DLR-2 is connected.
	      Click Next button.
	11) Click Finish button.
	12) Remove the Setup disk from the disk drive. 
	13) In the communicator's Fax modem settings, select Cable, 57600, 
                    Software, 8, 1, None.
	14) Press Activate in the Fax modem main view. You may now start using your
	     communicator as a fax modem with Windows 98.

5. PC Suite troubleshooting
===========================

See the readme.txt in the PC Suite program file directory on your computer.

	

NOKIA is a registered trademark of Nokia Corporation.

All the other trademarks are proprietary of the respective owners.

