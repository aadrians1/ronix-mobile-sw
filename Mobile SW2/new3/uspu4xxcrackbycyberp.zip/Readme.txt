Extract to:
[Drive]:\Windows\System
Select Yes to replace the file..

Run Prog, just Click "Enter Activation Code!"
you don't need to enter anything

Regards,
CyberPhreack
cyberphreack@clix.pt 
