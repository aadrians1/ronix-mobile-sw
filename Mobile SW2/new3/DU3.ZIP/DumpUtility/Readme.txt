DUMP UTILITY ver 3.00 

I need solutions  for 4.00 version.