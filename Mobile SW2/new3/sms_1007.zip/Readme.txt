SMS Gateway by GPA Technology  (v10.07 Beta 30-Jan-2000)
----------------------------------------------------------

Contents
========

- Overview
- Setup Instructions
- Distribution / Licence Information
- Limited Warranty and Disclaimer of Warranty
- Pricing & Ordering
- How to contact us
- Last minute information

Overview
========
SMS Gateway is a unique Short Message Service (SMS) messaging tool. 
It facilitates complete two way messaging capabilities over 
GSM networks for Microsoft Windows based applications through the 
use of DDE, OLE Automation, POP3, SMTP, and Command Line Interface.

SMS Gateway connects a PC to a GSM handset (Mobile Terminal), 
via a PCMCIA "Cellular Data Card", cable directly connected to a COM 
port, or via an infrared port. Through this connection all messages 
currently stored in the mobile terminal can be retrieved, new messages 
sent, and new incoming messages be sent straight through to the PC.

SMS Gateway comes with a powerful interactive two way messaging 
utility named SMS Messenger, that demonstrates the capabilities 
of SMS Gateway. This utility may be used for ad-hoc messaging 
alongside a corporate messaging or database access application.

Fully commented source code for the SMS Messenger application, 
written in Delphi 5.0, is also included in the package, so you 
can easily adapt its functions for your particular needs. Sample 
code for sending messages, receiving messages and controlling 
SMS Gateway using Excel 97 is also included with the installation files.

SMS Gateway supports a wide variety of methods to send and 
receive SMS messages, each of which are listed below.

For Sending SMS Messages to individuals or groups:
- Command Line Interface (CLI)
- Dynamic Data Exchange (DDE)
- Post Office Protocol 3 (POP3)
- Object Linking and Embedding (OLE)

For Receiving SMS Messages:
- Simple Mail Transfer Protocol (SMTP)
- Object Linking and Embedding (OLE).
- Logging to text files

OLE Automation support enables the transmission and reception 
of SMS messages directly from any application supporting 
these standards. Applications supporting OLE Automation 
include; Delphi, Paradox, FoxPro, WordPerfect, Excel, Word, 
Access, Visual Basic, and many more.

Support of POP3 and SMTP mail protocols enables SMS Gateway to be 
easilly integrated into web based facilities or corporate systems 
without any need for custom programming.

SMS Gateway is suitable for dispatch, field access to databases, 
telemetry, vehicle tracking, network management alerts, 
email notifications, and many more such applications.

We hope you find SMS Gateway a powerfull business tool 
that will enhance your business provide good value for money.

Setup Instructions
==================
-Copy the zip archive into an EMPTY directory on your hard disk
-Unzip all files in the zip archive into this directory
-From the Windows Start menu select Run
-Press the Browse button and select the newly created Setup.exe program
-Follow the on-screen instructions

Distribution / Licence Information
===================================

This program is shareware, it may be freely copied and distributed 
provided that the executable file is not tampered with in any way.

This version of SMS Gateway is fully functional, however each time 
a message is sent a licence banner stating "Sent using SMS Gateway (www.winsms.com) 
is appended to the message. As a registered user this licence banner is removed.

Limited Warranty and Disclaimer of Warranty
===========================================

This software (including any instructions for use) are 
provided "AS IS" without warranty of any kind. Further, 
GPA Technology does not warrant, guarantee or make any 
representations regarding the use, or results and 
performance of the software. If the software or written 
materials are defective the customer, and not 
GPA Technology or its dealers, distributors, agents 
or employees assumes the entire cost of all necessary 
servicing, repair or correction.

Neither GPA Technology nor anyone else who has been 
involved in the creation, production or delivery of 
this product shall be liable for any direct, indirect, 
consequential, or incidental damage (including damages 
for loss of business profits, business interruption, 
loss of business information, the like) arising out of 
the use or inability to use such product even if 
GPA Technology has been advised of the possibility 
of such damages.

This agreement , including Disclaimer of Warranty 
and Limited Warranty, is governed by the laws of 
the State of Victoria, Australia.

Pricing & Ordering
==================

Pricing & Ordering information may be found on our World Wide Web site 
at http://www.winsms.com


How to contact us
=================

E-mail     mail@winsms.com
WWW        http://www.winsms.com

Last minute information
=======================

Visit our World Wide Web site at http://www.winsms.com
for the latest updates and information.

======================================================
Thankyou for using SMS Gateway by GPA Technology
======================================================
