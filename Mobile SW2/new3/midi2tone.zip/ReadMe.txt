Midi To Tone 2.1
Copyright 1999 Mikko Ohtamaa

21.4.1999

=============
 What it is?
=============

It is a Windows 95 application. You can capture 
pieces of music from midi files and save it 
to other midi file. Of course you can listen 
midi files too. The program is freeware so it 
doesn't cost anything.

===============
 What it does?
===============

You can capture pieces of music from midi files and 
save it to other midi file. Of course you can 
listen midi files too. The program is freeware so it doesn't
cost anything.

=========================================================
 What? Do you think I'm stupid? Your program is useless!
=========================================================

Not exactly. The thing which the program does is that it 
"optimizes" midi files to a suitable format for Nokia PCComposer 
and mobile phones. 

===================
 How this happens?
===================

The user can select the primary melody from midi data with mouse. 
Overlapping notes are removed because a mobile phone can play
only a single note at a time. Also removing all pauses smearing 
note edges can be done. This helps to make longer ringing tones.
The program has also a algorithm to optimize the tempo and 
note lengths so that note ends are not "lost" which can happen if
the midi is imported to PCComposer straight. This makes ringing 
tones to sound better.

========================================
 Ok. Where can I download this program?
========================================

The primary site is www.kase.fi/~mikkooh/nokia

============================
 How can I use the program?
============================

First you must open a midi file. Midi files are divided 
to channels. You must choose a channel where the melody lies. 
You can mute all other channels so that you only hear 
the current channel's melody. Also a rolling note view helps
you to catch the right melody.

When you know on which channel your melody is, go to a note view.
There you can select notes you want pressing the left mouse button 
and dragging them into the lasso. If you want to unselect notes 
you can toggle it from the pop-up menu.

The right mouse button brings up a pop-up menu. There you can
zoom the note view, listen the selected melody or save the melody
either in a midi format or in a tone6110 0.11 format. See homepages
for more information.

You can also use automatic features to remove higher or lower notes
which are played same time. 

The mobile phone can only play notes which lie on the yellow area.
You can move this holding a control key and pressing the left mouse
button.

************************************************************
 !  Although mobile phones support 4 octaves
 !  PCComposer support only tones that fit in two octaves.
************************************************************

********************************************************************
 Midi To Tone has now Nokring export. Nokring format sucks and
 tones aren't heard right with it because the format doesn't
 support all required features. Prefer Tone6110 format if it works.
********************************************************************

In the option dialog you can modify some parameters that are used
in the convertion. The best way to learn these is simply to
trying everything.

=============================================
 How can I put the ringing tone to my phone?
=============================================

Only Nokia mobile phone models 6110, 8110, 7110 and (maybe)
Communicator support custom ringing tones. You need also a Nokia 
Cellular Data Suite 2.0. You can buy this from a Nokia dealer.

============
 Known bugs
============

The channel info list flickers. I will fix this when I get time.
MIDIs are played too slow when the program is minimized or background.
Windows timers sucks, but I could fix this.

Sometimes notes won't appear in the note view. Listen a bit of midi and
then try again.

=========
 History
=========

2.0 -> 2.1
    * fixed creepy sound when entering note view mode
    * nokring format support
    * midis sounds better in other programs

=================================================
 Your program sucks. Where can I send complains?
=================================================

My main email address is mikkooh@kase.fi. Also a feedback
about my "fluent" English is welcome. 

===========================================================
 I want to know what kind of a guy is behind this program?
===========================================================

I am 17 years old boy. I live in Toholampi, Finland. 
That's a little town near Kokkola city. 
My hobbies include coding, reading and jogging. 

I like Statovarius, Babylon 5, dogs and partying. I hate onion,
smoking and Swedish language.

If you have some projects I WILL GLADLY ASSIST
or YOU CAN OFFER ME a job.

