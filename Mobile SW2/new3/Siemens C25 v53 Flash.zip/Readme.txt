First setup swup if u don't have't
then use swupswup.exe

swupswup 5301

that's all


