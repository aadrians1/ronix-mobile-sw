/*
 * Smartcard snooper.
 * Written by Jim Rees <rees@umich.edu>.
 */

#pragma pack(2)

#include <Common.h>
#include <System/SysAll.h>
#include <System/DataMgr.h>
#include <System/SysEvtMgr.h>
#include <UI/UIAll.h>

#include <System/Unix/unix_stdio.h>
#include <System/Unix/unix_stdlib.h>
#include <System/Unix/sys_types.h>

#include "dogg.h"
#include "scrw.h"

#define MAXCOLLECT 100
#define MAXMEMO 3000

/* This will pull in the clib sprintf instead of using the crippled Pilot rom one */
#undef sprintf
#undef vsprintf

static char monthname[][4] = {
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
};

DmOpenRef MemoDB;
FieldPtr ansfield, statefield;
int port = 0;
int timeo = 20;
char *memop;
int memolen;
ULong mtime;

static Boolean dogg(EventPtr event);
int myprintf(int d);
int pr(const char *fmt, ...);

DWord
PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
    int err;

    if (cmd == sysAppLaunchCmdNormalLaunch) {
	err = StartApplication();
	if (err)
	    return err;
	EventLoop();
	StopApplication();
	return 0;
    } else
	return sysErrParamErr;
}

StartApplication()
{
    FrmGotoForm(formID_dogg);
    return 0;
}

StopApplication()
{
    if (memop)
	MemPtrFree((VoidPtr) memop);
    return 0;
}

EventLoop()
{
    short err;
    int formID;
    FormPtr form;
    EventType event;

    do {
	EvtGetEvent(&event, 200);

	if (SysHandleEvent(&event))
	    continue;
	if (MenuHandleEvent((void *)0, &event, &err))
	    continue;

	if (event.eType == frmLoadEvent) {
	    formID = event.data.frmLoad.formID;
	    form = FrmInitForm(formID);
	    FrmSetActiveForm(form);
	    switch (formID) {
	    case formID_dogg:
		FrmSetEventHandler(form, (FormEventHandlerPtr) dogg);
		break;
	    }
	}
	FrmDispatchEvent(&event);
    } while (event.eType != appStopEvent);
}

static Boolean
dogg(EventPtr event)
{
    FormPtr form;
    int handled = 0;

    switch (event->eType) {
    case frmOpenEvent:
	form = FrmGetActiveForm();
	ansfield = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_ans));
	statefield = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_state));
	FrmDrawForm(form);
	handled = 1;
	break;

    case ctlSelectEvent:  // A control button was pressed and released.
	if (event->data.ctlEnter.controlID == buttonID_start) {
	    doggydo();
	    handled = 1;
	} else if (event->data.ctlEnter.controlID == buttonID_save) {
	    doggydump();
	    handled = 1;
	}
	break;

    case menuEvent:
	switch (event->data.menu.itemID) {
	case menuitemID_about:
	    FrmAlert(alertID_about);
	    break;
	}
	handled = 1;
	break;

    }
    return handled;
}

doggydo()
{
    int fd, n, i, err;
    char buf[MAXCOLLECT];

    prfield("opening", statefield);

    fd = scopen(port, SCODCD, NULL);
    if (fd < 0) {
	pr("can't open serial port");
	return;
    }

    if (!memop)
	memop = (char *) MemPtrNew((long) MAXMEMO);
    *memop = '\0';
    memolen = 0;

    prfield("listening...", statefield);

    while (1) {
	err = scgetc(fd, &buf[0], 200);
	if (err == SCTIMEO && !EvtSysEventAvail(true))
	    continue;
	if (err != SCEOK)
	    break;

	mtime = TimGetSeconds();
	n = 1;
	while (scgetc(fd, &buf[n], timeo) == SCEOK && n < MAXCOLLECT)
	    n++;

	if (!n)
	    continue;

	for (i = 0; i < n; i++)
	    myprintf(buf[i] & 0xff);
	myprintf(-1);
    }

    if (err == SCTIMEO)
	pr("stopped on event");
    else
	pr("%s", scerrtab[err]);
    scclose(fd);
    prfield("closed", statefield);
}

doggydump()
{
    int i;
    Err err;
    UInt index = 1000;
    VoidHand RecHandle;
    Ptr RecPointer;
    char title[28];
    DateTimeType dt;

    if (!memop || !memolen) {
	pr("nothing to save");
	return;
    }

    MemoDB = DmOpenDatabaseByTypeCreator('DATA', 'memo', dmModeReadWrite);
    if (!MemoDB) {
	pr("save failed");
	return;
    }

    /* Allocate new memo */
    RecHandle = DmNewRecord(MemoDB, &index, sizeof title + memolen + 1);
    RecPointer = MemHandleLock(RecHandle);

    /* Write the title */
    TimSecondsToDateTime(mtime, &dt);
    sprintf(title, "trace %d %d-%s %d:%02d", index, dt.day, monthname[dt.month - 1], dt.hour, dt.minute);
    for (i = strlen(title); i < sizeof title - 1; i++)
	title[i] = ' ';
    title[sizeof title - 1] = '\n';
    DmWrite(RecPointer, 0, title, sizeof title);

    /* Write the raw trace data */
    DmWrite(RecPointer, sizeof title, memop, memolen + 1);

    /* Release the record and close the database */
    MemPtrUnlock(RecPointer);
    DmReleaseRecord(MemoDB, index, true);
    DmCloseDatabase(MemoDB);
    pr("saved %d trace bytes", memolen);
    *memop = '\0';
    memolen = 0;
}

/* Format and append to linebuf.  At end-of-line write to ansfield and to memop. */

int
myprintf(int d)
{
    va_list args;
    int i;
    static int linei;
    static char linebuf[80];
    char *cp, buf[4];

    if (d == -1) {
	/* end of line; write it out */
	linebuf[linei] = '\0';
	prfield(linebuf, ansfield);
	if (memolen + linei < MAXMEMO) {
	    linebuf[linei++] = '\n';
	    linebuf[linei] = '\0';
	    strcpy(memop + memolen, linebuf);
	    memolen += linei;
	}
	linei = 0;
    } else {
	/* not end of line; append to linebuf */
	buf[0] = itox(d >> 4);
	buf[1] = itox(d & 0xf);
	buf[2] = '\0';
	strcpy(&linebuf[linei], buf);
	linei += strlen(buf);
    }
}

itox(int d)
{
    return (d > 9 ? d - 10 + 'a' : d + '0');
}

int pr(const char *fmt, ...)
{
    va_list args;
    int i;
    static char buf[40];

    va_start(args, fmt);
    i = vsprintf(buf, fmt, args);
    va_end(args);
    prfield(buf, ansfield);
}

prfield(char *s, FieldPtr field)
{
    FldSetTextPtr(field, s);
    FldRecalculateField(field, true);
    FrmDrawForm(FrmGetActiveForm());
}

/*
copyright 1998
the regents of the university of michigan
all rights reserved

permission is granted to use, copy, create derivative works 
and redistribute this software and such derivative works 
for any purpose, so long as the name of the university of 
michigan is not used in any advertising or publicity 
pertaining to the use or distribution of this software 
without specific, written prior authorization.  if the 
above copyright notice or any other identification of the 
university of michigan is included in any copy of any 
portion of this software, then the disclaimer below must 
also be included.

this software is provided as is, without representation 
from the university of michigan as to its fitness for any 
purpose, and without warranty by the university of 
michigan of any kind, either express or implied, including 
without limitation the implied warranties of 
merchantability and fitness for a particular purpose. the 
regents of the university of michigan shall not be liable 
for any damages, including special, indirect, incidental, or 
consequential damages, with respect to any claim arising 
out of or in connection with the use of the software, even 
if it has been or is hereafter advised of the possibility of 
such damages.
*/
