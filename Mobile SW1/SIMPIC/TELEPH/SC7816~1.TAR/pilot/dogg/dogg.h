#define formID_dogg		1000

#define menuID_dogg		1000

#define menuitemID_about	1001

#define fieldID_ans		1001
#define fieldID_state		1002
#define buttonID_start		1003
#define buttonID_stop		1004
#define buttonID_save		1005

#define alertID_about		1000
