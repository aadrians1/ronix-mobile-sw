/*
 * OS dependent part, NT version
 *
 * Jim Rees, University of Michigan, October 1997
 */
static char *rcsid = "$Id: scioNT.c,v 1.4 1998/04/07 18:37:28 rees Exp $";

#include <stdio.h>
#include <windows.h>
#include <commdlg.h>
#include <io.h>

#include "scrw.h"

static struct {
    HANDLE fd;
    DCB dcb;
    OVERLAPPED rdov, wrov;
    int pending;
} sc[4];

int
scopen(int ttyn, int flags, int *ep)
{
    HANDLE fd = INVALID_HANDLE_VALUE;
    char comname[8];
    DCB dcb;
    COMMTIMEOUTS to;

    if (ttyn < 0 || ttyn > 3) {
	if (ep)
	    *ep = SCENOTTY;
	return -1;
    }

    sprintf(comname, "COM%01d", ttyn + 1);

    fd = CreateFile(comname, (GENERIC_READ | GENERIC_WRITE), 0, NULL,
		    OPEN_EXISTING, (FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED), NULL);

    if (fd == 0 || fd == INVALID_HANDLE_VALUE || !SetCommMask(fd, EV_DSR))
	goto nogood1;

    dcb.DCBlength = sizeof(DCB);

    if (!GetCommState(fd, &dcb))
	goto nogood1;

    sc[ttyn].fd = fd;
    sc[ttyn].dcb = dcb;

    dcb.BaudRate = 9600;
    dcb.ByteSize = 8;
    dcb.fBinary = TRUE;
    dcb.fParity = FALSE;
    dcb.fOutxCtsFlow = FALSE;
    dcb.fOutxDsrFlow = FALSE;
    dcb.fDtrControl = DTR_CONTROL_ENABLE;
    dcb.fDsrSensitivity = FALSE;
    dcb.fOutX = dcb.fInX = FALSE;
    dcb.fErrorChar = FALSE;
    dcb.fNull = FALSE;
    dcb.fRtsControl = RTS_CONTROL_ENABLE;
    dcb.fAbortOnError = FALSE;
    dcb.Parity = EVENPARITY;
    dcb.StopBits = TWOSTOPBITS;

    if (!SetCommState(fd, &dcb))
	goto nogood2;

    sc[ttyn].wrov.Offset = 0;
    sc[ttyn].wrov.OffsetHigh = 0;
    sc[ttyn].wrov.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

    sc[ttyn].rdov.Offset = 0;
    sc[ttyn].rdov.OffsetHigh = 0;
    sc[ttyn].rdov.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

    to.ReadIntervalTimeout = 0;
    to.ReadTotalTimeoutMultiplier = 0;
    to.ReadTotalTimeoutConstant = 0;
    to.WriteTotalTimeoutMultiplier = 0;
    to.WriteTotalTimeoutConstant = 0;

    if (!SetCommTimeouts(fd, &to))
	goto nogood2;

    /* The open may or may not have reset the card.  Wait a while then flush
       anything that came in on the port. */
    scsleep(250);
    scdrain(ttyn);

    /* poll for DSR */
    if (flags & SCODSR)
	while (!scdsr(ttyn))
	    scsleep(1000);

    return ttyn;

 nogood2:
    SetCommState(fd, &sc[ttyn].dcb);
 nogood1:
    if (fd != 0 && fd != INVALID_HANDLE_VALUE)
	CloseHandle(fd);
    if (ep)
	*ep = SCENOTTY;
    sc[ttyn].fd = INVALID_HANDLE_VALUE;
    return -1;
}

/* query dsr on the port (usually indicates whether the card is present) */

int
scdsr(int ttyn)
{
    HANDLE fd = sc[ttyn].fd;
    unsigned long comstat;

    if (fd == INVALID_HANDLE_VALUE)
	return 0;

    GetCommModemStatus(fd, &comstat);
    if (!(comstat & MS_DSR_ON)) /* No card */
	return 0;

    return 1;
}

/* raise or lower dtr */

int
scdtr(int ttyn, int cmd)
{
    if (!scdsr(ttyn))
	return -1;

    EscapeCommFunction(sc[ttyn].fd, (cmd ? SETDTR : CLRDTR));
}

int
scclose(int ttyn)
{
    HANDLE fd = sc[ttyn].fd;

    SetCommState(fd, &sc[ttyn].dcb);
    CloseHandle(fd);
    sc[ttyn].fd = INVALID_HANDLE_VALUE;
    return 0;
}

static
wait_for_io(HANDLE fd, OVERLAPPED *ovp, unsigned long *np, unsigned long timeo)
{
    while (1) {

	if (GetOverlappedResult(fd, ovp, np, FALSE))
	    /* i/o complete, got result */
	    return 0;

	if (GetLastError() != ERROR_IO_INCOMPLETE ||
	    WaitForSingleObject(ovp->hEvent, timeo) != WAIT_OBJECT_0)
	    /* error or timed out */
	    return SCTIMEO;
    }
}

/*
 * get one byte from the card.
 * wait at most ms msec.  0 for poll, -1 for infinite.
 * return byte in *cp.
 * return 0 or error.
 */

int
scgetc(int ttyn, char *cp, int ms)
{
    HANDLE fd = sc[ttyn].fd;
    static char buf[2];
    static unsigned long n1, n2;

    if (fd == INVALID_HANDLE_VALUE)
	return SCENOTTY;

    /* If the read timed out last time, then it's still pending */
    if (sc[ttyn].pending || !ReadFile(fd, buf, 1, &n1, &sc[ttyn].rdov)) {
	if (!sc[ttyn].pending && GetLastError() != ERROR_IO_PENDING)
	    return SCTIMEO;

	/* no result yet; wait for it */
	if (wait_for_io(fd, &sc[ttyn].rdov, &n2, ms)) {
	    sc[ttyn].pending++;
	    return SCTIMEO;
	}
	sc[ttyn].pending = 0;
    }

    if (cp)
	*cp = buf[0] & 0xff;
    return SCEOK; /* 0 */
}

/* write one byte to the card */

int
scputc(int ttyn, int ic)
{
    HANDLE fd = sc[ttyn].fd;
    static char buf[2];
    char gc;
    static unsigned long e, n1, n2;

    if (fd == INVALID_HANDLE_VALUE)
	return SCENOTTY;

    buf[0] = ic;

    if (!WriteFile(fd, buf, 1, &n1, &sc[ttyn].wrov)) {
	if (GetLastError() != ERROR_IO_PENDING)
	    return SCTIMEO;

	/* no result yet; wait for it */
	if (wait_for_io(fd, &sc[ttyn].wrov, &n2, 1000))
	    return SCTIMEO;
    }

    /* gobble up the echo */
    e = scgetc(ttyn, &gc, 100);
#ifdef DEBUG
    if (e != SCEOK)
	printf("failed to gobble\n");
    else if ((gc & 0xff) != ic)
	printf("gobbled wrong, %x != %x\n", gc & 0xff, ic);
#endif
    return SCEOK;
}

void
scsleep(int ms)
{
    static HANDLE h = INVALID_HANDLE_VALUE;

    if (h == INVALID_HANDLE_VALUE)
	h = CreateEvent(NULL, TRUE, FALSE, NULL);

    /* event will never be set; this will always time out */

    WaitForSingleObject(h, ms);
}

void
scdrain(int ttyn)
{
    HANDLE fd = sc[ttyn].fd;

    if (fd != INVALID_HANDLE_VALUE)
	PurgeComm(fd, PURGE_RXCLEAR | PURGE_RXABORT);
    sc[ttyn].pending = 0;
}

/*
copyright 1997
the regents of the university of michigan
all rights reserved

permission is granted to use, copy, create derivative works 
and redistribute this software and such derivative works 
for any purpose, so long as the name of the university of 
michigan is not used in any advertising or publicity 
pertaining to the use or distribution of this software 
without specific, written prior authorization.  if the 
above copyright notice or any other identification of the 
university of michigan is included in any copy of any 
portion of this software, then the disclaimer below must 
also be included.

this software is provided as is, without representation 
from the university of michigan as to its fitness for any 
purpose, and without warranty by the university of 
michigan of any kind, either express or implied, including 
without limitation the implied warranties of 
merchantability and fitness for a particular purpose. the 
regents of the university of michigan shall not be liable 
for any damages, including special, indirect, incidental, or 
consequential damages, with respect to any claim arising 
out of or in connection with the use of the software, even 
if it has been or is hereafter advised of the possibility of 
such damages.
*/
