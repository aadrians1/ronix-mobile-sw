/*
 * Send commands to a smartcard, using a dumb reader.
 *
 * Accepts the following commands:
 * 1,2: open port 1 or 2 (tty00, tty01 or com1, com2) (usually resets card too)
 * r: reset
 * f x.x: select fid
 * o ins p1 p2 p3: send "out" command
 * i ins p1 p2 p3: send "in" command
 * q: quit
 *
 * Jim Rees, University of Michigan, October 1997
 */
static char *rcsid = "$Id: lewis.c,v 1.1 1997/11/06 20:21:56 rees Exp $";

#include <stdio.h>

#include "scrw.h"

main()
{
    char c, buf[100];
    int fd = -1, n, ins, p1, p2, p3, f0, f1, r1, r2, err;
    extern int scatrto;

    printf("[12]\nr\nf a.b\no INS P1 P2 P3\ni INS P1 P2 P3\nq\n");

    while (fgets(buf, sizeof buf, stdin)) {
	c = buf[0];
	switch (c) {
	case '1':
	case '2':
	    if (sscanf(buf, "%*c %d", &f0) == 1)
		scatrto = f0;
	    /* Our reader uses DSR to indicate card present.  You might need
	       to change the flag to SCODCD. */
	    fd = scopen(c - '1', SCODSR, NULL);
	    if (fd < 0) {
		printf("can't open port %d\n", c - '0');
		break;
	    }
	case 'r':
	    n = screset(fd, buf, &err);
	    if (!n)
		printf("%s\n", scerrtab[err]);
	    else
		dump_reply(buf, n, 0, 0);
	    break;
	case 'f':
	    /* "open" (select) file */
	    sscanf(buf, "%*c %x.%x", &f0, &f1);
	    buf[0] = f0;
	    buf[1] = f1;
	    n = scwrite(fd, 0, 0xa4, 0, 0, 2, buf, &r1, &r2);
	    if (n == 2 && r1 == 144 && r2 == 0)
		printf("fid %x.%x ok\n", f0, f1);
	    else if (n != 2)
		printf("scwrite failed\n");
	    else if (r1 == 0x6a && r2 == 0x82)
		printf("file not found\n");
	    else
		dump_reply(buf, 0, r1, r2);
	    break;
	case 'i':
	    sscanf(buf, "%*c %x %x %x %x", &ins, &p1, &p2, &p3);
	    scan_data(buf, p3);
	    scwrite(fd, 0, ins, p1, p2, p3, buf, &r1, &r2);
	    dump_reply(buf, 0, r1, r2);
	    break;
	case 'o':
	    sscanf(buf, "%*c %x %x %x %x", &ins, &p1, &p2, &p3);
	    n = scread(fd, 0, ins, p1, p2, p3, buf, &r1, &r2);
	    dump_reply(buf, n, r1, r2);
	    break;
	case 'q':
	    scdtr(fd, 0);
	    goto out;
	}
    }

 out:
    scclose(fd);
    exit(0);
}

scan_data(p, n)
char *p;
int n;
{
    char buf[100];
    int i, r;

    printf("Enter %d data bytes (hex):\n", n);
    for (i = 0; i < n; i++) {
	scanf("%x", &r);
	*p++ = r;
    }
}

dump_reply(p, n, r1, r2)
char *p;
int n, r1, r2;
{
    int i;

    for (i = 0; i < n; i++)
	printf("%d:%x ", i + 1, p[i] & 0xff);
    if (n)
	printf("\n");
    if (r1)
	printf("%d (0x%x) %d (0x%x)\n", r1, r1, r2, r2);
}

/*
copyright 1997
the regents of the university of michigan
all rights reserved

permission is granted to use, copy, create derivative works 
and redistribute this software and such derivative works 
for any purpose, so long as the name of the university of 
michigan is not used in any advertising or publicity 
pertaining to the use or distribution of this software 
without specific, written prior authorization.  if the 
above copyright notice or any other identification of the 
university of michigan is included in any copy of any 
portion of this software, then the disclaimer below must 
also be included.

this software is provided as is, without representation 
from the university of michigan as to its fitness for any 
purpose, and without warranty by the university of 
michigan of any kind, either express or implied, including 
without limitation the implied warranties of 
merchantability and fitness for a particular purpose. the 
regents of the university of michigan shall not be liable 
for any damages, including special, indirect, incidental, or 
consequential damages, with respect to any claim arising 
out of or in connection with the use of the software, even 
if it has been or is hereafter advised of the possibility of 
such damages.
*/
