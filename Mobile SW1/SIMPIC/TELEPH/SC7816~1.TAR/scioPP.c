/*
 * OS dependent part, PalmPilot version
 *
 * Jim Rees, University of Michigan, March 1998
 * Original by Nate Binkerton
 */
static char *rcsid = "$Id: scioPP.c,v 1.2 1998/10/20 19:57:03 rees Exp $";

#include <SystemMgr.h>
#include <SerialMgr.h>

#include "scrw.h"

UInt refNum;

int
scopen(int ttyn, int flags, int *ep)
{
    Err err;
    SerSettingsType settings;

    if (err = SysLibFind("Serial Library", &refNum))
	goto bad;

    pr("SerOpen");
    if (err = SerOpen(refNum, ttyn, 9600L))
	goto bad;

    if (err = SerGetSettings(refNum, &settings))
	goto bad;

    settings.flags = (serSettingsFlagStopBits2
		    | serSettingsFlagParityOnM
		    | serSettingsFlagParityEvenM
		    | serSettingsFlagRTSAutoM
		    | serSettingsFlagCTSAutoM
		    | serSettingsFlagBitsPerChar8);

    if (err = SerSetSettings(refNum, &settings))
	goto bad;

    /* The open may or may not have reset the card.  Wait a while then flush
       anything that came in on the port. */
    pr("SerReceiveFlush");
    SerReceiveFlush(refNum, SysTicksPerSecond() / 4L);

    return 0;

 bad:
    if (ep)
	*ep = SCENOTTY;
    return -1;
}

/* query dsr on the port (usually indicates whether the card is present) */

int
scdsr(int ttyn)
{
    return 1;
}


/* dtr pin not available on pilot */
/* raise or lower dtr */

int
scdtr(int ttyn, int cmd)
{
    if (!scdsr(ttyn))
	return -1;
    return 0;
}

int
scclose(int ttyn)
{
    if (!SerClose(refNum))
	return -1;
    return 0;
}

/*
 * get one byte from the card.
 * wait at most ms msec.  0 for poll, -1 for infinite.
 * return byte in *cp.
 * return 0 or error.
 */

int
scgetc(int ttyn, char *cp, int ms)
{
    Err err;
    long ticks;

    if (ms <= 0)
	ticks = ms;
    else {
	ticks = ((long) ms * SysTicksPerSecond()) / 1000L;
	if (!ticks)
	    ticks = 1;
    }

    SerReceive(refNum, cp, 1L, ticks, &err);
    if (err == serErrLineErr)
	SerReceiveFlush(refNum, 1);

    return (err ? SCTIMEO : SCEOK);
}

/* write one byte to the card */

int
scputc(int ttyn, int ic)
{
    static char buf[2];
    Err err;

    buf[0] = ic;

    SerSend(refNum, buf, 1L, &err);
    if (err)
	return SCENOTTY;

    /* gobble up the echo */
    if (scgetc(ttyn, buf, 100) != SCEOK) {
	pr("gobble failure");
	return SCENOTTY;
    }

    return SCEOK;
}

void
scsleep(int ms)
{
    long ticks;

    if (ms <= 0)
	return;
    ticks = ((long) ms * SysTicksPerSecond()) / 1000L;
    if (!ticks)
	ticks = 1;
    SysTaskDelay(ticks);
}

/*
copyright 1998
the regents of the university of michigan
all rights reserved

permission is granted to use, copy, create derivative works 
and redistribute this software and such derivative works 
for any purpose, so long as the name of the university of 
michigan is not used in any advertising or publicity 
pertaining to the use or distribution of this software 
without specific, written prior authorization.  if the 
above copyright notice or any other identification of the 
university of michigan is included in any copy of any 
portion of this software, then the disclaimer below must 
also be included.

this software is provided as is, without representation 
from the university of michigan as to its fitness for any 
purpose, and without warranty by the university of 
michigan of any kind, either express or implied, including 
without limitation the implied warranties of 
merchantability and fitness for a particular purpose. the 
regents of the university of michigan shall not be liable 
for any damages, including special, indirect, incidental, or 
consequential damages, with respect to any claim arising 
out of or in connection with the use of the software, even 
if it has been or is hereafter advised of the possibility of 
such damages.
*/
