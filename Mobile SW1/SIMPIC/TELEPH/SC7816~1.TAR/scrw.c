/*
 * OS independent part
 *
 * Jim Rees, University of Michigan, October 1997
 */
static char *rcsid = "$Id: scrw.c,v 1.8 1998/07/16 22:46:36 rees Exp $";

#include <stdio.h>

#include "scrw.h"

/*
 * 7816 says ATR will appear within 40000 clocks (12 msec)
 * BUT some cards violate the spec and require more time
 * This can be overridden by setting scatrto
 */
#define ATRTO 120

/* error table */
char *scerrtab[] = {
    "ok",
    "no such tty",
    "out of memory",
    "timeout",
    "slag!",
    "card type not supported",
    "no card in reader",
};

/*
 * protocol parameters
 * If D is fractional, then D=1 and Dr is the reciprocal.
 * So D = D * Dr (does that make sense?)
 * timeout (work waiting time) is in msec, etu is in microsec.
 */

struct {
    int t, etu, cwt, bwt;
} scparam[4];

struct {
    short F, D, Dr;
} xtab[] = {
     372,  1,  1,
     372,  1,  1,
     558,  2,  1,
     744,  4,  1,
    1116,  8,  1,
    1488, 16,  1,
    1860,  1,  1,
     372,  1,  1,
     372,  1,  1,
     512,  1,  1,
     768,  1,  2,
    1024,  1,  4,
    1536,  1,  8,
    2048,  1, 16,
     372,  1, 32,
     372,  1, 64,
};

/* this should be in scparam */
int scatrto;

/* reset the card, and return answer to reset (atr) */

int
screset(int ttyn, char *atr, int *ep)
{
    int n, i, c, t, ts, t0, nhb, ta1 = -1, tb1 = -1, tc1 = -1, td1 = 0, tc2 = -1;
    int fi, di, F, D, Dr, N, WI, etu;
    unsigned char *ap, buf[33];

    if (ep)
	*ep = SCEOK;

    if (!atr)
	atr = buf;

    if (scdtr(ttyn, 0) < 0) {
	if (ep)
	    *ep = SCENOCARD;
	return 0;
    }

    /* 7816-3 sec 5.2 says >= 40000 clock cycles, ~=12 msec */
    scsleep(20);

    scdtr(ttyn, 1);

    if (!scatrto)
	scatrto = ATRTO;
    ap = (unsigned char *) atr;
    n = 0;

    /* wait scatrto for the first byte, 100 msec for subsequent.
       Spec says up to 1 sec between bytes, but in practice 100 seems plenty. */
    while (!scgetc(ttyn, (char *) ap, (n ? 100 : scatrto))) {
	ap++;
	n++;
    }

    if (!n) {
	if (ep)
	    *ep = SCESLAG;
	return 0;
    }

    ap = (unsigned char *) atr;

    ts = *ap++;
    if (ts != 0x3b) {
	if (ep)
	    *ep = SCENOSUPP;
	return n;
    }
    t0 = *ap++;
    if (t0 & 0x10)
	ta1 = *ap++;
    if (t0 & 0x20)
	tb1 = *ap++;
    if (t0 & 0x40)
	tc1 = *ap++;
    if (t0 & 0x80)
	td1 = *ap++;
    if (td1 & 0x10)
	*ap++;
    if (td1 & 0x20)
	*ap++;
    if (td1 & 0x40)
	tc2 = *ap++;
    if (td1 & 0x80)
	*ap++;

    /* got enough bytes? */

    if (ap - (unsigned char *) atr > n) {
	if (ep)
	    *ep = SCENOSUPP;
	return n;
    }

    t = td1 & 0xf;

    if (t == 0) {
	if (ta1 == -1) ta1 = 0x11;
	if (tc1 == -1) tc1 = 0;
	if (tc2 == -1) tc2 = 10;

	fi = (ta1 >> 4) & 0xf;
	di = ta1 & 0xf;

	F  = xtab[fi].F;
	D  = xtab[di].D;
	Dr = xtab[di].Dr;
	N  = tc1;
	WI = tc2;

	/* calculate etu and timeout ("work waiting time") based on protocol bytes.
	   etu is in microseconds, timeout in milliseconds.
	   see 7816-3 8.1 */

	scparam[ttyn].etu = etu = ((long) Dr * (long) F * 50L) / ((long) D * 179L);
	scparam[ttyn].cwt = (24L * (long) WI * (long) D * (long) etu) / ((long) Dr * 25L);
    } else if (t == 1) {
	if (ta1 == -1) ta1 = 32;
	if (tb1 == -1) tb1 = 0x4d;
	if (tc1 == -1) tc1 = 0;

	/* assume etu is 103 microseconds */
	scparam[ttyn].cwt = (2L * (tb1 & 0xf) + 11) * 103L / 1000;
	scparam[ttyn].bwt = 2L * ((tb1 >> 4) & 0xf) * 103L + 11L * 103L / 1000L;
	printf("%d cwt, %d bwt\n", scparam[ttyn].cwt, scparam[ttyn].bwt);
    }
    scparam[ttyn].t = t;

    return n;
}

/* This does the real work of transferring data to or from the card.  Since the ack
   handling is the same for both send and receive, we do it all here. */

static int
scioproc(int ttyn, int io, char *cp)
{
    return (!io ? scputc(ttyn, (*cp & 0xff)) : scgetc(ttyn, cp, scparam[ttyn].cwt));
}

static int
scioT0(int ttyn, int io, int cla, int ins, int p1, int p2, int p3, char *buf, int *sw1p, int *sw2p)
{
    int n = 0, ack, ackxins;
    char *bp = buf;
    char c;

    /* this is here for cyberflex javacard */
    scsleep(40);

    scputc(ttyn, cla);
    scputc(ttyn, ins);
    scputc(ttyn, p1);
    scputc(ttyn, p2);
    scputc(ttyn, p3);

#ifdef DEBUG
    printf("sent ins %x\n", ins);
#endif

    while (1) {
	/* read ack byte; see 7816-3 8.2.2 */
	if (scgetc(ttyn, &c, scparam[ttyn].cwt) != SCEOK) {
#ifdef DEBUG
	    printf("timeout reading ack\n");
#endif
	    return -1;
	}
	ack = (c & 0xff);

	if (ack == 0x60) {
	    /* null (no-op but resets timer) */
#ifdef DEBUG
	    printf("got 0x60 (null) ack; reset timer\n");
#endif
	    continue;
	}

	if ((ack & 0xf0) == 0x60 || (ack & 0xf0) == 0x90) {
	    /* SW1; get SW2 and return */
	    *sw1p = ack;
	    if (scgetc(ttyn, &c, scparam[ttyn].cwt) != SCEOK) {
#ifdef DEBUG
		printf("timeout reading sw2\n");
#endif
		return -1;
	    }
	    *sw2p = (c & 0xff);
	    break;
	}

	/* we would set VPP here if the interface supported it */

	ackxins = (ack ^ ins) & 0xfe;
	if (ackxins == 0xfe) {
	    /* xfer next data byte */
	    if (scioproc(ttyn, io, bp++) != SCEOK) {
#ifdef DEBUG
		printf("timeout reading next data byte\n");
#endif
		return -1;
	    }
	    n++;

	} else if (ackxins == 0) {
	    /* xfer all remaining data bytes */
	    while (n < p3) {
		if (scioproc(ttyn, io, bp++) != SCEOK) {
#ifdef DEBUG
		    printf("timeout reading all remaining data bytes\n");
#endif
		    return -1;
		}
		n++;
	    }

	} else {
	    /* ?? unknown ack byte */
#ifdef DEBUG
	    printf("unknown ack %x\n", ack);
	    continue;
#else
	    return -1;
#endif
	}
    }

    return n;
}

int
scwrite(int ttyn, int cla, int ins, int p1, int p2, int p3, char *buf, int *sw1p, int *sw2p)
{
    return scioT0(ttyn, 0, cla, ins, p1, p2, p3, buf, sw1p, sw2p);
}

int
scread(int ttyn, int cla, int ins, int p1, int p2, int p3, char *buf, int *sw1p, int *sw2p)
{
    return scioT0(ttyn, 1, cla, ins, p1, p2, p3, buf, sw1p, sw2p);
}

/*
copyright 1997
the regents of the university of michigan
all rights reserved

permission is granted to use, copy, create derivative works 
and redistribute this software and such derivative works 
for any purpose, so long as the name of the university of 
michigan is not used in any advertising or publicity 
pertaining to the use or distribution of this software 
without specific, written prior authorization.  if the 
above copyright notice or any other identification of the 
university of michigan is included in any copy of any 
portion of this software, then the disclaimer below must 
also be included.

this software is provided as is, without representation 
from the university of michigan as to its fitness for any 
purpose, and without warranty by the university of 
michigan of any kind, either express or implied, including 
without limitation the implied warranties of 
merchantability and fitness for a particular purpose. the 
regents of the university of michigan shall not be liable 
for any damages, including special, indirect, incidental, or 
consequential damages, with respect to any claim arising 
out of or in connection with the use of the software, even 
if it has been or is hereafter advised of the possibility of 
such damages.
*/
