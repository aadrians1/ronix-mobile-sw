/*
 * translate doggy doo into something useful
 *
 * Jim Rees, University of Michigan, April 1998
 */

#include <unistd.h>
#include <stdio.h>

int Dflag, pflag, rflag, iflag, cflag, uflag, vflag, xflag;
int money, updates;

char atr[20];
int atrlen;

struct cmd *lookup_cmd(int ins);

struct cmd {
    int ins, inout;
    char *name;
} cmdtab[] = {
    /* 7816-4 */
    0x0e, 0, "erase binary",
    0x20, 0, "verify",
    0x70, 0, "manage channel",
    0x82, 0, "ext auth",
    0x84, 1, "get challenge",
    0x88, 0, "int auth",
    0xb0, 1, "read binary",
    0xb2, 1, "read record",
    0xc0, 1, "get response",
    0xc2, 0, "envelope",
    0xca, 0, "get data",
    0xd0, 0, "write binary",
    0xd2, 0, "write record",
    0xd6, 0, "update binary",
    0xda, 0, "put data",
    0xdc, 0, "update record",
    0xe2, 0, "append record",
    0, 0, NULL
};

char *inouttab[] = {
    "in", "out", "?"
};

main(ac, av)
int ac;
char *av[];
{
    struct cmd *p;
    int i, n, class, ins, p1, p2, p3, ack, ackxins, sw1, sw2;
    unsigned char *bp, buf[32];

    while ((i = getopt(ac, av, "12m:t:uvx")) != -1) {
	switch (i) {
	case 'v':
	    vflag = 1;
	    break;
	case 'x':
	    xflag = 1;
	    break;
	}
    }

    parse_atr();

    while ((class = getbyte()) != -1) {
	ins = getbyte();
	p1 = getbyte();
	p2 = getbyte();
	p3 = getbyte();
	n = 0;
	bp = buf;
	while (1) {
	    /* read ack byte; see 7816-3 8.2.2 */
	    ack = getbyte();
	    if (ack == 0x60) {
		/* null (no-op but resets timer) */
		continue;
	    } else if ((ack & 0xf0) == 0x60 || (ack & 0xf0) == 0x90) {
		/* SW1; get SW2 and return */
		sw1 = ack;
		sw2 = getbyte();
		break;
	    } else if (ack < 0) {
		printf("EOF\n");
		break;
	    } else {
		ackxins = (ack ^ ins) & 0xfe;
		if (ackxins == 0xfe) {
		    /* xfer next data byte */
		    *bp++ = getbyte();
		    n++;
		} else if (ackxins == 0) {
		    /* xfer all remaining data bytes */
		    while (n < p3) {
			*bp++ = getbyte();
			n++;
		    }
		} else {
		    /* ?? unknown ack byte */
		    printf("unknown ack %x\n", ack);
		    continue;
		}
	    }
	}
	if (ack < 0)
	    break;
	p = lookup_cmd(ins);
	printf("%s %x %x %s %d:", p->name, p1, p2, inouttab[p->inout], p3);
	for (i = 0; i < p3; i++)
	    printf(" %02x", buf[i]);
	printf(" %x.%02x\n", sw1, sw2);
    }

    exit(0);
}

parse_atr()
{
    int n, i, c, t, ts, t0, nhb, ta1 = -1, tb1 = -1, tc1 = -1, td1 = 0, tc2 = -1;

    ts = getbyte();
    if (ts != 0x3b) {
	printf("TS=%02x (not direct conversion)\n", ts);
	return -1;
    }
    t0 = getbyte();
    nhb = t0 & 0xf;
    printf("T0=%02x, %d historical bytes\n", t0, nhb);
    if (t0 & 0x10) {
	ta1 = getbyte();
	printf("TA1=%02x\n", ta1);
    }
    if (t0 & 0x20) {
	tb1 = getbyte();
	printf("TB1=%02x\n", getbyte());
    }
    if (t0 & 0x40) {
	tc1 = getbyte();
	printf("TC1=%02x\n", tc1);
    }
    if (t0 & 0x80) {
	td1 = getbyte();
	printf("TD1=%02x\n", td1);
    }
    if (td1 & 0x10) {
	printf("TA2=%02x\n", getbyte());
    }
    if (td1 & 0x20) {
	printf("TB2=%02x\n", getbyte());
    }
    if (td1 & 0x40) {
	tc2 = getbyte();
	printf("TC2=%02x\n", tc2);
    }
    if (td1 & 0x80) {
	printf("TD2=%02x\n", getbyte());
    }
    t = td1 & 0xf;
    printf("T=%d\n", t);
    for (i = 0; i < nhb - 1; i++)
	getbyte();
}

getbyte()
{
    int b;

    if (scanf("%2x", &b) != 1)
	return -1;
    return b;
}

struct cmd *
lookup_cmd(int ins)
{
    struct cmd *p;
    static struct cmd dummy;
    static char name[32];

    for (p = &cmdtab[0]; p->name; p++)
	if (p->ins == ins)
	    break;

    if (!p->name) {
	dummy.ins = ins;
	dummy.inout = 2;
	sprintf(name, "unknown ins %02x", ins);
	dummy.name = name;
	p = &dummy;
    }

    return p;
}

/*
copyright 1998
the regents of the university of michigan
all rights reserved

permission is granted to use, copy, create derivative works 
and redistribute this software and such derivative works 
for any purpose, so long as the name of the university of 
michigan is not used in any advertising or publicity 
pertaining to the use or distribution of this software 
without specific, written prior authorization.  if the 
above copyright notice or any other identification of the 
university of michigan is included in any copy of any 
portion of this software, then the disclaimer below must 
also be included.

this software is provided as is, without representation 
from the university of michigan as to its fitness for any 
purpose, and without warranty by the university of 
michigan of any kind, either express or implied, including 
without limitation the implied warranties of 
merchantability and fitness for a particular purpose. the 
regents of the university of michigan shall not be liable 
for any damages, including special, indirect, incidental, or 
consequential damages, with respect to any claim arising 
out of or in connection with the use of the software, even 
if it has been or is hereafter advised of the possibility of 
such damages.
*/
