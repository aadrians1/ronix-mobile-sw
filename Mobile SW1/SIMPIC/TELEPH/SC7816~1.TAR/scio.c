/*
 * OS dependent part, Unix version
 *
 * Jim Rees, University of Michigan, October 1997
 */
static char *rcsid = "$Id: scio.c,v 1.4 1998/07/07 17:31:42 rees Exp $";

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/time.h>
#ifdef _AIX
#include <sys/select.h>
#endif

#include "scrw.h"

#ifdef _AIX
static char ttynametmpl[] = "/dev/tty%01d";
#else
#ifdef __OpenBSD__
static char ttynametmpl[] = "/dev/cua%02d";
#else
static char ttynametmpl[] = "/dev/tty%02d";
#endif
#endif

static struct {
    int fd;
    struct termios tio;
} sc[4];

int
scopen(int ttyn, int flags, int *ep)
{
    char ttyname[32];
    int fd, oflags;

    sprintf(ttyname, ttynametmpl, ttyn);
    oflags = O_RDWR;
    if (!(flags & SCODCD))
	oflags |= O_NONBLOCK;
    if ((fd = open(ttyname, oflags, 0)) < 0) {
	if (ep)
	    *ep = SCENOTTY;
	return -1;
    }

    if ((ttyn = scfdopen(ttyn, fd, flags, ep)) < 0) {
	close(fd);
	return -1;
    }

    if (flags & SCODSR)
	while (!scdsr(ttyn))
	    sleep(1);

    return ttyn;
}

int
scfdopen(int ttyn, int fd, int flags, int *ep)
{
    struct termios t;

    /* Get and save the tty state */

    if (tcgetattr(fd, &t) < 0) {
	if (ep)
	    *ep = SCENOTTY;
	return -1;
    }
    sc[ttyn].fd = fd;
    sc[ttyn].tio = t;

    /* Now put the tty in a happy ISO state */

    /* 9600 bps */
    cfsetispeed(&t, B9600);
    cfsetospeed(&t, B9600);

    /* raw */
    t.c_iflag &= ~(ISTRIP|INLCR|IGNCR|ICRNL|IXON);
    t.c_iflag |= (IGNBRK|IGNPAR);
    t.c_oflag &= ~OPOST;
    t.c_lflag &= ~(ECHO|ECHONL|ICANON|ISIG|IEXTEN);
    t.c_cc[VMIN] = 1;
    t.c_cc[VTIME] = 0;
#ifdef CHWFLOW
    t.c_cflag &= ~CHWFLOW;
#endif
    t.c_cflag |= CLOCAL;

    /* 8/E/2 */
    t.c_cflag &= ~(CSIZE | PARODD);
    t.c_cflag |= (CS8 | PARENB | CSTOPB);

    if (tcsetattr(fd, TCSANOW, &t) < 0) {
	if (ep)
	    *ep = SCENOTTY;
	sc[ttyn].fd = -1;
	return -1;
    }

    /* The open may or may not have reset the card.  Wait a while then flush
       anything that came in on the port. */
    scsleep(250);
    scdrain(ttyn);

    return ttyn;
}

int
scgetfd(int ttyn)
{
    return sc[ttyn].fd;
}

/* query dsr on the port (usually indicates whether the card is present) */

int
scdsr(int ttyn)
{
    int fd = sc[ttyn].fd;
    int i;

    if (fd < 0 || ioctl(fd, TIOCMGET, &i) < 0)
	return 0;

    return ((i & TIOCM_DSR) ? 1 : 0);
}

/* raise or lower dtr */

int
scdtr(int ttyn, int cmd)
{
    int fd = sc[ttyn].fd;
    int i;

    if (!scdsr(ttyn))
	return -1;

    if (ioctl(fd, TIOCMGET, &i) < 0)
	return -1;

    if (cmd)
	i |= TIOCM_DTR;
    else
	i &= ~TIOCM_DTR;

    return ioctl(fd, TIOCMSET, &i);
}

int
scclose(int ttyn)
{
    int fd = sc[ttyn].fd;

    tcsetattr(fd, TCSANOW, &sc[ttyn].tio);
    close(fd);
    sc[ttyn].fd = -1;
    return 0;
}

/*
 * get one byte from the card.
 * wait at most ms msec.  0 for poll, -1 for infinite.
 * return byte in *cp.
 * return 0 or error.
 */

int
scgetc(int ttyn, char *cp, int ms)
{
    int fd = sc[ttyn].fd;
    fd_set fdset;
    struct timeval tv, *tvp;

    FD_ZERO(&fdset);
    FD_SET(fd, &fdset);

    if (ms == -1)
	tvp = NULL;
    else {
	tv.tv_sec = (ms + 1) / 1000;
	tv.tv_usec = (ms % 1000) * 1000;
	tvp = &tv;
    }

    if (select(fd + 1, &fdset, NULL, NULL, tvp) != 1)
	return SCTIMEO;

    if (read(fd, cp, 1) != 1)
	return SCTIMEO;

    return SCEOK; /* 0 */
}

/* write one byte to the card */

int
scputc(int ttyn, int ic)
{
    int fd = sc[ttyn].fd;
    char c = ic;

    write(fd, &c, 1);

    /* gobble up the echo */
    return scgetc(ttyn, &c, 20);
}

void
scsleep(int ms)
{
    struct timeval tv;

    if (!ms)
	return;
    tv.tv_sec = (ms + 1) / 1000;
    tv.tv_usec = (ms % 1000) * 1000;

    select(0, NULL, NULL, NULL, &tv);
}

void
scdrain(int ttyn)
{
    tcflush(sc[ttyn].fd, TCIFLUSH);
}

/*
copyright 1997
the regents of the university of michigan
all rights reserved

permission is granted to use, copy, create derivative works 
and redistribute this software and such derivative works 
for any purpose, so long as the name of the university of 
michigan is not used in any advertising or publicity 
pertaining to the use or distribution of this software 
without specific, written prior authorization.  if the 
above copyright notice or any other identification of the 
university of michigan is included in any copy of any 
portion of this software, then the disclaimer below must 
also be included.

this software is provided as is, without representation 
from the university of michigan as to its fitness for any 
purpose, and without warranty by the university of 
michigan of any kind, either express or implied, including 
without limitation the implied warranties of 
merchantability and fitness for a particular purpose. the 
regents of the university of michigan shall not be liable 
for any damages, including special, indirect, incidental, or 
consequential damages, with respect to any claim arising 
out of or in connection with the use of the software, even 
if it has been or is hereafter advised of the possibility of 
such damages.
*/
