/*
 * Smartcard snooper
 * Jim Rees, University of Michigan
 */

#include <stdio.h>
#include <sys/time.h>

#include "scrw.h"

#define MAXCOLLECT 400

int port = 0;
int timeo = 20;
int vflag;

main(ac, av)
int ac;
char *av[];
{
    int fd, i, n;
    char buf[MAXCOLLECT];
    struct timeval tv0, tv1, tvd;

    while (ac > 1 && av[1][0] == '-') {
	switch (av[1][1]) {
	case '1':
	case '2':
	    port = av[1][1] - '1';
	    break;
	case 't':
	    timeo = atoi(av[2]);
	    ac--;
	    av++;
	    break;
	case 'v':
	    vflag = 1;
	    break;
	}
	ac--;
	av++;
    }

    setlinebuf(stdout);

    fd = scopen(port, SCODCD, NULL);
    if (fd < 0) {
	fprintf(stderr, "can't open port %d\n", port);
	exit(1);
    }
    tv0.tv_sec = 0;

    while (1) {
	if (scgetc(fd, &buf[0], -1) != SCEOK)
	    break;
	if (tv0.tv_sec == 0)
	    gettimeofday(&tv0, NULL);

	n = 1;
	while (scgetc(fd, &buf[n], timeo) == SCEOK && n < MAXCOLLECT)
	    n++;
	gettimeofday(&tv1, NULL);
	timersub(&tv1, &tv0, &tvd);

	if (vflag)
	    printf("%02d%03dms ", tvd.tv_sec, tvd.tv_usec / 1000);

	for (i = 0; i < n; i++)
	    printf("%02x ", buf[i] & 0xff);
	printf("\n");
    }

    exit(0);
}

/*
copyright 1998
the regents of the university of michigan
all rights reserved

permission is granted to use, copy, create derivative works 
and redistribute this software and such derivative works 
for any purpose, so long as the name of the university of 
michigan is not used in any advertising or publicity 
pertaining to the use or distribution of this software 
without specific, written prior authorization.  if the 
above copyright notice or any other identification of the 
university of michigan is included in any copy of any 
portion of this software, then the disclaimer below must 
also be included.

this software is provided as is, without representation 
from the university of michigan as to its fitness for any 
purpose, and without warranty by the university of 
michigan of any kind, either express or implied, including 
without limitation the implied warranties of 
merchantability and fitness for a particular purpose. the 
regents of the university of michigan shall not be liable 
for any damages, including special, indirect, incidental, or 
consequential damages, with respect to any claim arising 
out of or in connection with the use of the software, even 
if it has been or is hereafter advised of the possibility of 
such damages.
*/
