/*
 * -v verbose
 * -t atr delay
 * -x print every byte (very verbose)
 *
 * Emulate a smartcard.  For use with an inverse reader.
 *
 * Jim Rees, University of Michigan, October 1997
 */
static char *rcsid = "$Id: clark.c,v 1.1 1997/11/06 20:12:21 rees Exp $";

#ifdef __unix__
#include <unistd.h>
#endif
#include <stdio.h>

#include "scrw.h"

#ifndef __unix__
/* stuff for getopt() */
char *__progname = "balance";
extern char	*optarg;
#endif

int vflag, xflag;

char atr[] = {0x3b, 0x23, 0x0, 0x35, 0x11, 0x80};

/* Our file system.  Each entry is a file, and has a fid, record length, and
   one record.
   The ones with no data are directories (DFs).
 */

struct fidtab {
    int f0, f1, len;
    char data[16];
} fidtab[] = {
    {0x3f, 0, 0, {0}},
    {1, 1, 10, {0x72, 0x65, 0x63, 0x6f, 0x72, 0x64, 0x20, 0x6f, 0x6e, 0x65}},
    {1, 2, 13, {0x73, 0x65, 0x63, 0x6f, 0x6e, 0x64, 0x20, 0x72, 0x65, 0x63, 0x6f, 0x72, 0x64}},
    {0, 0, -1, {0}}
};

main(ac, av)
int ac;
char *av[];
{
    char buf[100];
    int port = 0, fd, atrdly = 40, i;

    while ((i = getopt(ac, av, "12t:vx")) != -1) {
	switch (i) {
	case '1':
	case '2':
	    port = i - '1';
	    break;
	case 't':
	    /* set atr delay */
	    atrdly = atoi(optarg);
	    break;
	case 'v':
	    vflag = 1;
	    break;
	case 'x':
	    xflag = 1;
	    break;
	}
    }

    /* open leon device */
    fd = scopen(port, SCODCD, NULL);
    if (fd < 0) {
	printf("can't open leon device\n");
	exit(1);
    }

    scsleep(atrdly);
    vcuwrite(fd, 0, atr, sizeof atr);
    if (vflag)
	printf("open, sent atr after %d ms delay\n", atrdly);

    while (1) {
	vcuread(fd, 0, buf, 5);
	if (vflag)
	    print_cmd(buf);
	respond_cmd(fd, buf);
    }

    scclose(fd);
    exit(0);
}

print_cmd(cmd)
char *cmd;
{
    int i;

    printf("cmd: ");
    for (i = 0; i < 5; i++)
	printf("%02x ", cmd[i] & 0xff);
    printf("\n");
}

respond_cmd(fd, cmd)
int fd;
char *cmd;
{
    int i, ins, p1, p2, len, f0, f1;
    char buf[64];
    static struct fidtab *fidp;

    ins = cmd[1] & 0xff;
    p1 = cmd[2] & 0xff;
    p2 = cmd[3] & 0xff;
    len = cmd[4] & 0xff;

    switch (ins) {
    case 0xa4:
	/* select fid */
	vcuread(fd, ins, buf, 2);
	f0 = buf[0] & 0xff; f1 = buf[1] & 0xff;
	printf("select fid %x.%x\n", f0, f1);

	/* find fid in the table */
	for (fidp = &fidtab[0]; fidp->len >= 0; fidp++)
	    if (fidp->f0 == f0 && fidp->f1 == f1)
		break;
	if (fidp->len >= 0)
	    write_sw(fd, 0x90, 0);
	else
	    /* file not found */
	    write_sw(fd, 0x6a, 0x82);
	break;
    case 0xb2:
	/* read record */
	if (!fidp || fidp->len < 0) {
	    /* no fid selected */
	    write_sw(fd, 0x69, 0x85);
	    break;
	}
	printf("read %d\n", len);
	if (len != fidp->len) {
	    /* wrong length */
	    write_sw(fd, 0x67, 0);
	    break;
	}
	vcuwrite(fd, ins, fidp->data, fidp->len);
	write_sw(fd, 0x90, 0);
	break;
    case 0xd2:
	/* write record */
	vcuread(fd, ~ins, buf, len);
	write_sw(fd, 0x90, 0);
	if (vflag) {
	    printf("write rec ");
	    for (i = 0; i < len; i++)
		printf("%02x ", buf[i] & 0xff);
	    printf("\n");
	}
	break;
    default:
	printf("unknown command %02x %02x %02x %02x\n", ins, p1, p2, len);
	break;
    }
}

vcuread(fd, ack, buf, n)
int fd, ack, n;
char *buf;
{
    int i;

    for (i = 0; i < n; i++) {
	if (ack && (i == 0 || (ack & 1)))
	    scputc(fd, ack);
	if (scgetc(fd, &buf[i], -1))
	    return -1;
	if (xflag)
	    printf("%02x\n", buf[i] & 0xff);
    }
    return n;
}

vcuwrite(fd, ack, buf, n)
int fd, ack, n;
char *buf;
{
    int i;

    if (ack)
	scputc(fd, ack);
    for (i = 0; i < n; i++)
	scputc(fd, buf[i] & 0xff);
    return n;
}

/* write sw1 and sw2 reply */

write_sw(fd, sw1, sw2)
int fd, sw1, sw2;
{
    char buf[2];

    buf[0] = sw1;
    buf[1] = sw2;
    vcuwrite(fd, 0, buf, 2);
}

/*
copyright 1997
the regents of the university of michigan
all rights reserved

permission is granted to use, copy, create derivative works 
and redistribute this software and such derivative works 
for any purpose, so long as the name of the university of 
michigan is not used in any advertising or publicity 
pertaining to the use or distribution of this software 
without specific, written prior authorization.  if the 
above copyright notice or any other identification of the 
university of michigan is included in any copy of any 
portion of this software, then the disclaimer below must 
also be included.

this software is provided as is, without representation 
from the university of michigan as to its fitness for any 
purpose, and without warranty by the university of 
michigan of any kind, either express or implied, including 
without limitation the implied warranties of 
merchantability and fitness for a particular purpose. the 
regents of the university of michigan shall not be liable 
for any damages, including special, indirect, incidental, or 
consequential damages, with respect to any claim arising 
out of or in connection with the use of the software, even 
if it has been or is hereafter advised of the possibility of 
such damages.
*/
