/*
 * Discard - The software interface for the Simple Smartcard Reader (SSR)
 * http://www.nykoping.com/johan/discard/
 *
 * ui.c - the user interface
 *
 * Copyright (c) 1998 Johan Larsson, johan@nykoping.com
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <bios.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "ui.h"
#include "defines.h"
#include "canalyse.h"
#include "ssrio.h"


void clean_up(void)
{
  _set_screen_lines(TEXT_EXIT);
  textbackground(BLACK);
  textcolor(LIGHTGRAY);
  _setcursortype(_NORMALCURSOR);
  clrscr();

  printf("Discard %s by Johan Larsson\n"
         "Copyright (c) 1998 Johan Larsson, johan@nykoping.com\n"
         "%s\n",VERSION,URL);

 exit(0);
}



void init_screen(void)
{
  _setcursortype(_NOCURSOR);
  clrscr();
}



void draw_lowermenu(char **text, int nr)
{
 int i,x;

  textbackground(LIGHTGRAY);

  window(1,1,ScreenCols(),ScreenRows());

  gotoxy(1,ScreenRows());

  for(i=0;i<nr*2;i+=2){
   textcolor(RED);
   cprintf(" %s",text[i]);
   textcolor(BLACK);
   cprintf(" %s",text[i+1]);
  }

  for(x=wherex();x<ScreenCols()-5;x++)
   cprintf(" ");
}



void draw_main_screen(void)
{
 int i,x;

 textbackground(LIGHTGRAY);
 clrscr();
 gotoxy(1,2);
 textbackground(LIGHTGRAY);

  for(i=1;i<(ScreenRows()-1);i++)
   for(x=0;x<ScreenCols();x++)
    ScreenPutChar(BACKGROUND_CHAR,(LIGHTGRAY << 4) | BLUE,x,i); //putch(BACKGROUND_CHAR);


 gotoxy(1,1);
 textcolor(BLACK);
 cprintf(" Discard %s",VERSION);

 gotoxy(ScreenCols()-5,1);
 cprintf("%dx%d",ScreenCols(),ScreenRows());

 gotoxy(ScreenCols()-5,ScreenRows());
 cprintf("%#x",LPT_DATA);

}


int draw_menu(int width, int height)
{
 int i,key, hilite=0,x1,x2,y1,y2;
 char *bar[]={"F1","Info","F3","Open","Ctrl+R","Read","Alt+X","Quit"};
 char *menu[]={"Read Telecard","Open dumped Telecard","Information","Quit"};
 int no_of_args=4;
 int bg1=BLUE;
 int bg2=LIGHTGRAY;
 int fg1=WHITE;
 int fg2=WHITE;

 draw_lowermenu(bar,4);

  x1 = (ScreenCols()-width)/2;
  x2 = x1+width;

  y1 = (ScreenRows()-height)/2;
  y2 = y1+height;

  popup_window(bg1,x1,y1,x2,y2,"Discard");

  textcolor(fg1);

  gotoxy(x1+7,((y2-y1+1)/2-no_of_args/2)+y1-1);
  for(i=0;i<no_of_args;i++){gotoxy(x1+7,wherey()+1);cprintf("%s",menu[i]);}

  gotoxy(x1+4,((y2-y1+1)/2-no_of_args/2)+y1);
  textbackground(bg2);
  textcolor(fg2);
  cprintf(" %c %s",SELECT_CHAR,menu[0]);

  while(wherex()-x2+3!=0)
   putch(' ');

  textcolor(fg1);
  textbackground(bg1);

  while (!DONE)
  {
    key = bioskey(0);
    switch(key)
    {
      case 0x5000:
         if(hilite==no_of_args-1)
          break;
         gotoxy(x1+4,wherey());
			cprintf("   %s",menu[hilite++]);
         while(wherex()-x2+3!=0)
			 putch(' ');
         gotoxy(x1+4,wherey()+1);
			textbackground(bg2);
         textcolor(fg2);
			cprintf(" %c %s",SELECT_CHAR,menu[hilite]);
			while(wherex()-x2+3!=0)
			 putch(' ');
			textbackground(bg1);
         textcolor(fg1);
			break;
      case 0x4800:
         if(hilite==0)
          break;
			gotoxy(x1+4,wherey());
			cprintf("   %s",menu[hilite--]);
			while(wherex()-x2+3!=0)
			 putch(' ');
         gotoxy(x1+4,wherey()-1);
			textbackground(bg2);
         textcolor(fg2);
			cprintf(" %c %s",SELECT_CHAR,menu[hilite]);
			while(wherex()-x2+3!=0)
			 putch(' ');
			textbackground(bg1);
         textcolor(fg1);
         break;
      case 0x1c0d: /*Enter*/
                   return(hilite);
      case 0x2300: /*ALT+H*/
      case 0x3b00: /*F1*/
                   return 2;/*Info*/
      case 0x3d00: /*F3*/
                   return 1;/*Open*/
      case 0x1312: /*Ctrl+R*/
                   return 0;/*Read*/
      case 0x4400: /*F10*/
      case 0x2d00: /*Alt+X*/
                   return 3;/*Quit*/
      /*case 0x3f00: _set_screen_lines(50);
                   draw_main_screen();
                   draw_menu(40,9);
                   break;*/
    }
  }

 return 4; /*ERROR*/
}



void draw_color_screen(int color,char x1,char y1,char x2,char y2)
{
 int y,x;

  gotoxy(x1,y1);

  for(y=0;y<y2-y1+1;y++){
   gotoxy(x1,y1+y);
   for(x=0;x<x2-x1+1;x++)
    ScreenPutChar(' ',(color<<4) | color,x1+x,y1+y);

   usleep(WINDOW_POPUP_DELAY);
  }
}


void remove_window(char x1,char y1,char x2,char y2)
{
 int y,x;



  for(y=0;y<y2-y1+2;y++){
   gotoxy(x1,y1+y);
   for(x=0;x<x2-x1+2;x++)
    ScreenPutChar(BACKGROUND_CHAR,(LIGHTGRAY << 4) | BLUE,x1-1+x,y1-1+y); //putch(' ');
  }
}


char *draw_input_window(int width, int height,char *title,char *text,int input_width)
{
 int i;
 int x1,x2,y1,y2;
 char temp[8];
 int slask;
 char input[13];

  memset(input,'\0',13);

  x1 = (ScreenCols()-width)/2;
  x2 = x1+width;

  y1 = (ScreenRows()-height)/2;
  y2 = y1+height;


  popup_window(GREEN,x1,y1,x2,y2,title);

  gotoxy(((x2-x1)/2-strlen(text)/2)+x1,((y2-y1+1)/2+y1)-2);
   cprintf("%s",text);

  gotoxy(((x2-x1)/2-input_width/2)+x1,((y2-y1+1)/2+y1));
  textbackground(BLACK);

  for(i=0;i<input_width;i++)
   putch(' ');

  gotoxy(wherex()-input_width,wherey());

  _setcursortype(_NORMALCURSOR);

  i=0;

  while(1)
  {

    slask=bioskey(0);

    if(isprint(slask&0xFF)){
     temp[i]=slask;
     temp[i+1]='\0';
     if(i<7){
      i++;
      cprintf("%c",slask);
      } else if(i==7){
       cprintf("%c",slask);
       gotoxy(wherex()-1,wherey());
      }
     } else switch(slask){

     case 0x4f00: /*END*/
     case 0x011b: /*ESC*/
     case 0x3e00: /*F4*/

        _setcursortype(_NOCURSOR);
        return strdup("ERROR");

     case 0x0e08: /*BACKSPACE*/

         if(i==0)
          break;
         putch(' ');
         gotoxy(wherex()-2,wherey());
         temp[i]='\0';
         i--;
         break;

      case 0x1c0d: /*ENTER*/

         strncpy(input,temp,8);
         strcat(input,".dmp\0");
         strlwr(input);

         _setcursortype(_NOCURSOR);

         return strdup(input);
    }

  }

 _setcursortype(_NOCURSOR);
 window(1,1,ScreenCols(),ScreenRows());
 return strdup("ERROR");
}



void popup_window(int color,int x1, int y1,int x2,int y2,char *title)
{
 int X1,Y1,X2,Y2,i;
 int ch;

 window(1,1,ScreenCols(),ScreenRows());

  X1=X2=ScreenCols()/2;
  Y1=Y2=ScreenRows()/2;

 while( !(x1==X1) || !(x2==X2) || !(y1==Y1) || !(y2==Y2) ){
  if(X1>x1) X1-=1;
  if(Y1>y1) Y1-=1;
  if(X2<x2) X2+=1;
  if(Y2<y2) Y2+=1;

  draw_color_screen(color,X1,Y1,X2-2,Y2-2);
 }
  textcolor(WHITE);
  textbackground(color);

  gotoxy(X1,Y1);putch('�'); //�
  gotoxy(X2,Y1);putch('�'); //�
  gotoxy(X1,Y2);putch('�'); //�
  gotoxy(X2,Y2);putch('�'); //�

  gotoxy(X1+1,Y1);
  for(i=0;i<X2-X1-1;i++)
   putch('�');

  gotoxy(X1+1,Y2);
  for(i=0;i<X2-X1-1;i++)
   putch('�');

  gotoxy(X1+1,Y1);
  for(i=0;i<Y2-Y1-1;i++)
   cprintf("\n\b�");

  gotoxy(X2+1,Y1);
  for(i=0;i<Y2-Y1-1;i++)
   cprintf("\n\b�");


  for(i=x1;i<x2+1;i++){
   ScreenGetChar(&ch, NULL, i, y2);
   ScreenPutChar(ch,DARKGRAY,i,y2);
  }

  for(i=y1;i<y2+1;i++){
   ScreenGetChar(&ch, NULL, x2, i);
   ScreenPutChar(ch,DARKGRAY,x2,i);
  }

  gotoxy(((x2-x1)/2-strlen(title)/2)+x1-2,y1);
  cprintf("%c %s %c",TITLE_LEFT_CHAR,title,TITLE_RIGHT_CHAR);
}



void draw_info_window(int width, int height)
{
 int key,x1,x2,y1,y2;
 char *bar[]={"ESC","Return to menu", "","Scroll","PGDN","Down one screen","PGUP","Up one screen"};
 FILE *info;
 int INFO_FILE_AVAIL=FALSE;
 int max_lines=0,line=0;

  x1 = (ScreenCols()-width)/2;
  x2 = x1+width;

  y1 = (ScreenRows()-height)/2;
  y2 = y1+height;

  draw_lowermenu(bar,4);

  popup_window(BLUE,x1,y1,x2,y2,"Information - discard.txt");


  window(x1+1,y1+1,x2-1,y2-1);

  textcolor(WHITE);

    height=height-3;
    width=width-2;

  if((info = fopen("discard.txt", "rt")) == NULL)
   cprintf("discard.txt not found");
  else {

    INFO_FILE_AVAIL = TRUE;

    while(!feof(info)){
     fgets(NULL,80,info);
     max_lines++;
    }

    print_info_page(info,line,max_lines,width,height);

    textcolor(LIGHTBLUE);
    gotoxy(1,height+2);
    cprintf("Use arrowkeys and PageUp/PageDown to navigate");
   }

  while (!DONE)
  {
    key = bioskey(0);
    switch(key)
    {

      case 0x4800: /*UP*/

                  if(INFO_FILE_AVAIL){

                   if(line>0){
                    line--;
                    print_info_page(info,line,max_lines,width,height);
                   }

                  }

                  usleep(INFO_WINDOW_REFRESH);

                  break;

      case 0x5000: /*DOWN*/

                  if(INFO_FILE_AVAIL){

                   if(line!=max_lines-height){

                    if(line< max_lines-height )
                     line++;
                    else line=max_lines-height;

                    print_info_page(info,line,max_lines,width,height);

                   }
                  }
                  usleep(INFO_WINDOW_REFRESH);

                  break;


      case 0x4900: /*PGUP*/

                  if(INFO_FILE_AVAIL){

                   if(line!=0){

                    if( (line-height) >0 )
                     line-=height;
                    else line=0;

                    print_info_page(info,line,max_lines,width,height);

                   }
                  }
                  usleep(INFO_WINDOW_REFRESH);
                  break;

      case 0x5100: /*PGDN*/

                  if(INFO_FILE_AVAIL){

                   if(line!=max_lines-height){
                    if(line+height<max_lines-height)
                     line+=height;
                    else line=max_lines-height;

                  print_info_page(info,line,max_lines,width,height);

                   }
                  }
                  usleep(INFO_WINDOW_REFRESH);
                  break;

      case 0x4f00: /*END*/
      case 0x011b: /*ESC*/
      case 0x3e00: /*F4*/
                   remove_window(x1,y1,x2,y2);
                   return;
    }
  }

}


void draw_save_window(int width, int height, char *dump)
{
 int x1,x2,y1,y2,key;
 char *bar[]={"ESC","Return to menu","ENTER","Save file"};
 char filename[13];
 FILE *f;

  x1 = (ScreenCols()-width)/2;
  x2 = x1+width;

  y1 = (ScreenRows()-height)/2;
  y2 = y1+height;

  draw_lowermenu(bar,2);

  strncpy(filename,draw_input_window(width,height,"Save *.dmp","Please enter filename",8),12);


 if(!strcmp(filename,"ERROR")){
  remove_window(x1,y1,x2,y2);
  return;
 }

  draw_lowermenu(bar,1);

  textbackground(GREEN);
  textcolor(LIGHTGREEN);

  f = fopen(strcat(DUMP_DIR,filename), "wt");

  if(f == NULL){

    gotoxy(((x2-x1)/2-(20+strlen(filename))/2)+x1,((y2-y1+1)/2+y1)+2);
    cprintf("Could not write to %.12s!",filename);

    while(!DONE){
     key = bioskey(0);

     switch(key)
     {
       case 0x4f00: /*END*/
       case 0x011b: /*ESC*/
       case 0x3e00: /*F4*/
                    fclose(f);
                    remove_window(x1,y1,x2,y2);
                    return;
     }
    }
  } else {
           fprintf(f,"# Discard save file.\n");
           fprintf(f,"> %.256s\n",dump);

           gotoxy(((x2-x1)/2-(15+strlen(filename))/2)+x1,((y2-y1+1)/2+y1)+2);
           textbackground(GREEN);
           textcolor(LIGHTGREEN);
           cprintf("Dump saved to %.12s!",filename);

           while(!kbhit());
         }

 fclose(f);
 remove_window(x1,y1,x2,y2);
 return;
}


void draw_open_window(int width, int height)
{
 char filename[14];
 int key,x1,x2,y1,y2,DISCARD_SAVE_FILE=FALSE;
 int done=FALSE;
 char *bar[]={"ESC","Return to menu","ENTER","Open file"};
 char smartcard_mem[MEM_SIZE];
 card c;
 FILE *f;
 char id[2];
 char slask[MEM_SIZE];


  x1 = (ScreenCols()-width)/2;
  x2 = x1+width;

  y1 = (ScreenRows()-height)/2;
  y2 = y1+height;


 draw_lowermenu(bar,2);

 strncpy(filename,draw_input_window(width,height,"Open *.dmp","Please enter filename",8),12);

 if(!strcmp(filename,"ERROR")){
  remove_window(x1,y1,x2,y2);
  return;
 }

  textbackground(GREEN);
  textcolor(LIGHTGREEN);

  draw_lowermenu(bar,1);

  f = fopen(strcat(DUMP_DIR,filename), "rt");

  if( f == NULL ){
    textbackground(GREEN);
    textcolor(LIGHTGREEN);

    gotoxy(((x2-x1)/2-(15+strlen(filename))/2)+x1,((y2-y1+1)/2+y1)+2);
    cprintf("File %.12s not found!",filename);

    while(!done){
     key = bioskey(0);

     switch(key)
       {
         case 0x4f00: /*END*/
         case 0x011b: /*ESC*/
         case 0x3e00: /*F4*/
                      fclose(f);
                      remove_window(x1,y1,x2,y2);
                      return;
       }
    }
   }


   while(!feof(f)){

    fscanf(f,"%s %s",id,slask);

    if(id[0]=='>' && !DISCARD_SAVE_FILE){
     strncpy(smartcard_mem,slask,MEM_SIZE);
     DISCARD_SAVE_FILE=TRUE;
    }
   }


   if(!DISCARD_SAVE_FILE){
    gotoxy(((x2-x1)/2-18/2)+x1,((y2-y1+1)/2+y1)+2);
    cprintf("Not a discard file!");

    while(!done){
     key = bioskey(0);

     switch(key)
      {
         case 0x4f00: /*END*/
         case 0x011b: /*ESC*/
         case 0x3e00: /*F4*/
                      fclose(f);
                      remove_window(x1,y1,x2,y2);
                      return;
       }
    }
   }


   width=60;
   height=15;

   x1 = (ScreenCols()-width)/2;
   x2 = x1+width;

   y1 = (ScreenRows()-height)/2;
   y2 = y1+height;


   popup_window(BLUE,x1,y1,x2,y2,strcat("Analysation of ",filename));

   window(x1+2,y1+2,x2-2,y2-2);

   clrscr();

   analyse_dump(smartcard_mem,&c);

   print_analysation(&c);

  while(!done){
    key = bioskey(0);

    switch(key)
    {
     case 0x4f00: /*END*/
     case 0x011b: /*ESC*/
     case 0x3e00: /*F4*/
                    done=TRUE;
    }
  }


 fclose(f);
 remove_window(x1,y1,x2,y2);
 return;
}


void draw_read_window(int width, int height)
{
 int key,x1,x2,y1,y2;
 char *bar[]={"ESC","Return to menu","F2","Save"};
 int done=FALSE;
 char smartcard_mem[MEM_SIZE+1];
 card c;


 draw_lowermenu(bar,1);

  x1 = (ScreenCols()-width)/2;
  x2 = x1+width;

  y1 = (ScreenRows()-height)/2;
  y2 = y1+height;


  _setcursortype(_NOCURSOR);
  textbackground(BLUE);
  textcolor(WHITE);

  popup_window(BLUE,x1,y1,x2,y2,"Read Telecard");

  window(x1+2,y1+2,x2-2,y2-2);

  SSR_green_led(TRUE);

  cprintf("Make sure that your Simple Smartcard Reader (SSR)\n\r"
          "device is properly connected to your parallellport and\n\r"
          "that your parallellport�s address (hex) is shown in the\n\r"
          "lower right corner of this screen.\n\n\r"
          //"The green LED on the SSR should be lit now.\n\n\r"
          "Please insert the telecard you want to analyse.\n\n\r"
          "Press ");
  textcolor(YELLOW);
  cprintf("Spacebar");
  textcolor(WHITE);
  cprintf(" to start...\r\n");


 while(!done){
  key = bioskey(0);

  switch(key)
    {
      case 0x4f00: /*END*/
      case 0x011b: /*ESC*/
      case 0x3e00: /*F4*/
                   remove_window(x1,y1,x2,y2);
                   return;
      case 0x3920: done=TRUE;break;
    }
 }

  SSR_green_led(FALSE);

  clrscr();

  if(SSR_card_present()){

   textbackground(BLUE);
   textcolor(WHITE);

   strncpy(smartcard_mem,SSR_dump_memory(),MEM_SIZE);

   analyse_dump(smartcard_mem,&c);

   print_analysation(&c);

   draw_lowermenu(bar,2);
  } else {

    textbackground(BLUE);
    textcolor(LIGHTGREEN);

    cprintf("Please insert a telecard into the SSR.");
  }

  done=FALSE;
  while(!done){
   key = bioskey(0);

   switch(key)
   {
      case 0x4f00: /*END*/
      case 0x011b: /*ESC*/
      case 0x3e00: /*F4*/
                   done=TRUE;break;
      case 0x3c00: /*F2*/
                   draw_save_window(40,9,smartcard_mem);
                   done=TRUE;
                   break;
   }
 }

 remove_window(x1,y1,x2,y2);
}


void print_info_page(FILE *info,int start_line, int max_lines,int width,int height)
{
 char line[256];
 int line_nr=0;

 rewind(info);

 while(!feof(info) && line_nr <=start_line+height){

  fgets(line,width,info);

  if(start_line <= line_nr && line_nr <= start_line+height ){

   if(start_line==line_nr)
    clrscr();

   if(strstr(line,"�"))
    textcolor(LIGHTGREEN);
   else if( strstr(line,"~")  || strstr(line,"�"))
    textcolor(YELLOW);
   else if( strstr(line,"$") || strstr(line,",,") )
    textcolor(YELLOW);
   else textcolor(WHITE);

   cprintf("%s\r",line);
  }
  line_nr++;
 }

 textcolor(LIGHTBLUE);
 gotoxy(width-8,height+2);
 cprintf("[%.3d/%.3d]",start_line,max_lines-height);
}

