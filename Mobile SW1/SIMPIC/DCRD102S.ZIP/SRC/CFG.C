/*
 * Discard - The software interface for the Simple Smartcard Reader (SSR)
 * http://www.nykoping.com/johan/discard/
 *
 * cfg.c - functions for configuration
 *
 * Copyright (c) 1998 Johan Larsson, johan@nykoping.com
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <string.h>
#include <conio.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <pc.h>
#include <dos.h>
#include <unistd.h>
//#include <dpmi.h>

#include "ssrio.h"
#include "defines.h"
#include "cfg.h"
#include "canalyse.h"
#include "ui.h"

void parse_cfg_file(void)
{
 FILE *cfg;
 char line[256],*tmp;
 int value;

  if ((cfg = fopen(CFG_FILE, "rt")) == NULL){
    printf("[ERROR] Cannot open config file %s\n",CFG_FILE);
    while(!kbhit());
  }



 if(cfg!=NULL){
  while(!feof(cfg)){
   fgets(line, 256, cfg);

    if(line[0]!='#' && line[0] != '\n'){

     if((tmp=strstr(line, "TEXT_START "))!=NULL){
      tmp+=11;
      sscanf(tmp, "%d", &value);

      if(value!=0&&value!=ScreenRows())
       _set_screen_lines(value);

     } else if((tmp=strstr(line, "TEXT_EXIT "))!=NULL){
      tmp+=10;
      sscanf(tmp, "%d", &value);

      TEXT_EXIT=value;

     } else if((tmp=strstr(line, "LPT_IOBASE "))!=NULL){
      tmp+=11;
      sscanf(tmp, "%i", &value);

      LPT_DATA=value;
      LPT_STATUS=LPT_DATA+1;
     }

    }
  }
 }

}


void commandline_parser(int argc, char **argv)
{
 int i;


 if(argc!=1)
  for(i=1;i<=argc;i++){

  strlwr(argv[i]);

  if(argv[i][0] == '/')
   argv[i][0] = '-';


  if( !strcmp(argv[i],"--version")){
   printf("\nDiscard %s\n"
          "Copyright (c) 1998 Johan Larsson, johan@nykoping.com\n"
          "%s\n\n"
          "Discard comes with NO WARRANTY, to the extent permitted by law.\n"
          "You may redistribute copies of Discard under the terms of the\n"
          "GNU General Public License.\n"
          "For more information about these matters, see the file named COPYING.\n",VERSION,URL);
   exit(0);
  }

  if( !strcmp(argv[i],"-h") ||
       strstr(argv[i],"?") ||
      !strcmp(argv[i],"--help")){


   printf("\nDiscard %s - The Simple Smartcard Reader software interface\n\n",VERSION);
   printf("Usage: %s\n",argv[0]);
   printf("  [-f x]    [--force x]        Force textmode with 80 columns and x lines.\n"
          "  [-s x y]  [--show_byte x y]  Shows unanalysed bytes x to y.\n"
          "            [--version]        Shows Discard version.\n"
          "            [--help]           Displays this help\n");

   printf("\nPlease read discard.txt for help.\n"
          "Report bugs to johan@nykoping.com\n");

   exit(0);
  }


  if( !strcmp(argv[i],"--greets") ){

   printf("\n[ Discard %s ]\n\n",VERSION);

   printf("Nice dudes:\n"
          "Henrik Antelius - Projectname founder and UI helper.\n"
          "Bj�rn Svensson - Betatester and Trosa�s heartbreaker.\n"
          "Henrik Fegreaus - Our beloved robotman.\n"
          );

   exit(0);
  }


  if( (!strcmp(argv[i],"--force") || !strcmp(argv[i],"-f")) && argc > i+1)
   _set_screen_lines(strtol(argv[i+1], NULL, 0));

  if( (!strcmp(argv[i],"--show_byte") || !strcmp(argv[i],"-s")) && argc > i)
   show_byte(strtol(argv[i+1], NULL, 0),strtol(argv[i+2], NULL, 0),SSR_dump_memory());


 }

}

