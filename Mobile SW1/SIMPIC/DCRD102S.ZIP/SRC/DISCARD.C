/*
 * Discard - The software interface for the Simple Smartcard Reader (SSR)
 * http://www.nykoping.com/johan/discard/
 *
 * discard.c - main
 *
 * Copyright (c) 1998 Johan Larsson, johan@nykoping.com
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include "ui.h"
#include "defines.h"
#include "ssrio.h"
#include "cfg.h"

void main(int argc,char **argv)
{
 LPT_DATA=LPT_DEFAULT;
 LPT_STATUS=LPT_DATA+1;

  parse_cfg_file();

  commandline_parser(argc,argv);

  init_screen();
  draw_main_screen();

  while(!DONE){

    switch(draw_menu(40,9))
    {
      case 0:
        draw_read_window(60,15);
        break;
      case 1:
        draw_open_window(40,9);
        break;
      case 2:
        draw_info_window(74,19);
        break;
      case 3:
        clean_up();
    }
  }

 clean_up();
}
