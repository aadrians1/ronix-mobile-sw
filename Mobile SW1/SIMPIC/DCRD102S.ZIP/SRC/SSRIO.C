/*
 * Discard - The software interface for the Simple Smartcard Reader (SSR)
 * http://www.nykoping.com/johan/discard/
 *
 * ssrio.c - SSR input/output functions
 *
 * Copyright (c) 1998 Johan Larsson, johan@nykoping.com
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <string.h>
#include <unistd.h>
#include <dos.h>

#include "ssrio.h"
#include "defines.h"


char SSR_card_present(void)
{
 int in;

 in = (inportb(LPT_STATUS)^0x80)&0xf8;

 if(in==0xe8)
  return TRUE;
 else return FALSE;
}


void SSR_green_led(char state)
{
 int in,out;

 if(state==TRUE){
  in = inportb(LPT_DATA);
  out = (in | MASK_SSR_GREEN_LED_HIGH);
  outportb(LPT_DATA, out);
 } else {
  in = inportb(LPT_DATA);
  out = (in & MASK_SSR_GREEN_LED_LOW);
  outportb(LPT_DATA, out);
 }

}


int SSR_read_bit(void)
{
 int in;

 in = (inportb(LPT_STATUS)^0x80)&0xf8;

 if(in==0xe0)
  return '0';
 else return '1';
}


void SSR_clock_high(void)
{
 int in,out;

 in = inportb(LPT_DATA);
 out = (in | MASK_CLOCK_HIGH);
 outportb(LPT_DATA, out);
 usleep(MIN_HIGHLEVEL_CLOCK);
}



void SSR_clock_low(void)
{
 int in,out;

 in = inportb(LPT_DATA);
 out = (in & MASK_CLOCK_LOW);
 outportb(LPT_DATA, out);
 usleep(MIN_LOWLEVEL_CLOCK);
}


void SSR_reset_high(void)
{
 int in,out;

 in = inportb(LPT_DATA);
 out = (in | MASK_RESET_HIGH);
 outportb(LPT_DATA, out);
}


void SSR_reset_low(void)
{
 int in,out;

 in = inportb(LPT_DATA);
 out = (in & MASK_RESET_LOW);
 outportb(LPT_DATA, out);
}


void SSR_reset_pointer(void)
{
 SSR_reset_low();
 SSR_clock_high();
 usleep(MIN_RESET);
 SSR_clock_low();
 SSR_reset_high();
}


char *SSR_dump_memory(void)
{
 char slask[MEM_SIZE+1];
 int i;

 SSR_reset_pointer();

 for(i=0;i<MEM_SIZE;i++){
  slask[i]=SSR_read_bit();
  SSR_clock_high();
  SSR_clock_low();
 }

 return strdup(slask);
}
