/*
 * Discard - The software interface for the Simple Smartcard Reader (SSR)
 * http://www.nykoping.com/johan/discard/
 *
 * canalyse.c - functions for smartcard memory analysing
 *
 * Copyright (c) 1998 Johan Larsson, johan@nykoping.com
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <pc.h>

#include "canalyse.h"
#include "defines.h"
#include "ssrio.h"


int read_byte(char *dump,int nr)
{
 char test[8];
 int x;

 for(x=0;x<8;x++)
  test[x] = dump[(nr-1)*8+x];

 return (int)strtol(test,NULL,2);
}


void analyse_dump(char *dump,card *c)
{
 int used_units=0,checksum=0,x,i,byte_5,byte_12;


 for(i=1;i<12;i++)
  for(x=0;x<8;x++)
   if(dump[i*8+x] == '1')
    checksum++;


 c->checksum1 = 216-checksum;
 c->checksum2 = read_byte(dump,1);


 byte_5=read_byte(dump,5);

 if(byte_5==0x00) strcpy(c->manufacturer,"Schlumberger (old)");
 else if(byte_5==0x01) strcpy(c->manufacturer,"Schlumberger (new)");
 else if(byte_5==0x10) strcpy(c->manufacturer,"Solaic");
 else if(byte_5==(0x30||0x40)) strcpy(c->manufacturer,"Gemplus");
 else strcpy(c->manufacturer,"Unknown");


 byte_12=read_byte(dump,12);

 if(byte_12==0x1d) strcpy(c->country,"France");
 else if(byte_12==0x1e) strcpy(c->country,"Sweden");
 else if(byte_12==0x24) strcpy(c->country,"Mexico");
 else if(byte_12==0x30) strcpy(c->country,"Norway");
 else if(byte_12==0x33) strcpy(c->country,"Andorra");
 else if(byte_12==0x3c) strcpy(c->country,"Ireland");
 else if(byte_12==0x47) strcpy(c->country,"Portugal");
 else if(byte_12==0x5f) strcpy(c->country,"Gabon");
 else if(byte_12==0x65) strcpy(c->country,"Finland");
 else strcpy(c->country,"Unknown");


 c->max_units = check_max_units(dump);


 for(i=12;i<32;i++)
  for(x=0;x<8;x++)
   if(dump[i*8+x] == '1')
    used_units++;

 c->units = used_units-2;


 for(i=0;i<5;i++)
  c->serial[i]=read_byte(dump,i+6);


 c->type=read_byte(dump,2);

}



int check_max_units(char *dump)
{
 int byte_3,byte_4;

 byte_3=read_byte(dump,3);
 byte_4=read_byte(dump,4);

 if(byte_3==0x10)
 {
 if(byte_4==0x12) return 10;
 if(byte_4==0x24) return 22;
 if(byte_4==0x27) return 25;
 if(byte_4==0x32) return 30;
 if(byte_4==0x52) return 50;
 if(byte_4==0x62) return 60;
 if(byte_4==0x82) return 80;
 }

 else if(byte_3==0x11)
 {
 if(byte_4==0x02) return 100;
 if(byte_4==0x22) return 120;
 if(byte_4==0x52) return 150;
 }

 return 0;
}


void print_analysation(card *c)
{
  textcolor(YELLOW);

  cprintf("%s - Serial number %X:%X:%X:%X:%X\n\n\r", c->type==0x83 ? "Telecard" : "Unknown type" ,c->serial[0],c->serial[1],c->serial[2],c->serial[3],c->serial[4]);

  textcolor(WHITE);

  cprintf("Maximum units: %d\n\r",c->max_units);
  cprintf("Present units left: %d\n\r",(c->max_units-c->units) < 0 || c->max_units==0 ? 0 : c->max_units-c->units);
  cprintf("Country: %s\n\r",c->country);
  cprintf("Manufacturer: %s\n\n\r",c->manufacturer);

  textcolor(LIGHTRED);

  if(c->type!=0x83)
   cprintf("WARNING: Unknown cardtype. Analysation may be wrong.\n\r");
  if(c->checksum1!=c->checksum2)
   cprintf("WARNING: Checksums not equal.\n\r");

}


void show_byte(int from,int to, char *dump)
{
 int i,x;
 char *description[]={" Checksum"," Cardtype"," Max units",""," Manufacturer"," Serial number","","","",""," Country",""," Used units"};

 if(from>0&&from<33&&to>0&&to<33&&from<=to){

  printf("\n[ Discard %s - %#x ]\n\n", VERSION, LPT_DATA);

  for(i=from-1;i<to;i++){
   printf("BYTE %d: \t",i+1);
   for(x=0;x<8;x++)
    printf("%c",dump[i*8+x]);
  if(i<13)
   printf("\t%s\n",description[i]);
  else printf("\n");
  }

  if(!SSR_card_present())
   printf("\nNo card detected in the SSR.");

  printf("\nRead discard.txt for more information.\n");

 } else printf("\n[ Discard %s ]\n\n"
               "show_byte arg error\n"
               "Usage: discard --show_byte <from> <to>\n"
               "       1 <= <from> <= 32\n"
               "       <from> <= <to> <= 32\n",VERSION);
 exit(0);
}
