typedef unsigned char Byte;

void A3A8(Byte rand[16], Byte key[16], Byte simoutput[12]);
void A3A8_tworounds(Byte rand[16], Byte key[16], Byte x[32]);
