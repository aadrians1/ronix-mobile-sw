#ifndef _GETRESPONSE_H
#define _GETRESPONSE_H

typedef unsigned char Byte;

extern void init_card(char* devicename, Byte pin[8]);
extern void get_response(Byte challenge[16], Byte response[12]);
extern void set_timeout(int);

#endif
