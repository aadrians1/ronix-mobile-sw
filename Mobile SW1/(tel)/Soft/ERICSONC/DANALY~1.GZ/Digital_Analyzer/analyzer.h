#ifndef FD_LAnalyser_h_
#define FD_LAnalyser_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void Version(FL_OBJECT *, long);
extern void Exit(FL_OBJECT *, long);
extern void Contador(FL_OBJECT *, long);
extern void Sampling(FL_OBJECT *, long);
extern void Menu_Port(FL_OBJECT *, long);


/**** Forms and Objects ****/

typedef struct {
	FL_FORM *LAnalyser;
	void *vdata;
	long ldata;
	FL_OBJECT *Version;
	FL_OBJECT *Exit;
	FL_OBJECT *Frequency;
	FL_OBJECT *Channels;
	FL_OBJECT *Display_Graphic;
	FL_OBJECT *Texto;
	FL_OBJECT *Slider;
	FL_OBJECT *Contador;
	FL_OBJECT *Start;
	FL_OBJECT *Stop;
	FL_OBJECT *Resume;
	FL_OBJECT *Port;
} FD_LAnalyser;

extern FD_LAnalyser * create_form_LAnalyser(void);

#endif /* FD_LAnalyser_h_ */
