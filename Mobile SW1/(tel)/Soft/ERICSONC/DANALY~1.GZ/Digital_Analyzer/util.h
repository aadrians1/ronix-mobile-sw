/*
 * util.h -- include file for support for the Logic Analyser program
 * 
 * Copyrigth (C) 1997 Nuno Sucena ( slug@student.dee.uc.pt )
 * 
 */

/* Don't change these ones ! */
#define PROGRAM_NAME "Logic Analyzer v0.2"
#define PROGRAM_AUTHOR "Nuno Sucena Almeida - DEE @ University of Coimbra - Portugal - Europe"
#define AUTHOR_EMAIL "slug@student.dee.uc.pt"

/* Define here the minimum port and maximum port from which you can select */
#define MIN_PORT 0x300
#define MAX_PORT 0x31f

/* Define to reset the graphic display each time there is an update */
#define CONTADOR_REFRESH

#define MAX_PONTOS 20
#define MAX_BIT_PORTS 8

/* initial input port */
#define DEFAULT_PORT MIN_PORT

/* initial number of channels */
#define DEFAULT_CHANNELS 1

/* initial sampling period */
#define DEFAULT_FREQUENCY 1

extern int channels;
extern double frequency;
extern long int port;
extern short int OK;

extern int get_bit ( int value , int bit );
extern int read_port ( int port );
extern void shift_values ( float *yy_ee[] );
extern void init_values ( float *yy_ee[] );
extern void init_choice (  FD_LAnalyser *form );

