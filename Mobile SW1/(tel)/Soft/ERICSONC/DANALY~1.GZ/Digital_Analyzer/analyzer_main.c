/*
 * analyzer_main.c -- Main source for the Logic Analyser program
 *
 * Copyrigth (C) 1997 Nuno Sucena ( slug@student.dee.uc.pt )
 *
 */

#include "forms.h"
#include "analyzer.h"
#include "util.h"

int main(int argc, char *argv[])
{
   FD_LAnalyser *fd_LAnalyser;
   fl_initialize(&argc, argv, 0, 0, 0);
   fd_LAnalyser = create_form_LAnalyser();
   /* fill-in form initialization code */
   init_choice ( fd_LAnalyser );
#ifndef CONTADOR_REFRESH
   fl_clear_xyplot(fd_LAnalyser->Display_Graphic);
   fl_set_xyplot_xbounds(fd_LAnalyser->Display_Graphic,0, MAX_PONTOS + 2 );
   fl_set_xyplot_ybounds(fd_LAnalyser->Display_Graphic,0, ( MAX_BIT_PORTS +1 )*2  );
   /* fl_set_xyplot_ytics(fd_LAnalyser->Display_Graphic, 0 , 10 );
    * fl_set_xyplot_ygrid(fd_LAnalyser->Display_Graphic, FL_GRID_MINOR); */
   /* fl_set_xyplot_xgrid(fd_LAnalyser->Display_Graphic, FL_GRID_MINOR); */
#endif
   /*   init_values ( yy ); */
   printf ( "%s\n%s\n%s\n\n" , PROGRAM_NAME , PROGRAM_AUTHOR , AUTHOR_EMAIL );
   if ( ioperm ( MIN_PORT,MAX_PORT - MIN_PORT + 1,1) == -1 )
     {
	fprintf(stderr,"Error accessing I/O Ports 0x%x -> 0x%x !\n", 
		MIN_PORT, MAX_PORT);
	OK = 1;
     }
   else
     OK = 0;
   /* show the first form */
   fl_show_form(fd_LAnalyser->LAnalyser,FL_PLACE_CENTER,FL_FULLBORDER,"LAnalyzer");
   fl_do_forms();
   ioperm ( MIN_PORT , MAX_PORT + MIN_PORT +1 , 0 );
   return 0;
}
