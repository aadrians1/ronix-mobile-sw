/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "analyzer.h"

FD_LAnalyser *create_form_LAnalyser(void)
{
  FL_OBJECT *obj;
  FD_LAnalyser *fdui = (FD_LAnalyser *) fl_calloc(1, sizeof(*fdui));

  fdui->LAnalyser = fl_bgn_form(FL_NO_BOX, 690, 460);
  obj = fl_add_box(FL_UP_BOX,0,0,690,460,"");
  fdui->Version = obj = fl_add_button(FL_NORMAL_BUTTON,20,20,100,40,"Logic Analyzer");
    fl_set_object_color(obj,FL_INDIANRED,FL_RED);
    fl_set_object_lcolor(obj,FL_RIGHT_BCOL);
    fl_set_object_callback(obj,Version,0);
  fdui->Exit = obj = fl_add_button(FL_NORMAL_BUTTON,20,70,100,40,"Exit");
    fl_set_object_color(obj,FL_SLATEBLUE,FL_DODGERBLUE);
    fl_set_object_lcolor(obj,FL_YELLOW);
    fl_set_object_callback(obj,Exit,0);
  fdui->Frequency = obj = fl_add_counter(FL_NORMAL_COUNTER,540,90,130,30,"Sampling Period (sec)");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_WHEAT,FL_BLUE);
    fl_set_object_lalign(obj,FL_ALIGN_TOP);
    fl_set_object_callback(obj,Contador,0);
    fl_set_counter_bounds(obj, 0.1, 10.0);
    fl_set_counter_value(obj, 1.0);
    fl_set_counter_return(obj, FL_RETURN_END);
  fdui->Channels = obj = fl_add_counter(FL_NORMAL_COUNTER,540,30,130,30,"Channels");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_WHEAT,FL_BLUE);
    fl_set_object_lalign(obj,FL_ALIGN_TOP);
    fl_set_object_callback(obj,Sampling,0);
    fl_set_counter_precision(obj, 0);
    fl_set_counter_bounds(obj, 1, 8);
    fl_set_counter_value(obj, 1);
    fl_set_counter_step(obj, 1, 2);
    fl_set_counter_return(obj, FL_RETURN_END);
  fdui->Display_Graphic = obj = fl_add_xyplot(FL_SQUARE_XYPLOT,150,130,500,310,"");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_INACTIVE,FL_CHARTREUSE);
  fdui->Texto = obj = fl_add_browser(FL_NORMAL_BROWSER,20,130,120,310,"");
    fl_set_object_color(obj,FL_DARKCYAN,FL_YELLOW);
  fdui->Slider = obj = fl_add_slider(FL_VERT_NICE_SLIDER,660,130,20,310,"");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_SLATEBLUE,FL_RED);
    fl_set_object_callback(obj,Sampling,0);
    fl_set_slider_precision(obj, 0);
    fl_set_slider_bounds(obj, 1, 16);
    fl_set_slider_value(obj, 1);
    fl_set_slider_size(obj, 0.25);
     fl_set_slider_return(obj, FL_RETURN_END);
  fdui->Contador = obj = fl_add_timer(FL_VALUE_TIMER,300,30,100,30,"");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_color(obj,FL_DARKGOLD,FL_RIGHT_BCOL);
    fl_set_object_lalign(obj,FL_ALIGN_TOP);
    fl_set_object_callback(obj,Contador,0);
  fdui->Start = obj = fl_add_button(FL_NORMAL_BUTTON,300,90,100,30,"Start");
    fl_set_object_color(obj,FL_DARKVIOLET,FL_COL1);
    fl_set_object_callback(obj,Contador,0);
  fdui->Stop = obj = fl_add_button(FL_NORMAL_BUTTON,420,30,100,30,"Stop");
    fl_set_object_color(obj,FL_RED,FL_COL1);
    fl_set_object_callback(obj,Contador,0);
  fdui->Resume = obj = fl_add_button(FL_NORMAL_BUTTON,420,90,100,30,"Resume");
    fl_set_object_color(obj,FL_ORCHID,FL_COL1);
    fl_set_object_callback(obj,Contador,0);
  fdui->Port = obj = fl_add_choice(FL_NORMAL_CHOICE2,180,90,100,30,"");
    fl_set_object_color(obj,FL_DARKORANGE,FL_BLACK);
    fl_set_object_callback(obj,Menu_Port,0);
  fl_end_form();

  fdui->LAnalyser->fdui = fdui;

  return fdui;
}
/*---------------------------------------*/

