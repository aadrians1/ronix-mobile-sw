Run Midic25.exe, than clik "Offline" button to find midi melody.
If file wont open, check file properties and make sure that "read only" option is off.

additional informations:
support@pinservice.com