So hier sind noch ein paar technische Daten:

Telefon ist ein Sagem 939 Version FW 4.1 E

IMEI ist 		332120820115010

Unlockcode		12203200

Kartendaten, ausgelesen mit Sim Spy

Card Identification	8949 2060 4000 6297 0365

IMSI			262 02 6020 189189


Folgende �nderungen zwischen den Binfiles haben sich ergeben:

Adresse A4F bis A52

Locked			49 FF 4F 22

Unlocked		48 BC 9B 61


Das Eeprom ist ein 24lc128 von Microchip


Denkt daran, mich hat dieser Code 200 Mark gekostet, findet jemand eine
L�sung, so w�hre es nur fair, sie mir mitzuteilen.

jimlovell@hotmail.com


Beiliegende Files:

Locked.bin		Ausgelesen eingebucht, vor Eingabe des Codes
			im Hotline Men�.

Unlocked.bin		Ausgelesen eingebucht, direkt nach der Eingabe
			im Hotline Men�, Telefon sagte ausgef�hrt.

20115010lock.dat	Ausgelesen vor unlocking mit Sagem_l2.


20115010unlock.dat	Ausgelesen nach unlocking mit Sagem_l2.


Traumpaar.html		Webseite von D2 mit unlockcode.
