
/* EEPROM / Flash EPROM Programmer */
/*   last edit 15-Mar-97   */
/*    by Jeff Frohwein    */

/* Compiled with Microsoft C 6.0 */

/* Rev 1.0 - Original release */
/* Rev 1.1 - Added verify command */
/* Rev 1.2 - Added support for AMD & Data Valid programming algorithms */
/* Rev 1.3 - Added support for 10ms algorithm */
/* Rev 1.4 - Modified to support REV C & later schematics */

#include <stdio.h>
#include <string.h>
#include <dos.h>

typedef struct
{ /* time holder */
  int hour;
  int minute;
  int sec;
  int hsec;
} TIME, *TIME_PTR;

#define GET_TIME	0x2c		/* time request		*/
#define DOS_INT		0x21		/* int to call DOS	*/
#define INIT		6		/* initial clock set	*/

enum BOOLEAN
   {
   false,
   true
   };

#define BYTE    unsigned char
#define WORD    unsigned int
#define LONG    unsigned long
#define DELAY   delay(WaitDelay)

/* Change those defines to match your compiler. */
#define OUTPORT(port, val)      outp(port, val)   /*; DELAY */
#define INPORT(port)		inp(port)

#define CTRL    CtrlPort
#define DATA    DataPort
#define STATUS  StatusPort

/* Programming algorithm defines */
#define AMD29FXXX     0
#define DATA_VALID    1
#define TEN_MS        2

/*
 * Bits for MUX (C B A):
 *      ~AUTOFDXT ~SCLINT ~STROBE
 * Bits in CTRL register (7..0):
 *      N/A N/A N/A IRQEnable ~SCLINT INIT ~AUTOFDXT ~STROBE
 */

/*
 * Bits read (7..0):
 *      BUSY ~ACKPR PE SLCT ERROR N/A N/A N/A
 * Bits from REGISTER (D7..D4, D3..D0):
 *      SLCT PE BUSY ~ACK
 */

#ifdef MK_FP
#undef MK_FP
#endif
#define MK_FP(seg, ofs)     ((void far *) ((unsigned long) (seg)<<16|(ofs)))

BYTE Algorithm, Size;
char Data, Control;
int del;
int WaitDelay;
LONG Address;
unsigned CtrlPort;
unsigned DataPort;
unsigned StatusPort;

/* function prototypes */

BYTE ReadByte (void);
int InitPort (int port);
void delay (int d);
void SetInitPort (void);
LONG ChipSize (BYTE size);
void SetAddr (LONG Addr);
void IncAddr (void);
void WriteByte (BYTE val);
BYTE ProgramByte (LONG Addr, BYTE val);
BYTE ReadByte (void);
void dump (void);
void ReadChip (FILE * fp);
void VerifyChip (FILE * fp);
BYTE EraseAm29Fxxx (void);
void ErrorExit (void);
void ProgramChip (FILE * fp);

/*
 * get_time(n)
 * TIME_PTR n;
 *
 * fills timetype structure n with current time using DOS interrupt 21
 *
 */

get_time(n)
TIME_PTR n;
{
  union REGS inregs;
  union REGS outregs;

  inregs.h.ah = GET_TIME;

  int86(DOS_INT, &inregs, &outregs);

  n->hour = outregs.h.ch;
  n->minute  = outregs.h.cl;
  n->sec  = outregs.h.dh;
  n->hsec = outregs.h.dl;

  return(0);
}

void msleep(int ms)
   {
   /* sleep for ms milliseconds */
   static long count = 0;
   static long wait = 1;
   long d, i, loops;
   TIME n1, n2;
   int delay = 0;

   if (count == 0)
      {
      printf("Delay calibration in progress...\n");
      /* wait for a clock tick */
      count = 1000L;
      while (delay < 200)
         {
         wait = wait << 1;
         get_time(&n1);
         delay = n1.hsec;
         while (n1.hsec == delay)
            get_time(&n1);
         /* get a ballpark figure */
         for (loops = 0; loops < count; loops++)
            for (i = 0; i<wait; i++);
         get_time(&n2);
         delay = (100*n2.sec + n2.hsec) - (100*n1.sec + n1.hsec);
         if (delay < 0) delay += 6000;
         }
/*
printf("1st time %2d:%02d:%02d.%02d\n", n1.hour, n1.minute, n1.sec, n1.hsec);
printf("%02d.%02d ... %02d.%02d\n", n1.sec, n1.hsec, n2.sec, n2.hsec);
printf("delay %d ms\n", 10*delay);
*/
      /* this is the first guess */
      count = 100* count / delay;
/*
printf("Delay %d loops/ms\n", count);
*/
      /* this one should be about 2 sec */
/*
      get_time(&n1);
      d = INIT*count;
      for (loops = 0; loops < d; loops++)
         for (i = 0; i<wait; i++);
      get_time(&n2);
      delay = (100*n2.sec + n2.hsec) - (100*n1.sec + n1.hsec);
      if (delay < 0) delay += 6000;
 printf("delay %d ms\n", 10*delay);
      count = INIT*100*count / delay;
printf("Delay %d loops/ms\n", count);
*/
      }
   else
      {
      get_time(&n1);

      d = ms*count/1000;
      for (loops = 0; loops < d; loops++)
         for (i = 0; i<wait; i++);

      get_time(&n2);
      del = (100*n2.sec + n2.hsec) - (100*n1.sec + n1.hsec);
      if (del < 0) delay += 6000;
/*
      printf("delay %d ms\n", delay);
*/
      }
   }

void usage (void)
   {
   printf(" Usage: eep [-l int] [-s int] [-p | -r | -v file[.obj]]\n");
   printf("   -a   Algorithm of programming (0=AMD Am29Fxxx,1=Data Valid,2=10ms)\n");
   printf("           (default is 0 = AMD Am29Fxxx)\n");
   printf("   -d   Dump first 256 bytes of chip to screen\n");
   printf("   -l   Specify the port to use (default is 1 = LPT1)\n");
   printf("   -p   Program chip from file\n");
   printf("   -r   Read chip to file\n");
   printf("   -s   Size in bits (0=16k,1=32k,2=64k,3=128k,4=256k,5=512k,6=1m,\n");
   printf("           7=2m,8=4m,9=8m,10=16m) (default is 6 = 1mbits)\n");
   printf("   -v   Verify chip matches file\n");
   }

int InitPort (int port)
   {
   DataPort = *(unsigned far *) MK_FP(0x0040, 6 + 2 * port);
   if (DataPort == 0)
      {
      printf("Can't find address of parallel port %d...\n", port);
      exit(1);
      }
   else
      {
      StatusPort = DataPort + 1;
      CtrlPort = DataPort + 2;
      printf("Parallel port %d is located at %Xh.\n", port, DataPort);
      }
   }

void delay (int d)
   {
   while (d--);
   }

/* if port not specified set to LPT1 */

void SetInitPort (void)
   {
   if (DataPort == 0)
      InitPort(1);
   }

/* Return actual chip size in bits */

LONG ChipSize (BYTE size)
   {
   BYTE i;
   LONG Length = 16384;

   for(i=0; i<size; i++)
      Length *= 2;

   return(Length);
   }

/* Print chip size */

void PrintChipSize (void)
   {
   LONG i = ChipSize(Size);
   printf("Chip size = %lu bits (%lu bytes)\n", i, i/8);
   }

/* Set chip address */

void SetAddr (LONG Addr)
   {
   BYTE Clk0, Clk1, Clk2, i, temp;

   Address = Addr;

   Data &=~0x40; OUTPORT(DataPort, Data);   /* Clear all counters */
   Data |= 0x40; OUTPORT(DataPort, Data);

   Clk0 =  Addr & 0xff;
   Clk1 = (Addr >> 8) & 0xff;
   Clk2 = (Addr >> 16) & 0xff;

   while ( (Clk0 != 0) ||
           (Clk1 != 0) ||
           (Clk2 != 0) )
      {
      temp = 0;

      if (Clk0 != 0) { temp |= 1; Clk0--; }
      if (Clk1 != 0) { temp |= 2; Clk1--; }
      if (Clk2 != 0) { temp |= 4; Clk2--; }

      Data |= temp; OUTPORT(DataPort, Data);
      Data &=~temp; OUTPORT(DataPort, Data);
      }

   Data |=  7; OUTPORT(DataPort, Data);   /* Clock counters to latch */
   Data &= ~7; OUTPORT(DataPort, Data);
   }

/* Increment chip address */

void IncAddr(void)
   {
   Address++;
   Data |= 1; OUTPORT(DataPort, Data);
   Data &=~1; OUTPORT(DataPort, Data);
   if ((Address & 0xff) == 0)
      {
      Data |= 2; OUTPORT(DataPort, Data);
      Data &=~2; OUTPORT(DataPort, Data);
      if ((Address & 0xffff) == 0)
         {
         Data |= 4; OUTPORT(DataPort, Data);
         Data &=~4; OUTPORT(DataPort, Data);
         }
      }
   }

/* Write a byte to chip */

void WriteByte(BYTE val)
   {
   BYTE i, v;

   v = val;
   for(i=0; i<8; i++)
      {
      if ((v & 0x80) == 0)
         Data &=~0x10;
      else
         Data |= 0x10;
      OUTPORT(DataPort, Data);
      Data |= 8; OUTPORT(DataPort, Data); /* Clock data into SR */
      Data &=~8; OUTPORT(DataPort, Data);
      v <<= 1;
      }

   Data |= 8; OUTPORT(DataPort, Data); /* Clock data into latch */
   Data &=~8; OUTPORT(DataPort, Data);

   Control &=~4; OUTPORT(CtrlPort, Control); /* Set /WOE low */

   Control |= 1; OUTPORT(CtrlPort, Control); /* Set /WR low */
   Control &=~1; OUTPORT(CtrlPort, Control); /* Set /WR high */

   Control |=4; OUTPORT(CtrlPort, Control); /* Set /WOE low */
   }

/* Wait for program byte completion */

BYTE ProgramDone (BYTE val)
   {
   BYTE Check;
   BYTE Pass = 0;

   switch (Algorithm)
      {
      case AMD29FXXX:
         Check = ReadByte();

         /* Loop until chip done programming */
         while ( (Check != val) &&
                 ((Check & 0x20)==0) )
            Check = ReadByte();

         if (Check == val)
            Pass = 1;
         else
            {
            Check = ReadByte();
            if (Check == val)
               Pass = 1;
            }
         break;
      case DATA_VALID:
         /* Loop until chip done programming */

         while (ReadByte() != val)
            {}

         Pass = 1;
         break;
      case TEN_MS:
         /* Delay for 10 milliseconds */

         msleep(10);
         Pass = 1;
         break;
      }
   return (Pass);
   }

/* Program a byte on chip */

BYTE ProgramByte(LONG Addr, BYTE val)
   {
   BYTE Pass = 0;

   if (Algorithm == AMD29FXXX)
      {
      SetAddr(0x5555);  WriteByte(0xaa);
      SetAddr(0x2aaa);  WriteByte(0x55);
      SetAddr(0x5555);  WriteByte(0xa0);
      }

   SetAddr(Addr);    WriteByte(val);

   /* Wait until chip done programming */
   Pass = ProgramDone(val);

   if (Pass == 0)
      printf("Write failed at Address %lx of rom.\n", Address);

   return (Pass);
   }

/* Read a byte from chip */

BYTE ReadByte(void)
   {
   BYTE i;

   Control |= 2; OUTPORT(CtrlPort, Control);     /* Set /RD low */
   Data &=~0x80; OUTPORT(DataPort, Data);        /* Set U/L low */
   i = (INP(StatusPort) >> 3) & 0xf;
   Data |= 0x80; OUTPORT(DataPort, Data);        /* Set U/L high */
   i = ((INP(StatusPort) << 1) & 0xf0)+i;
   Control &=~2; OUTPORT(CtrlPort, Control);     /* Set /RD high */

   return(i);
   }

void dump(void)
   {
   int i;
   BYTE First = 1;
   BYTE val;
   Data = 0x60;
   Control = 0xc;

   PrintChipSize();

   /* Initialize ports */
   OUTPORT(CtrlPort, Control);
   OUTPORT(DataPort, Data);

   SetAddr(0);
   for(i=0; i<256; i++)
      {
      if (First == 1)
         {
         if (i < 16) printf("0");
         printf("%hx - ",i);
         First = 0;
         }
      val = ReadByte();
      IncAddr();
      if (val < 16)
         printf("0");
      printf("%hx ",val);
      if ((i & 0xf)==0xf)
         {
         First = 1;
         printf("\n");
         }
      }
   }

void ReadChip(FILE * fp)
   {
   short int a;
   LONG i;
   BYTE val;

   Data = 0x60;
   Control = 0xc;

   PrintChipSize();

   /* Initialize ports */
   OUTPORT(CtrlPort, Control);
   OUTPORT(DataPort, Data);

   SetAddr(0);

   for(i = 0; i < (ChipSize(Size)/8); i++)
      {
      val = ReadByte();
      IncAddr();

      /* Print char to file */
      fputc(val, fp);
      }
   }

/* Compare chip to a file */

void VerifyChip(FILE * fp)
   {
   short int a;
   LONG i = 0;
   BYTE val;
   BYTE CompareFail = 0;
   int c;

   Data = 0x60;
   Control = 0xc;

   PrintChipSize();

   /* Initialize ports */
   OUTPORT(CtrlPort, Control);
   OUTPORT(DataPort, Data);

   SetAddr(0);

   while ( (!feof(fp)) && (i < (ChipSize(Size)/8)) )
      {
      c = fgetc(fp);
      if (c != EOF)
         {
         val = ReadByte();
         IncAddr();
         if (c != val)
            {
            printf("Address %lx - Rom %hx : File %hx\n", i, val, c);
            CompareFail = 1;
            }
         i++;
         }
      }

      if (CompareFail == 0)
         printf("%lu bytes compared ok.\n", i);
   }

/* Erase AMD chips */

BYTE EraseAm29Fxxx(void)
   {
   BYTE i;

   BYTE Pass = 0;
   BYTE Val1 = 0;
   BYTE Val2 = 0x40;

   printf("Erasing Am29Fxxx chip...");
   SetAddr(0x5555); WriteByte(0xaa);
   SetAddr(0x2aaa); WriteByte(0x55);
   SetAddr(0x5555); WriteByte(0x80);
   SetAddr(0x5555); WriteByte(0xaa);
   SetAddr(0x2aaa); WriteByte(0x55);
   SetAddr(0x5555); WriteByte(0x10);

   SetAddr(0);

   /* Wait for erase to complete */
   while ( ((Val1 & 0x40) != (Val2 & 0x40)) &&
           ((Val2 & 0x20)==0) )
      {
      Val1 = ReadByte();
      Val2 = ReadByte();
      }

   /* If toggle stopped, chip erased okay */
   if ((Val1 & 0x40) == (Val2 & 0x40))
      Pass = 1;
   else
      {
      Val1 = ReadByte();
      if ((Val1 & 0x40) == (Val2 & 0x40))
         Pass = 1;
      }
   printf("\n");

   if (Pass == 0)
      printf("Chip erase failed!\n");

   return (Pass);
   }

void ErrorExit(void)
   {
   exit(1);
   }

/* Begin chip programming */

void ProgramChip(FILE * fp)
   {
   BYTE b;
   BYTE Pass = 1;
   int c;
   LONG Addr = 0;
   short int a, cnt, z;
   enum BOOLEAN lock;

   Data = 0x60;
   Control = 0xc;

   /* Initialize ports */
   OUTPORT(CtrlPort, Control);
   OUTPORT(DataPort, Data);

   if (Algorithm == AMD29FXXX)
      {
      if (!EraseAm29Fxxx())   /* Chip erase */
         ErrorExit();
      }

   if (Algorithm == TEN_MS)
      msleep(0);             /* Calibrate delay routine */

   printf("Programming chip - |");
   while ( (!feof(fp)) &&
           (Addr < (ChipSize(Size)/8)) &&
           (Pass == 1) )
      {
      c = fgetc(fp);
      if (c != EOF)
         {
         b = c;
         Pass = ProgramByte(Addr, b);
         Addr++;
         switch (Addr & 0x3ff)
            {
            case 0:
               printf("\b/");
               break;
            case 0x100:
               printf("\b-");
               break;
            case 0x200:
               printf("\b\\");
               break;
            case 0x300:
               printf("\b|");
               break;
            }
         }
      }
   printf("\n");

   if (Pass == 0)
      {
      printf("Program error. Chip may be bad!\n");
      ErrorExit();
      }
   else
      printf("%lu bytes programmed.\n", Addr);
   }

void main(int argc, char **argv)
   {
   int arg;
   FILE *fp;
   char fname[20];

   WaitDelay = 5;

   DataPort = 0;           /* Indicate port not selected */
   Algorithm = AMD29FXXX;  /* default to Am29Fxxx programming algorithm */
   Size = 6;               /* default to 1mbit chip */

   printf("EEPROM / Flash EPROM Programmer V1.4, by Jeff Frohwein, 15-Mar-97\n");

/*
  msleep(0);
  printf("Start\n");
  msleep(3000);
  printf("delay %d ms\n", 10*del);
  printf("3 secs\n");
*/

   /* If no arguments then print help menu */
   if (argc < 2)
      {
      usage();
      exit(1);
      }

   for (arg = 1; arg < argc; arg++)
      {

      /* If invalid command line character then exit */
      if (argv[arg][0] != '-')
         {
         usage();
         exit(1);
         }

      switch (argv[arg][1])
         {
      case 'a':
      case 'A':
         /* Specify programming algorithm */
         Algorithm = atoi(argv[++arg]);
         if (Algorithm > 2)
            {
            printf("Programming algorithm selection invalid!\n");
            exit(1);
            }
         break;
      case 'd':
      case 'D':
         SetInitPort();
         dump();
         break;
      case 'p':
      case 'P':
         /* Add extension .OBJ if none present */
         strcpy(fname, argv[++arg]);
         if (strchr(fname, '.') == NULL)
            strcat(fname, ".obj");

         if ((fp = fopen(fname, "rb")) == NULL)
            {
            printf("Error opening file '%s'\n", fname);
            exit(1);
            }
         SetInitPort();
         ProgramChip(fp);
         fclose(fp);
         break;
      case 'l':
      case 'L':
         InitPort(atoi(argv[++arg]));
         break;
      case 'r':
      case 'R':
         /* Add extension .OBJ if none present */
         strcpy(fname, argv[++arg]);
         if (strchr(fname, '.') == NULL)
            strcat(fname, ".obj");

         if ((fp = fopen(fname, "wb")) == NULL)
            {
            printf("Error opening file '%s'\n", fname);
            exit(1);
            }
         SetInitPort();
         ReadChip(fp);
         fclose(fp);
         break;
      case 's':
      case 'S':
         /* Specify size of chip */
         Size = atoi(argv[++arg]);
         if (Size>10)
            {
            printf("Chip size selection invalid!\n");
            exit(1);
            }
         break;
      case 'v':
      case 'V':
         /* Add extension .OBJ if none present */
         strcpy(fname, argv[++arg]);
         if (strchr(fname, '.') == NULL)
            strcat(fname, ".obj");

         if ((fp = fopen(fname, "rb")) == NULL)
            {
            printf("Error opening file '%s'\n", fname);
            exit(1);
            }
         SetInitPort();
         VerifyChip(fp);
         fclose(fp);
         break;
      default:
         usage();
         exit(1);
         }
      }
   exit(0);
   }
