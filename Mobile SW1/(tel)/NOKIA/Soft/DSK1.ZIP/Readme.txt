
Installation:
Start setup.exe. In the first window press the "Instructions" button at the down right corner. You'll get to the "Setup Instructions" screen. Try printing the instructions by clicking the "Print instructions to default printer" button. Then go on by following the instructions. Write down any oddities you find from there.

If you cannot access any printers from your computer, that's OK as installation should be quite straight forward anyway. In "Setup Communication Link" choose "Install Infrared link" option. (If you have Nokia Data Suite 1.2 installed, then you have already cable support, and infrared too if you had chosen to install it). If possible, use infrared as your primary connection method because it's important to find out about possible compatibility problems in different computers. If you have Outlook/Schedule+ installed, you should also select the check box in "Enhanced Sychronization Support" window. That adds "Synchronize with Nokia phone" menu option to Outlook/Schedule menu and enables you to sychronize phone with Outlook/Schedule+ without opening the PC Calendar. 


IMPORTANT!
-Before synchronizing your Outlook/Schedule+ with PC Calendar or phone for the first time, read the instructions how to backup your the data in Outlook/Schedule+ and then do it! Otherwise you may lose information. Instructions are below ("Backing up the calendar information").


Nice to know:
-Recurrence behaves differently in PC Calendar and Outlook/Schedule+ as there's no support for recurring note in the 6100-phones. Therefore when you delete recurring note from PC Calendar the whole series is deleted, not just that one item.
-PC Calendar associates each phone (or actually its IMEI code) to one PC Calendar file. If you are only using one phone with your PC Calendar then you won't probably even notice it, as the first time you connect your phone to PC Calendar it gets automatically associated to default 'npccal.ncl' file. However, if you are using several phones, then you have to give names for each PC Calendar file.
-Old (yesterday and before that) notes are deleted from phone while synchronizing
-There's room for about 20-30 notes in the 6110. The length of the note text in phone is 20-30 characters.
-You cannot synchronize phone/PC Calendar with Schedule+ if Outlook is installed


Some known bugs:
-There may be inaccuracies in UI/Help texts especially in other languages than English and Finnish 
-Resource problems: after some period of usage the icons may turn black or fonts may change in PC Calendar, other applications or desktop
-F7 doesn't list notes
-You need mouse to access all the fields as you cannot always use mnemonics or tab key to move the cursor
-Program doesn't ask you to connect phone when you are synchronizing from Outlook/Schedule+, you have to do it yourself before starting the sync.
-"Server busy" dialog may appear sometimes when using IR-connection


Backing up the calendar information (Outlook/Schedule+):

Outlook:

The deleted calendar notes can be retrieved, if in Options/General you don't have "Empty the Deleted Items folder upon exiting" as checked. If you have it checked, then uncheck it for the time you are using PC Calendar. From Deleted Items folder you can move notes back to Calendar folder.

Another way to retrieve data is to use "Export to File" function. It goes like this:
To export calendar data to file:
-Choose "File/Import and Export" from Outlook menu
-Choose "Export to presonal folder file (.pst)"
-Choose "Calendar" (it's default)
-Give name to export file and the save it
And you can import the exported data back to Outlook by:
-Choose "File/Import and Export"
-Choose "Import from a personal folder file (.pst)"
-Choose the exported file (and so on)


Schedule+:
There is no Deleted Items folder in Schedule+, so exporting the data in the Schedule+ is recommended.

Export: Choose "File/Export/Schedule+Interchange" and so on (saves Schedule+ data to file)
Import: Choose "File/Import/Schedule+Interchange" and so on (imports the contents of export file to Schedule+)
