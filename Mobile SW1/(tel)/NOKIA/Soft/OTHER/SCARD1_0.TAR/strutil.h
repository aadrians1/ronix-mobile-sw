#ifndef HEADER_TJH_STRUTIL_H
#define HEADER_TJH_STRUTIL_H

extern char *mstrtok(char *cp,char *patlist);
extern int mstrtok_clear(char *cp);

#endif /* HEADER_TJH_STRUTIL_H */

