NOKIA 5110 skin for WinAMP              [released 13 April 1999]


INTRODUCTION
~~~~~~~~~~~~
Greetings from  Novorossiysk/Russia  and  thanks for downloading
this skin. Make sure you have at least WinAMP 1.8, otherwise you
are not able to use this skin as your Winamp interface.

Check http://www.winamp.com for the latest release of WinAMP.


INSTALLATION
~~~~~~~~~~~~
Unzipping to your winamp/skins directory will create a subfolder
storing all data.  Launch WinAMP,  go to the option-menu and use
the skin-browser to select the skin.

For  users  of  WinAMP 2.04  or  higher  it's enough to copy the
ZIP-File to the winamp/skins directory.


ABOUT
~~~~~
This is my  first  WinAMP skin. It was designed  to look like my
Nokia 5110 cellular phone.


CREDITS & CONTACT
~~~~~~~~~~~~~~~~~
Idea and realization: Dmitriy Loza AKA Dexter
                      <mr.dexter@iname.com>
                      http://www.nvrsk.ru/~dexter

Hardware ;) creation: Nokia Corporation
                      http://www.nokia.com

Parts of this manual: Jan T.Sott
                      <yathosho@altavista.net>
                      http://members.xoom.com/animeye/winamp


LEGAL
~~~~~

WinAMP is Copyright � 1997-1998 Nullsoft, Inc. and Justin Frankel.
WinAMP is a trademark of Nullsoft, Inc.
