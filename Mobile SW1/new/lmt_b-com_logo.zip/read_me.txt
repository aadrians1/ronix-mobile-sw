This file was downloaded from
http://www.digits.lv/gsm